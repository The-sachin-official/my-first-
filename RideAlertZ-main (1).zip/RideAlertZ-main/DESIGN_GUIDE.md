# RideAlertz - UI/UX Design Guide

## 🎨 Color Palette

### Emergency Theme Colors

#### Primary Colors
```kotlin
EmergencyRed     = #DC2626  // Main alerts, emergency button
NeonGreen        = #10B981  // Active status, success
AlertOrange      = #F59E0B  // Warnings, pending states
```

#### Dark Theme
```kotlin
BlackPrimary     = #0F172A  // Background
BlackSecondary   = #1E293B  // Surface
BlackTertiary    = #334155  // Cards, containers
```

#### Light Theme
```kotlin
WhitePrimary     = #FAFAFA  // Background
WhiteSecondary   = #FFFFFF  // Surface
GrayLight        = #E2E8F0  // Dividers
GrayMedium       = #94A3B8  // Secondary text
GrayDark         = #475569  // Primary text
```

#### Accent Colors
```kotlin
AccentBlue       = #3B82F6  // Information, links
AccentPurple     = #8B5CF6  // Special features
```

---

## 📐 Layout Specifications

### Spacing System
- **Extra Small**: 4dp
- **Small**: 8dp
- **Medium**: 16dp
- **Large**: 24dp
- **Extra Large**: 32dp

### Border Radius
- **Small**: 8dp (chips, tags)
- **Medium**: 12dp (buttons)
- **Large**: 16dp (cards)
- **Extra Large**: 20-24dp (hero elements)
- **Circle**: 50% (icons, avatars)

### Elevation
- **Flat**: 0dp (most cards in Material 3)
- **Low**: 2dp (interactive cards)
- **Medium**: 4dp (floating elements)
- **High**: 8dp (dialogs, modals)

---

## 🔤 Typography

### Font Family
- **Default**: System font (Roboto on Android)

### Type Scale
```kotlin
displayLarge     = 57sp, Bold
displayMedium    = 45sp, Bold
displaySmall     = 36sp, Bold

headlineLarge    = 32sp, Bold
headlineMedium   = 28sp, Bold
headlineSmall    = 24sp, Bold

titleLarge       = 22sp, Bold
titleMedium      = 16sp, SemiBold
titleSmall       = 14sp, Medium

bodyLarge        = 16sp, Regular
bodyMedium       = 14sp, Regular
bodySmall        = 12sp, Regular

labelLarge       = 14sp, Medium
labelMedium      = 12sp, Medium
labelSmall       = 11sp, Medium
```

### Usage Guidelines
- **Headlines**: Screen titles, important messages
- **Titles**: Card headers, section titles
- **Body**: Main content, descriptions
- **Labels**: Buttons, chips, tags

---

## 🎯 Component Specifications

### Emergency Button (Hero)
```
Size: 220dp diameter
Shape: Circle
Color: EmergencyRed (#DC2626)
Icon: 64dp
Text: titleLarge, Bold, White
Animation: Pulse (1s, 1.0 → 1.05 scale)
Interaction: Long-press 2s
Feedback: Haptic
```

### Welcome Card
```
Width: Match parent
Height: Wrap content
Padding: 20dp
Radius: 20dp
Background: 
  - Active: secondaryContainer (Neon Green tint)
  - Inactive: surfaceVariant (Gray)
Icon: 56dp circle
Title: headlineSmall, Bold
Subtitle: bodyLarge
```

### Quick Action Icons
```
Size: 28dp icon
Layout: Column (icon + label)
Spacing: 4dp between icon and text
Color: secondary (Neon Green)
Text: labelMedium
Interaction: Single tap
```

### Settings Items
```
Height: 64dp minimum
Padding: 12dp
Icon: 40dp circle container, 20dp icon
Title: bodyLarge, Medium
Subtitle: bodySmall, onSurfaceVariant
Trailing: ChevronRight or Switch
```

### Status Chips
```
Height: 28dp
Padding: 10dp horizontal, 5dp vertical
Radius: 8dp
Background: Color.copy(alpha = 0.1f)
Text: labelSmall, color matches background
```

---

## 🌈 Color Usage Guidelines

### Semantic Colors

#### Success (Neon Green)
- Monitoring active
- GPS connected
- Operation successful
- Confirmation messages

#### Warning (Alert Orange)
- GPS pending
- Low battery
- Attention needed
- Non-critical alerts

#### Error (Emergency Red)
- Crash detected
- Emergency triggered
- Critical errors
- Destructive actions

#### Info (Accent Blue)
- Information messages
- Help text
- Links
- Navigation

### State Colors

#### Active State
```kotlin
Background: secondaryContainer
Icon: secondary (Neon Green)
Text: onSecondaryContainer
```

#### Inactive State
```kotlin
Background: surfaceVariant
Icon: onSurfaceVariant (Gray)
Text: onSurfaceVariant
```

#### Emergency State
```kotlin
Background: errorContainer
Icon: error (Emergency Red)
Text: onErrorContainer
```

---

## 🎭 Animations

### Timing
- **Fast**: 150ms (micro-interactions)
- **Normal**: 300ms (transitions)
- **Slow**: 500ms (emphasis)
- **Very Slow**: 1000ms+ (ambient)

### Easing
- **Standard**: Ease in-out (default)
- **Decelerate**: Ease out (entering)
- **Accelerate**: Ease in (exiting)

### Animation Specs

#### Emergency Button Pulse
```kotlin
infiniteRepeatable(
    animation = tween(1000),
    repeatMode = RepeatMode.Reverse
)
Scale: 1.0 → 1.05
```

#### Fade In (Splash)
```kotlin
tween(durationMillis = 1500)
Alpha: 0f → 1f
```

#### Status Change
```kotlin
tween(durationMillis = 500)
Color: previous → new
```

---

## 📱 Screen Layouts

### Home Screen Structure
```
┌─────────────────────────┐
│  TopAppBar              │
│  "RideAlertz"           │
├─────────────────────────┤
│  Padding: 24dp          │
│                         │
│  ┌───────────────────┐  │
│  │ Welcome Card      │  │
│  │ (Status Header)   │  │
│  └───────────────────┘  │
│                         │
│  ┌───────────────────┐  │
│  │                   │  │
│  │  Emergency Button │  │
│  │  (Hero Element)   │  │
│  │                   │  │
│  │  Quick Actions    │  │
│  │  [Settings] [Profile] [Help]
│  │                   │  │
│  └───────────────────┘  │
│                         │
└─────────────────────────┘
```

### Settings Screen Structure
```
┌─────────────────────────┐
│  TopAppBar              │
│  [←] "Settings"         │
├─────────────────────────┤
│  Padding: 16dp          │
│                         │
│  Emergency              │
│  ┌───────────────────┐  │
│  │ Emergency Contacts│→ │
│  │ Emergency Services│→ │
│  └───────────────────┘  │
│                         │
│  Monitoring             │
│  ┌───────────────────┐  │
│  │ Auto-Start      ○ │  │
│  │ High Sensitivity○ │  │
│  └───────────────────┘  │
│                         │
│  [More sections...]     │
└─────────────────────────┘
```

---

## 🔘 Interactive States

### Button States
```kotlin
// Default
containerColor = primary
contentColor = onPrimary

// Pressed
containerColor = primary.copy(alpha = 0.8f)

// Disabled
containerColor = surfaceVariant
contentColor = onSurfaceVariant.copy(alpha = 0.38f)
```

### Card States
```kotlin
// Default
elevation = 0.dp
backgroundColor = surface

// Pressed (if clickable)
elevation = 2.dp
backgroundColor = surfaceVariant

// Selected
backgroundColor = primaryContainer
```

---

## ♿ Accessibility

### Touch Targets
- **Minimum**: 48dp × 48dp
- **Recommended**: 56dp × 56dp for primary actions

### Color Contrast
- **Normal text**: 4.5:1 minimum
- **Large text**: 3:1 minimum
- **UI components**: 3:1 minimum

### Content Descriptions
```kotlin
Icon(
    imageVector = Icons.Default.Emergency,
    contentDescription = "Emergency alert button"
)
```

### Text Scaling
- Support system font size settings
- Test with 200% text scale
- Use `sp` for text sizes

---

## 🌓 Dark/Light Theme

### Theme Toggle
- Follow system preference by default
- Optional manual override in settings

### Dark Theme Adjustments
- Reduce elevation shadows
- Use brighter accent colors
- Increase contrast for text

### Light Theme Adjustments
- Subtle shadows for depth
- Standard accent colors
- Comfortable reading contrast

---

## 📐 Grid System

### Mobile (Portrait)
- **Columns**: 4
- **Gutter**: 16dp
- **Margin**: 16dp

### Tablet (Landscape)
- **Columns**: 12
- **Gutter**: 24dp
- **Margin**: 24dp

---

## 🎬 Micro-interactions

### Haptic Feedback
```kotlin
// Light tap
HapticFeedbackType.Click

// Long press
HapticFeedbackType.LongPress

// Error
HapticFeedbackType.Reject
```

### Sound Effects
- Emergency alert: Loud, distinct siren
- Crash detection: Alert tone
- Success: Soft confirmation beep
- Error: Error tone

---

## 📋 Checklist for New Screens

- [ ] Use theme colors (no hardcoded colors)
- [ ] Apply proper spacing (8dp, 16dp, 24dp)
- [ ] Set content descriptions for accessibility
- [ ] Add haptic feedback for key actions
- [ ] Test in both light and dark themes
- [ ] Verify touch targets (min 48dp)
- [ ] Add loading/error states
- [ ] Support text scaling
- [ ] Test on different screen sizes
- [ ] Follow navigation patterns

---

## 🚀 Quick Reference

### Primary Actions
- **Color**: EmergencyRed or NeonGreen
- **Size**: Large (56dp height minimum)
- **Position**: Prominent, easy to reach

### Secondary Actions
- **Style**: Outlined or Text buttons
- **Color**: Primary or Secondary
- **Size**: Medium (48dp height)

### Tertiary Actions
- **Style**: Text buttons or icons
- **Color**: onSurfaceVariant
- **Size**: Small (40dp)

### Status Indicators
- **Active**: Neon Green
- **Warning**: Alert Orange
- **Error**: Emergency Red
- **Neutral**: Gray

---

*Last Updated: 2025-10-06*
*Version: 1.0.0*
