# How to Check Logcat Errors in Android Studio

## Method 1: Using Android Studio Logcat (Recommended)

### Steps:
1. **Open Logcat Panel**
   - At the bottom of Android Studio, click on the **"Logcat"** tab
   - If you don't see it, go to: `View` → `Tool Windows` → `Logcat`

2. **Filter Logs**
   - In the Logcat search box, type: `AmbulanceDriverLogin` or `AmbulanceDriver`
   - This will show only logs related to ambulance driver login

3. **Select Your Device/Emulator**
   - Make sure your device/emulator is selected in the device dropdown at the top

4. **Clear Logs Before Testing**
   - Click the trash icon (🗑️) to clear old logs
   - This makes it easier to see new errors

5. **Test the Login**
   - Try logging in with your credentials
   - Watch the Logcat for error messages

## Method 2: Using ADB Command Line

### For Windows PowerShell:
```powershell
# Connect to your device first, then run:
adb logcat -c  # Clear logs
adb logcat | Select-String -Pattern "AmbulanceDriver"
```

### For Command Prompt:
```cmd
adb logcat -c
adb logcat | findstr "AmbulanceDriver"
```

## What to Look For:

### Successful Login Logs:
```
D/AmbulanceDriverLogin: Attempting login with email: AMB-TN-999@ambulance.ridealertz.com, driverId: AMB-TN-999
D/AmbulanceDriverLogin: Login successful, UID: abc123...
D/AmbulanceDriverLogin: Bundle created: driverId=AMB-TN-999, driverName=...
D/AmbulanceDriverLogin: Intent created, starting activity...
D/AmbulanceDriverLogin: Activity started successfully
D/AmbulanceDriver: onCreate started
D/AmbulanceDriver: Driver data: id=AMB-TN-999, name=...
D/AmbulanceDriver: onCreate completed successfully
```

### Error Logs to Watch For:
```
E/AmbulanceDriverLogin: Login error
E/AmbulanceDriverLogin: Error starting AmbulanceDriverActivity
E/AmbulanceDriver: Error in onCreate
```

## Common Error Messages:

1. **"The supplied auth credential is incorrect"**
   - Wrong password or email format mismatch
   - Check if account was created with old buggy format

2. **"There is no user record corresponding to this identifier"**
   - Account doesn't exist in Firebase
   - Need to register first

3. **"Error starting AmbulanceDriverActivity"**
   - Activity navigation issue
   - Check AndroidManifest.xml

4. **"Error in onCreate"**
   - AmbulanceDriverActivity crashed on startup
   - Check the full stack trace

## Filter Tags to Use:

- `AmbulanceDriverLogin` - Login activity logs
- `AmbulanceDriver` - Dashboard activity logs
- `AmbulanceDriverRegister` - Registration logs
- `AndroidRuntime` - App crashes
- `FATAL` - Critical errors

## Tips:

1. **Use Log Level Filter**
   - Click the dropdown next to search (shows "Verbose" by default)
   - Select "Error" to see only errors
   - Or select "Debug" to see all debug messages

2. **Save Logs**
   - Right-click in Logcat → "Save Logcat to File"
   - Useful for sharing errors

3. **Real-time Monitoring**
   - Keep Logcat open while testing
   - Errors appear immediately when they occur

