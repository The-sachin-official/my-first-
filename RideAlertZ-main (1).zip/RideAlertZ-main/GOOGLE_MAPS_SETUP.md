# Google Maps API Key Setup Guide

## Quick Setup (5 minutes)

### Step 1: Get Your API Key

1. **Go to Google Cloud Console**
   - Visit: https://console.cloud.google.com/

2. **Create/Select a Project**
   - Click "Select a project" at the top
   - Click "NEW PROJECT"
   - Name it: "RideAlertz" (or any name)
   - Click "CREATE"

3. **Enable Maps SDK**
   - In the search bar, type: "Maps SDK for Android"
   - Click on "Maps SDK for Android"
   - Click "ENABLE"

4. **Create API Key**
   - Go to: https://console.cloud.google.com/apis/credentials
   - Click "CREATE CREDENTIALS" → "API key"
   - Copy the API key (it looks like: `AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX`)

### Step 2: Add API Key to Your App

Open `AndroidManifest.xml` and replace line 37:

**Change from:**
```xml
android:value="YOUR_GOOGLE_MAPS_API_KEY_HERE" />
```

**Change to:**
```xml
android:value="AIzaSy_YOUR_ACTUAL_KEY_HERE" />
```

### Step 3: Restrict Your API Key (Optional but Recommended)

1. In Google Cloud Console, click on your API key
2. Under "Application restrictions":
   - Select "Android apps"
   - Click "ADD AN ITEM"
   - Package name: `com.example.ridealertz`
   - SHA-1 certificate fingerprint: (see below how to get it)

#### Get SHA-1 Fingerprint:
```bash
# In Android Studio Terminal:
cd android
gradlew signingReport

# Or use keytool:
keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
```

### Step 4: Sync and Run

1. In Android Studio: **File → Sync Project with Gradle Files**
2. **Build → Clean Project**
3. **Build → Rebuild Project**
4. **Run the app**

---

## Alternative: Use Without Restrictions (For Testing)

If you just want to test quickly:
1. Get the API key (steps 1-4 above)
2. Paste it in AndroidManifest.xml
3. Don't add restrictions
4. Run the app

**Note**: Unrestricted keys can be used by anyone, so add restrictions before publishing!

---

## Troubleshooting

### Map shows "For development purposes only"
- Your API key is working but needs billing enabled
- Go to: https://console.cloud.google.com/billing
- Enable billing (Google gives $200 free credit monthly)

### Map is blank/grey
- Check internet connection
- Verify API key is correct
- Make sure "Maps SDK for Android" is enabled
- Check Logcat for error messages

### "API key not found" error
- Make sure you copied the entire key
- No extra spaces before/after the key
- Sync Gradle files after adding the key

---

## Cost Information

- **Free tier**: $200 credit per month
- **Map loads**: First 100,000 loads/month are FREE
- **For a personal app**: You'll likely never pay anything

---

## Quick Test

After adding the key:
1. Run the app
2. Login
3. The map should show with a marker
4. You should see streets, buildings, etc.

If you see a grey screen with Google logo → API key issue
If you see the map → SUCCESS! ✅
