# Cleanup Instructions - Remove Database Files

## Files to Delete Manually

### 1. Delete Network Package (Android Studio)
**Path**: `app/src/main/java/com/example/ridealertz/network/`

**Steps**:
1. In Android Studio, navigate to Project view
2. Expand: `app` → `src` → `main` → `java` → `com.example.ridealertz`
3. Right-click on `network` folder
4. Select "Delete"
5. Confirm deletion

**Files inside**:
- `ApiConfig.kt`
- `ApiService.kt`
- `RetrofitClient.kt`

---

### 2. Delete XAMPP Backend Folder (File Explorer)
**Path**: `xampp_backend/`

**Steps**:
1. Open File Explorer
2. Navigate to: `C:\Users\Admin\AndroidStudioProjects\rideAlertz\`
3. Find `xampp_backend` folder
4. Right-click → Delete
5. Confirm deletion

**Folder contains**:
- `ridealertz_api/`
  - `config.php`
  - `login.php`
  - `register.php`
  - `get_contacts.php`
  - `add_contact.php`
  - `delete_contact.php`
  - `set_primary.php`
  - `clear_all.php`
  - `test.php`
  - `database.sql`
  - `users_table.sql`
- `README.md`

---

### 3. Delete Database Setup Guides (Optional)
These files are no longer needed:

**In Android Studio or File Explorer**:
- `DATABASE_SETUP_GUIDE.md`
- `LOGIN_SETUP_GUIDE.md`

---

## After Deletion

### 1. Sync Project
1. In Android Studio, click: **File** → **Sync Project with Gradle Files**
2. Wait for sync to complete
3. All errors should be resolved

### 2. Clean and Rebuild
1. Click: **Build** → **Clean Project**
2. Wait for clean to finish
3. Click: **Build** → **Rebuild Project**
4. Wait for rebuild to complete

### 3. Verify No Errors
1. Check the "Build" tab at bottom
2. Should show: "BUILD SUCCESSFUL"
3. No red errors in code editor

---

## Quick Delete Commands (Alternative)

If you prefer using terminal/command prompt:

### Windows PowerShell:
```powershell
# Navigate to project root
cd C:\Users\Admin\AndroidStudioProjects\rideAlertz

# Delete network package
Remove-Item -Recurse -Force app\src\main\java\com\example\ridealertz\network

# Delete XAMPP backend
Remove-Item -Recurse -Force xampp_backend

# Delete old guides (optional)
Remove-Item DATABASE_SETUP_GUIDE.md
Remove-Item LOGIN_SETUP_GUIDE.md
```

### Windows Command Prompt:
```cmd
cd C:\Users\Admin\AndroidStudioProjects\rideAlertz

rmdir /s /q app\src\main\java\com\example\ridealertz\network
rmdir /s /q xampp_backend
del DATABASE_SETUP_GUIDE.md
del LOGIN_SETUP_GUIDE.md
```

---

## Verification Checklist

After deletion, verify:

- [ ] `network` folder deleted from `com.example.ridealertz`
- [ ] `xampp_backend` folder deleted from project root
- [ ] No import errors in Android Studio
- [ ] Gradle sync successful
- [ ] Build successful
- [ ] App runs without crashes

---

## If You See Errors After Deletion

### "Cannot resolve symbol 'network'"
**Solution**: The import is still there. Check these files:
- `LoginActivity.kt` - Should NOT have `import com.example.ridealertz.network.*`
- `EmergencyContactsActivity.kt` - Should NOT have network imports

### "Unresolved reference: RetrofitClient"
**Solution**: 
1. Search project for "RetrofitClient"
2. Remove any remaining references
3. Sync Gradle again

### Build errors about Retrofit/OkHttp
**Solution**:
1. Open `build.gradle.kts` (app level)
2. Verify these lines are REMOVED:
   - `implementation("com.squareup.retrofit2:retrofit:2.9.0")`
   - `implementation("com.squareup.retrofit2:converter-gson:2.9.0")`
   - `implementation("com.squareup.okhttp3:okhttp:4.12.0")`
   - `implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")`
3. Sync Gradle

---

## Summary

After completing these steps:
✅ No database code remains  
✅ No network dependencies  
✅ App uses only SharedPreferences  
✅ Completely offline  
✅ No build errors  

The app is now clean and ready to run!
