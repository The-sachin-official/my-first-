# RideAlertz - New Features Documentation

## Overview
This document describes the newly implemented advanced driving features for the RideAlertz application.

---

## 🌙 1. Dark Mode / Hands-Free Mode

### Description
- **Dark Mode**: System-wide dark theme for better visibility during night driving
- **Hands-Free Mode**: Automatically enabled in Driving Mode with voice alerts

### Implementation
- **Location**: `SettingsActivity.kt`, `Theme.kt`
- **Features**:
  - Toggle in Settings → Appearance → Dark Mode
  - Persistent preference storage
  - Automatic dark theme in Driving Mode for reduced eye strain
  - High contrast UI optimized for driving conditions

### Usage
1. Open Settings
2. Navigate to "Appearance" section
3. Toggle "Dark Mode" switch
4. Theme applies immediately across the app

---

## 🚗 2. Driving Mode with Speed Limit Alerts

### Description
Full-screen, distraction-free driving interface with real-time speed monitoring and voice alerts.

### Implementation
- **Location**: `DrivingModeActivity.kt`
- **Features**:
  - Large speed display (120sp font)
  - Configurable speed limit (default: 60 km/h)
  - Visual warning when speed limit exceeded
  - Pulsing red alert animation
  - Text-to-Speech voice alerts: "Speed limit exceeded. Current speed X kilometers per hour"
  - Always-on screen (keepScreenOn)
  - Dark theme for night driving

### Key Components
```kotlin
- Speed Display: Real-time speed in km/h
- Speed Limit Indicator: Shows current limit
- Warning System: Visual + Audio alerts
- Trip Statistics: Distance, violations, duration
```

### Usage
1. From main screen, tap "Driving" tab in bottom navigation
2. Driving Mode launches automatically
3. Speed is monitored continuously
4. Alerts trigger when exceeding limit
5. Tap "End Trip" to finish and view score

---

## 📊 3. Driving Behavior Analysis

### Description
Real-time analysis of driving patterns including harsh braking, sharp turns, and speed violations.

### Implementation
- **Location**: `DrivingBehaviorAnalyzer.kt`, `SensorMonitoringService.kt`
- **Sensors Used**:
  - Accelerometer: Detects harsh braking (>8 m/s²)
  - Gyroscope: Detects sharp turns (>2.5 rad/s)
  - GPS: Calculates speed and distance

### Detected Behaviors

#### Harsh Braking
- **Threshold**: 8.0 m/s² forward deceleration
- **Condition**: Only detected when speed > 20 km/h
- **Callback**: Voice alert + counter increment

#### Sharp Turns
- **Threshold**: 2.5 rad/s rotation (Z-axis)
- **Condition**: Only detected when speed > 30 km/h
- **Callback**: Voice alert + counter increment

#### Speed Violations
- **Threshold**: Configurable speed limit
- **Detection**: Continuous GPS speed monitoring
- **Callback**: Voice alert with current speed

### Data Tracked
- Total distance traveled (km)
- Trip duration (minutes)
- Current speed (km/h)
- Average speed (km/h)
- Harsh braking count
- Sharp turn count
- Speed violation count

---

## 🏆 4. Gamified Safe Driving Score

### Description
Scoring system (0-100) that encourages safe driving habits with achievements and history tracking.

### Implementation
- **Location**: `SafeDrivingScoreActivity.kt`, `DrivingBehaviorAnalyzer.kt`

### Scoring Algorithm
```
Base Score: 100 points

Deductions:
- Harsh Braking: -5 points each (max -30)
- Sharp Turns: -3 points each (max -20)
- Speed Violations: -10 points each (max -40)

Final Score: Max(0, Base - Deductions)
```

### Score Ranges
- **90-100**: Excellent! Gold Badge 🌟
- **80-89**: Great! Silver Badge 👍
- **70-79**: Good - Room for improvement
- **60-69**: Fair - Drive more carefully
- **0-59**: Needs improvement

### Features
- **Animated Score Circle**: Visual progress indicator with color coding
  - Green (80-100): Safe driver
  - Orange (60-79): Moderate risk
  - Red (0-59): High risk
  
- **Achievement Badges**:
  - Total Trips counter
  - Average Score display
  - Badge Level (Gold/Silver/Bronze/Novice)

- **Trip History**: Last 50 trips with:
  - Date and time
  - Distance and duration
  - Safety score
  - Violation breakdown

- **Statistics**:
  - Total trips completed
  - Overall average score
  - Persistent across sessions

### Usage
1. Complete a driving trip
2. Tap "End Trip" in Driving Mode
3. View your safety score automatically
4. Or access anytime via "Safety" tab in main screen

---

## 📹 5. Dashcam Integration

### Description
Continuous video recording with rolling 30-second buffer. Automatically saves footage when accident/impact detected.

### Implementation
- **Location**: `DashcamRecorderService.kt`
- **Technology**: Camera2 API with MediaRecorder

### Features

#### Continuous Recording
- **Buffer**: 30 seconds (3 segments × 10 seconds)
- **Resolution**: 1920x1080 (Full HD)
- **Frame Rate**: 30 fps
- **Bitrate**: 10 Mbps
- **Format**: MP4 (H.264 video, AAC audio)

#### Rolling Buffer
- Keeps only last 3 video segments
- Automatically deletes old segments
- Minimal storage usage
- Temporary files in app directory

#### Impact Detection
- Triggered by `SensorMonitoringService` on accident detection
- Saves last 30 seconds to permanent storage
- Location: `/Movies/RideAlertz_Impacts/`
- Filename: `impact_YYYYMMDD_HHMMSS.mp4`
- Notification shown when saved

### Service Actions
```kotlin
ACTION_START_RECORDING: Start dashcam
ACTION_STOP_RECORDING: Stop dashcam
ACTION_SAVE_IMPACT: Save current buffer
```

### Permissions Required
- `CAMERA`: Video recording
- `RECORD_AUDIO`: Audio recording
- `WRITE_EXTERNAL_STORAGE`: Save videos
- `FOREGROUND_SERVICE_CAMERA`: Background recording

### Usage
1. Dashcam starts automatically in Driving Mode
2. Records continuously in background
3. On accident detection:
   - Last 30 seconds saved automatically
   - Notification shows saved location
4. Access saved videos in `/Movies/RideAlertz_Impacts/`

### Storage Management
- Temporary files: Auto-deleted
- Impact videos: Kept permanently
- User can manually delete from file manager

---

## 🎯 Integration Points

### Main Screen
- **Driving Tab**: Launches Driving Mode
- **Safety Tab**: Shows Safe Driving Score

### Settings
- **Appearance**: Dark mode toggle
- **Driving Mode**: 
  - Speed limit configuration
  - Auto-start dashcam option

### Sensor Service
- Integrates with existing accident detection
- Adds behavior analysis
- Triggers dashcam save on impact

---

## 📱 User Flow

### Starting a Drive
1. Open RideAlertz app
2. Tap "Driving" in bottom navigation
3. Driving Mode launches (dark theme)
4. Dashcam starts recording
5. Speed monitoring begins
6. Behavior analysis active

### During Drive
- Large speed display visible
- Speed limit alerts (visual + voice)
- Behavior violations tracked
- Dashcam recording continuously
- Stats updated in real-time

### Ending a Drive
1. Tap "End Trip" button
2. Trip data saved to history
3. Safety score calculated
4. Score screen displayed automatically
5. Dashcam stops recording

### Viewing History
1. Tap "Safety" tab anytime
2. View current score
3. See achievement badges
4. Browse trip history
5. Track improvement over time

---

## 🔧 Technical Details

### Dependencies Added
```kotlin
// CameraX for dashcam
implementation("androidx.camera:camera-core:1.3.1")
implementation("androidx.camera:camera-camera2:1.3.1")
implementation("androidx.camera:camera-lifecycle:1.3.1")
implementation("androidx.camera:camera-video:1.3.1")
implementation("androidx.camera:camera-view:1.3.1")
```

### Permissions Added
```xml
<!-- Camera and audio -->
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_CAMERA" />

<!-- Hardware features -->
<uses-feature android:name="android.hardware.camera" />
<uses-feature android:name="android.hardware.camera.autofocus" />
```

### New Activities
1. `DrivingModeActivity`: Full-screen driving interface
2. `SafeDrivingScoreActivity`: Score and history display

### New Services
1. `DashcamRecorderService`: Background video recording

### New Components
1. `DrivingBehaviorAnalyzer`: Behavior analysis engine

---

## 🎨 UI/UX Highlights

### Driving Mode
- **Minimalist Design**: Focus on essential information
- **High Contrast**: Black background, white text
- **Large Typography**: 120sp speed display
- **Color Coding**: 
  - White: Normal speed
  - Red: Speed violation
- **Animations**: Pulsing warning indicator
- **Voice Feedback**: Hands-free operation

### Score Screen
- **Animated Elements**: Smooth score circle animation
- **Color Psychology**:
  - Green: Safe/Good
  - Orange: Warning/Moderate
  - Red: Danger/Poor
- **Achievement System**: Gamification for engagement
- **History Cards**: Easy-to-scan trip summaries

---

## 📈 Future Enhancements

### Potential Additions
1. **Advanced Dashcam**:
   - Front + rear camera support
   - Night vision mode
   - Video compression
   - Cloud backup

2. **Behavior Analysis**:
   - Lane departure detection
   - Following distance monitoring
   - Drowsiness detection
   - Distraction alerts

3. **Gamification**:
   - Leaderboards
   - Challenges and missions
   - Rewards system
   - Social sharing

4. **Speed Limits**:
   - Automatic limit detection via GPS
   - Road-specific limits
   - School zone alerts
   - Variable speed zones

---

## 🐛 Known Limitations

1. **Dashcam**:
   - Single camera (back-facing only)
   - No video merging (saves last segment only)
   - Requires significant storage
   - Battery intensive

2. **Behavior Analysis**:
   - Accuracy depends on sensor quality
   - May have false positives on rough roads
   - Speed calculation requires good GPS signal

3. **Score System**:
   - Simple algorithm (can be enhanced)
   - No context awareness (e.g., emergency situations)

---

## 📞 Support

For issues or questions:
- Check sensor calibration in device settings
- Ensure all permissions granted
- Verify GPS signal strength
- Clear app cache if behavior tracking issues

---

## 📝 Version History

### v1.0 - Initial Release
- Dark mode support
- Driving mode with speed alerts
- Behavior analysis (braking, turns, speed)
- Gamified safety score
- Dashcam integration with impact save

---

**Last Updated**: 2025-01-13
**Author**: RideAlertz Development Team
