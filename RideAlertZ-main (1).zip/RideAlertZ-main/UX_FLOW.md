# RideAlertz - UX Flow & Design Documentation

## 🎨 Design System

### Color Palette (Emergency Theme)
- **Primary Emergency Red**: `#DC2626` - Main alerts, emergency button
- **Neon Green**: `#10B981` - Active status, success states
- **Alert Orange**: `#F59E0B` - Warnings, pending states
- **Deep Black**: `#0F172A` - Dark theme background
- **Off-White**: `#FAFAFA` - Light theme background
- **Accent Blue**: `#3B82F6` - Information, links

### Typography
- **Headlines**: Bold, 28-36sp
- **Body**: Regular, 14-16sp
- **Labels**: Medium, 12-14sp

---

## 📱 Screen Layouts

### 1. Splash Screen
**Purpose**: Brand introduction, app initialization
- Large app logo/icon (emergency symbol)
- App name "RideAlertz"
- Tagline "Your Safety Companion"
- Fade-in animation (1.5s)
- Auto-navigate to Home (3s)

### 2. Home Screen (Main Dashboard)
**Purpose**: Primary control center
**Components**:
- **Top Bar**: App title "RideAlertz"
- **Welcome Card**: 
  - Status icon (shield/checkmark)
  - "Welcome" or "You're Protected" text
  - Subtitle based on monitoring state
- **Emergency Button** (Hero):
  - Large circular red button (220dp)
  - Emergency icon + "Press & Hold" text
  - Pulsing animation
  - Long-press (2s) to trigger
  - Instruction text below
- **Quick Actions** (Bottom):
  - Settings icon + label
  - Profile icon + label
  - Help icon + label

### 3. Crash Alert Screen
**Purpose**: Emergency detection confirmation
**Components**:
- Full-screen alert overlay
- Countdown timer (10s)
- "Crash Detected!" headline
- "Cancel" button (if false alarm)
- Auto-trigger emergency protocol

### 4. Settings Screen
**Purpose**: App configuration
**Sections**:
- **Emergency Contacts**: Add/edit contacts
- **Monitoring Settings**: Sensitivity, auto-start
- **Notifications**: Alert preferences
- **Location**: GPS settings
- **About**: App version, privacy policy

---

## 🔄 UX Flow

### Primary Flow: Ride Monitoring
```
1. App Launch
   └─> Splash Screen (3s)
       └─> Home Screen

2. Start Ride
   └─> User taps "Start Monitoring" (if not auto)
       └─> Welcome card shows "You're Protected"
       └─> Neon green status indicator
       └─> Background service starts
       └─> Sensors activate (accelerometer, gyroscope, GPS)

3. Normal Ride
   └─> App monitors in background
       └─> GPS tracks location
       └─> Sensors detect motion patterns
       └─> No alerts triggered

4. Crash Detection
   └─> Sudden deceleration detected
       └─> Gyroscope confirms impact
       └─> Crash Alert Screen appears
       └─> Countdown starts (10s)
       └─> User can cancel if false alarm
       └─> If not canceled:
           ├─> Send SMS to emergency contacts
           ├─> Share live location
           ├─> Call emergency services (optional)
           └─> Log incident

5. End Ride
   └─> User taps "Stop Monitoring"
       └─> Service stops
       └─> Welcome card shows "Welcome"
       └─> Gray status indicator
```

### Secondary Flow: Manual Emergency
```
1. User on Home Screen
   └─> Long-press Emergency Button (2s)
       └─> Haptic feedback
       └─> Crash Alert Screen appears
       └─> Same emergency protocol as auto-detection
```

### Settings Flow
```
1. Home Screen
   └─> Tap Settings icon
       └─> Settings Screen opens
       └─> User configures:
           ├─> Emergency contacts
           ├─> Sensitivity levels
           ├─> Auto-start preferences
           └─> Notification settings
       └─> Back to Home
```

### Emergency Contact Flow
```
1. Settings Screen
   └─> Tap "Emergency Contacts"
       └─> Contact List Screen
       └─> Tap "Add Contact"
           ├─> Pick from phone contacts
           ├─> Set as Primary/Secondary
           └─> Save
       └─> Back to Settings
```

---

## 🚀 Navigation Structure

```
SplashActivity
    ↓ (auto, 3s)
MainActivity (Home)
    ├─> CrashAlertActivity (on detection/manual trigger)
    ├─> SettingsActivity (Settings icon)
    ├─> ProfileActivity (Profile icon)
    ├─> HelpActivity (Help icon)
    ├─> LiveTrackingActivity (from Quick Actions)
    ├─> ShareLocationActivity (from Quick Actions)
    └─> EmergencyContactsActivity (from Settings)
```

---

## ⚡ Key Interactions

### Emergency Button
- **Visual**: Red circle, pulsing animation
- **Action**: Long-press 2 seconds
- **Feedback**: Haptic vibration
- **Result**: Trigger emergency protocol

### Monitoring Toggle
- **Visual**: Large button, color changes (green/red)
- **Action**: Single tap
- **States**: 
  - Inactive → Active (green, "Stop Monitoring")
  - Active → Inactive (gray, "Start Monitoring")

### Status Indicators
- **Neon Green**: Monitoring active, GPS connected
- **Orange**: Warning, GPS pending
- **Red**: Error, emergency triggered
- **Gray**: Inactive

---

## 📊 Screen States

### Home Screen States
1. **Inactive**: Gray theme, "Start Monitoring" button
2. **Active**: Green accents, "Stop Monitoring" button
3. **Emergency**: Red overlay, countdown timer

### Crash Alert States
1. **Countdown**: 10s timer, "Cancel" option
2. **Triggered**: "Sending alerts..." message
3. **Completed**: "Emergency contacts notified" confirmation

---

## 🎯 Design Principles

1. **Clarity**: Large, readable text and icons
2. **Speed**: Minimal taps to critical functions
3. **Safety**: Confirmation for destructive actions
4. **Feedback**: Visual + haptic for all interactions
5. **Accessibility**: High contrast, large touch targets
6. **Emergency-First**: Red for alerts, green for safety

---

## 🔔 Notification Flow

### Crash Detected
```
1. Vibration pattern (emergency)
2. Sound alert (loud, distinct)
3. Full-screen alert (even if locked)
4. SMS to contacts: "Emergency! [Name] may have crashed. Location: [GPS link]"
5. Persistent notification with "I'm OK" action
```

### Monitoring Active
```
1. Ongoing notification: "RideAlertz is monitoring your ride"
2. Quick actions: Stop Monitoring, Share Location
```

---

## 📱 Responsive Design

### Phone (Portrait)
- Single column layout
- Full-width cards
- Large emergency button (220dp)

### Tablet (Landscape)
- Two-column layout (optional)
- Larger emergency button (280dp)
- Side panel for quick actions

---

## 🌙 Theme Support

### Light Theme
- Off-white background (#FAFAFA)
- Dark text (#0F172A)
- Colorful accents (red, green, orange)

### Dark Theme
- Deep black background (#0F172A)
- White text
- Vibrant accents (neon green, bright red)

---

## ✅ Accessibility

- **Minimum touch target**: 48dp
- **Color contrast**: WCAG AA compliant
- **Screen reader**: Content descriptions for all icons
- **Large text**: Scales with system settings
- **Haptic feedback**: For critical actions
