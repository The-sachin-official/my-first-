# RideAlertz - No Database Version

## Overview
All database functionality has been removed. The app now uses **SharedPreferences** for local storage only.

---

## What Was Removed

### ❌ Deleted Files/Folders
- `app/src/main/java/com/example/ridealertz/network/` - All network API files
- All PHP backend files in `xampp_backend/ridealertz_api/`:
  - `login.php`
  - `register.php`
  - `get_contacts.php`
  - `add_contact.php`
  - `delete_contact.php`
  - `set_primary.php`
  - `clear_all.php`
  - `config.php`
  - `test.php`
  - `database.sql`
  - `users_table.sql`

### ❌ Removed Dependencies
- Retrofit (API calls)
- OkHttp (HTTP client)
- Coroutines (async operations)

### ❌ Removed Features
- MySQL database integration
- Network API calls
- Loading indicators
- Error messages for network issues
- XAMPP backend

---

## What's Now Used

### ✅ SharedPreferences Storage

**User Data:**
```kotlin
// Stored in SharedPreferences
- is_logged_in: Boolean
- user_name: String
- user_email: String
- user_phone: String
- users: JSON array of all registered users
```

**Emergency Contacts:**
```kotlin
// Stored in SharedPreferences
- emergency_contacts: JSON array of contacts
```

---

## How It Works Now

### 1. Login System
- **Registration**: User data stored in SharedPreferences as JSON array
- **Login**: Validates against locally stored users
- **Session**: Uses `is_logged_in` flag
- **No server required**

### 2. Emergency Contacts
- **Add**: Saves to SharedPreferences immediately
- **Remove**: Updates SharedPreferences
- **Set Primary**: Updates locally
- **Clear All**: Clears from SharedPreferences

### 3. Data Persistence
- All data stored on device only
- No internet connection required
- Data persists until app is uninstalled
- No sync between devices

---

## App Structure

### LoginActivity
```kotlin
// Local authentication
- Stores users in SharedPreferences
- No password hashing (plain text)
- Email validation
- Duplicate email check
```

### MainActivityNew
```kotlin
// Main map screen
- Google Maps integration
- Bottom tabs: Location, Driving, Safety
- User profile display
- Check-in and SOS buttons
```

### EmergencyContactsActivity
```kotlin
// Contact management
- Add/Remove contacts
- Set primary contact
- All stored locally in SharedPreferences
```

---

## Setup Instructions

### 1. Sync Gradle
1. Open project in Android Studio
2. Click "Sync Now"
3. Wait for sync to complete

### 2. Add Google Maps API Key
1. Get API key from [Google Cloud Console](https://console.cloud.google.com/)
2. Enable "Maps SDK for Android"
3. Open `AndroidManifest.xml`
4. Replace `YOUR_GOOGLE_MAPS_API_KEY` with your key:

```xml
<meta-data
    android:name="com.google.android.geo.API_KEY"
    android:value="YOUR_ACTUAL_API_KEY_HERE" />
```

### 3. Run the App
1. Connect device or start emulator
2. Click Run (green play button)
3. App will launch with login screen

---

## Usage

### First Time Use
1. **Register**: 
   - Click "Sign Up"
   - Enter name, email, phone, password
   - Click "Sign Up"
   - Returns to login screen

2. **Login**:
   - Enter registered email and password
   - Click "Login"
   - Navigates to main map screen

3. **Add Emergency Contacts**:
   - From main screen, tap Settings or Contacts
   - Click "+" button
   - Fill in contact details
   - Optionally set as primary
   - Click "Add Contact"

### Subsequent Use
- App remembers login state
- Auto-logs in on app restart
- All data persists locally

---

## Data Storage Details

### Users JSON Structure
```json
[
  {
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "+1234567890",
    "password": "password123"
  }
]
```

### Emergency Contacts JSON Structure
```json
[
  {
    "name": "Jane Doe",
    "phone": "+0987654321",
    "initials": "JD",
    "isPrimary": true
  }
]
```

---

## Advantages of No Database

✅ **No server setup required**  
✅ **Works completely offline**  
✅ **Faster - no network delays**  
✅ **Simpler architecture**  
✅ **No hosting costs**  
✅ **Privacy - data stays on device**  

---

## Limitations

⚠️ **No data backup** - Data lost if app uninstalled  
⚠️ **No multi-device sync** - Each device has separate data  
⚠️ **Plain text passwords** - Not secure for production  
⚠️ **Limited scalability** - SharedPreferences has size limits  
⚠️ **No cloud features** - Can't share data between users  

---

## Security Notes

### ⚠️ Important
This version stores passwords in **plain text** in SharedPreferences. This is **NOT secure** for production use.

For production, consider:
1. Using Android Keystore for sensitive data
2. Implementing proper password hashing
3. Using encrypted SharedPreferences
4. Adding biometric authentication

---

## Features Still Working

✅ Login/Registration (local)  
✅ Main map screen with Google Maps  
✅ Bottom navigation (Location, Driving, Safety)  
✅ Emergency contacts management  
✅ User profile display  
✅ Check-in and SOS buttons  
✅ Settings screen  
✅ Logout functionality  

---

## Troubleshooting

### Problem: Data lost after app restart
**Solution**: Check if SharedPreferences is being cleared. Verify `is_logged_in` flag.

### Problem: Can't login with registered account
**Solution**: 
1. Check email and password match exactly
2. Verify user was saved during registration
3. Check SharedPreferences in Android Studio Device File Explorer

### Problem: Emergency contacts not saving
**Solution**: 
1. Verify permissions are granted
2. Check SharedPreferences write operations
3. Ensure JSON serialization is working

---

## Summary

The app now runs **completely offline** with all data stored locally in SharedPreferences. No database, no server, no network calls required. Perfect for a simple, standalone mobile app!

**Note**: The XAMPP backend folder can be deleted as it's no longer needed.
