# RideAlertz MySQL Database Integration - Complete Setup Guide

## Overview
The app now uses MySQL database (via XAMPP) instead of SharedPreferences for storing emergency contacts.

---

## Part 1: XAMPP Backend Setup

### Step 1: Install XAMPP
1. Download XAMPP from https://www.apachefriends.org/
2. Install and start **Apache** and **MySQL** services

### Step 2: Create Database
1. Open phpMyAdmin: `http://localhost/phpmyadmin`
2. Click "New" to create a database
3. Name it: `ridealertz_db`
4. Click "Create"

### Step 3: Create Table
1. Select `ridealertz_db` database
2. Click "SQL" tab
3. Copy and paste the content from `xampp_backend/ridealertz_api/database.sql`
4. Click "Go" to execute

### Step 4: Copy API Files
1. Navigate to your XAMPP installation folder (usually `C:\xampp\htdocs\`)
2. Copy the entire `ridealertz_api` folder from `xampp_backend/` to `htdocs/`
3. Final path should be: `C:\xampp\htdocs\ridealertz_api\`

### Step 5: Test API
1. Open browser and go to: `http://localhost/ridealertz_api/test.php`
2. You should see: `{"success":true,"message":"API is working!","timestamp":"..."}`
3. If you see this, the backend is working correctly!

---

## Part 2: Android App Configuration

### Step 1: Sync Gradle
1. Open the project in Android Studio
2. Click "Sync Now" when prompted (or File → Sync Project with Gradle Files)
3. Wait for dependencies to download (Retrofit, OkHttp, Coroutines)

### Step 2: Configure API URL

#### For Android Emulator:
The default configuration is already set for emulator:
```kotlin
// In ApiConfig.kt
const val BASE_URL = "http://10.0.2.2/ridealertz_api/"
```
**No changes needed** if testing on emulator.

#### For Real Android Device:
1. Find your computer's IP address:
   - Open Command Prompt (CMD)
   - Type: `ipconfig`
   - Look for "IPv4 Address" under your active network adapter
   - Example: `192.168.1.100`

2. Update `ApiConfig.kt`:
   ```kotlin
   const val BASE_URL = "http://192.168.1.100/ridealertz_api/"
   ```
   Replace `192.168.1.100` with your actual IP address.

3. **Important**: Make sure your phone and computer are on the **same WiFi network**.

### Step 3: Build and Run
1. Connect your device or start emulator
2. Click "Run" (green play button) in Android Studio
3. The app will now use MySQL database for emergency contacts

---

## Part 3: How It Works

### User Identification
- Each device gets a unique `user_id` automatically
- Stored in SharedPreferences: `user_${timestamp}`
- All contacts are linked to this user_id

### API Endpoints
| Endpoint | Method | Purpose |
|----------|--------|---------|
| `get_contacts.php` | GET | Fetch all contacts for user |
| `add_contact.php` | POST | Add new contact |
| `delete_contact.php` | POST | Remove contact |
| `set_primary.php` | POST | Set contact as primary |
| `clear_all.php` | POST | Delete all contacts |

### Features
- ✅ Real-time sync with MySQL database
- ✅ Loading indicators during API calls
- ✅ Error messages for network issues
- ✅ Toast notifications for user feedback
- ✅ Manual contact entry only (no auto-add)
- ✅ Manual primary contact selection
- ✅ Clean contact names (removes parentheses)

---

## Part 4: Troubleshooting

### Problem: "Network error: Failed to connect"
**Solutions:**
1. Check if XAMPP Apache is running
2. Test API in browser: `http://localhost/ridealertz_api/test.php`
3. For real device: Verify IP address is correct
4. Check Windows Firewall (allow port 80)
5. Ensure phone and PC are on same WiFi

### Problem: "Database connection failed"
**Solutions:**
1. Verify MySQL is running in XAMPP
2. Check `config.php` credentials:
   ```php
   $username = "root";
   $password = "";  // Usually empty for XAMPP
   ```
3. Ensure database `ridealertz_db` exists

### Problem: "Failed to load contacts"
**Solutions:**
1. Check if table `emergency_contacts` exists
2. Run the SQL script from `database.sql` again
3. Check Apache error logs in XAMPP

### Problem: App crashes on contact operations
**Solutions:**
1. Check Logcat in Android Studio for errors
2. Verify all API files are in correct location
3. Test each endpoint individually in browser/Postman

---

## Part 5: Testing the Integration

### Test 1: Add Contact
1. Open Emergency Contacts screen
2. Click "+" button
3. Fill in name and phone
4. Click "Add Contact"
5. Should see "Contact added successfully" toast
6. Contact appears in list

### Test 2: Set Primary
1. Click star icon on any contact
2. Should see "Primary contact set" toast
3. Star becomes filled/gold colored

### Test 3: Delete Contact
1. Click trash icon on any contact
2. Should see "Contact removed" toast
3. Contact disappears from list

### Test 4: Verify in Database
1. Open phpMyAdmin
2. Select `ridealertz_db` → `emergency_contacts` table
3. Click "Browse"
4. You should see your contacts stored there

---

## Part 6: Database Schema

```sql
CREATE TABLE emergency_contacts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(100) NOT NULL,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    initials VARCHAR(10) NOT NULL,
    is_primary TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

---

## Part 7: Security Notes

⚠️ **For Production Use:**
1. Change database password from default
2. Use HTTPS instead of HTTP
3. Add authentication/authorization
4. Validate and sanitize all inputs
5. Use prepared statements (already implemented)
6. Add rate limiting
7. Deploy to proper web server (not XAMPP)

---

## Support

If you encounter issues:
1. Check XAMPP control panel - both Apache and MySQL should be green
2. Review Android Studio Logcat for error messages
3. Test API endpoints in browser first
4. Verify network connectivity
5. Check database tables in phpMyAdmin

---

## Summary

✅ **Backend**: PHP API running on XAMPP with MySQL database  
✅ **Frontend**: Android app using Retrofit for API calls  
✅ **Features**: Full CRUD operations with loading states and error handling  
✅ **Testing**: Use emulator with `10.0.2.2` or real device with computer's IP  

The integration is complete and ready to use!
