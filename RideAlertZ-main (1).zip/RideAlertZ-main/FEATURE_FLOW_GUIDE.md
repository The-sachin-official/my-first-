# RideAlertz - Feature Flow Guide

## 🎯 Quick Navigation Map

```
Main Screen (MainActivityNew)
    │
    ├─── [Settings Icon] ──────────► Settings Activity
    │                                      │
    │                                      ├─ Appearance
    │                                      │   └─ Dark Mode Toggle ✓
    │                                      │
    │                                      └─ Driving Mode
    │                                          ├─ Speed Limit Config
    │                                          └─ Auto-Start Dashcam
    │
    ├─── [Driving Tab] ────────────► Driving Mode Activity
    │                                      │
    │                                      ├─ Large Speed Display
    │                                      ├─ Speed Limit Alerts
    │                                      ├─ Behavior Tracking
    │                                      ├─ Dashcam Recording
    │                                      │
    │                                      └─ [End Trip] ──► Safety Score Activity
    │
    └─── [Safety Tab] ─────────────► Safety Score Activity
                                           │
                                           ├─ Current Score (0-100)
                                           ├─ Achievement Badges
                                           ├─ Current Trip Stats
                                           └─ Trip History (Last 50)
```

---

## 🚗 Driving Mode Flow

### Starting a Trip

```
User Action: Tap "Driving" Tab
    ↓
DrivingModeActivity Launches
    ↓
┌─────────────────────────────────────┐
│  Initialize Components:             │
│  ✓ DrivingBehaviorAnalyzer         │
│  ✓ Text-to-Speech Engine           │
│  ✓ SensorMonitoringService         │
│  ✓ DashcamRecorderService          │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│  Start Trip:                        │
│  • behaviorAnalyzer.startTrip()    │
│  • Reset counters                   │
│  • Start dashcam recording          │
│  • Begin GPS tracking               │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│  Monitoring Active:                 │
│  • Speed updates every 1 second     │
│  • Sensor data continuous           │
│  • Dashcam 30s rolling buffer       │
└─────────────────────────────────────┘
```

### During Trip

```
Continuous Monitoring Loop
    │
    ├─── GPS Updates ────────────────────┐
    │         │                           │
    │         ├─ Calculate Speed          │
    │         ├─ Update Distance          │
    │         └─ Check Speed Limit        │
    │                   │                 │
    │                   └─ IF EXCEEDED ───┤
    │                                     │
    ├─── Accelerometer Data ──────────────┤
    │         │                           │
    │         └─ Detect Harsh Braking     │
    │                   │                 │
    │                   └─ IF DETECTED ───┤
    │                                     │
    ├─── Gyroscope Data ──────────────────┤
    │         │                           │
    │         └─ Detect Sharp Turns       │
    │                   │                 │
    │                   └─ IF DETECTED ───┤
    │                                     │
    └─── Impact Detection ────────────────┤
              │                           │
              └─ Save Dashcam Footage     │
                                          ↓
                        ┌─────────────────────────────┐
                        │  Alert Actions:             │
                        │  1. Increment counter       │
                        │  2. Show visual warning     │
                        │  3. Speak voice alert       │
                        │  4. Update UI stats         │
                        └─────────────────────────────┘
```

### Ending Trip

```
User Action: Tap "End Trip"
    ↓
┌─────────────────────────────────────┐
│  Stop Services:                     │
│  • Stop dashcam recording           │
│  • Save final GPS location          │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│  Calculate Results:                 │
│  • Total distance                   │
│  • Trip duration                    │
│  • Average speed                    │
│  • Violation counts                 │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│  Calculate Safety Score:            │
│  Base: 100 points                   │
│  - Harsh braking × 5                │
│  - Sharp turns × 3                  │
│  - Speed violations × 10            │
│  = Final Score (0-100)              │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│  Save to History:                   │
│  • Add to trip history list         │
│  • Update total statistics          │
│  • Calculate new average            │
│  • Persist to SharedPreferences     │
└─────────────────────────────────────┘
    ↓
Launch SafeDrivingScoreActivity
    ↓
Display Results with Animation
```

---

## 📊 Score Calculation Flow

```
Trip Completed
    ↓
┌─────────────────────────────────────┐
│  Gather Trip Data:                  │
│  • Harsh Braking Count: 2           │
│  • Sharp Turn Count: 3              │
│  • Speed Violations: 1              │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│  Calculate Deductions:              │
│  • Harsh: 2 × 5 = -10 points       │
│  • Turns: 3 × 3 = -9 points        │
│  • Speed: 1 × 10 = -10 points      │
│  • Total: -29 points                │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│  Final Score:                       │
│  100 - 29 = 71 points               │
│  Rating: "Good driving!"            │
│  Badge: Bronze                      │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│  Update Statistics:                 │
│  • Total Trips: +1                  │
│  • Total Score: +71                 │
│  • Recalculate Average              │
└─────────────────────────────────────┘
```

---

## 📹 Dashcam Recording Flow

```
Dashcam Service Started
    ↓
┌─────────────────────────────────────┐
│  Initialize Camera:                 │
│  • Open back-facing camera          │
│  • Configure MediaRecorder          │
│  • Set resolution: 1920×1080        │
│  • Set frame rate: 30fps            │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│  Start Recording Segment 1:         │
│  • Duration: 10 seconds             │
│  • File: dashcam_timestamp1.mp4     │
│  • Location: /temp/                 │
└─────────────────────────────────────┘
    ↓ (10 seconds later)
┌─────────────────────────────────────┐
│  Start Recording Segment 2:         │
│  • Stop segment 1                   │
│  • Add to buffer [Seg1]             │
│  • Start new recording              │
└─────────────────────────────────────┘
    ↓ (10 seconds later)
┌─────────────────────────────────────┐
│  Start Recording Segment 3:         │
│  • Stop segment 2                   │
│  • Add to buffer [Seg1, Seg2]       │
│  • Start new recording              │
└─────────────────────────────────────┘
    ↓ (10 seconds later)
┌─────────────────────────────────────┐
│  Start Recording Segment 4:         │
│  • Stop segment 3                   │
│  • Add to buffer [Seg1, Seg2, Seg3] │
│  • DELETE Seg1 (oldest)             │
│  • Buffer now: [Seg2, Seg3]         │
│  • Start new recording              │
└─────────────────────────────────────┘
    ↓ (continues rolling...)

═══════════════════════════════════════
         IMPACT DETECTED!
═══════════════════════════════════════
    ↓
┌─────────────────────────────────────┐
│  Save Impact Footage:               │
│  • Current buffer: [Seg2, Seg3, Seg4]│
│  • Copy latest segment              │
│  • Destination: /RideAlertz_Impacts/│
│  • Filename: impact_timestamp.mp4   │
│  • Show notification                │
└─────────────────────────────────────┘
    ↓
Continue Recording (buffer preserved)
```

---

## 🎨 UI State Transitions

### Driving Mode Screen States

```
┌─────────────────────────────────────┐
│  NORMAL STATE                       │
│  ────────────────                   │
│  • Speed: White text                │
│  • Background: Black                │
│  • Dashcam: Red REC indicator       │
│  • Stats: Normal display            │
└─────────────────────────────────────┘
              │
              ├─ Speed > Limit
              ↓
┌─────────────────────────────────────┐
│  SPEED ALERT STATE                  │
│  ──────────────────                 │
│  • Speed: Red text (pulsing)        │
│  • Warning banner: Animated         │
│  • Voice: "Speed limit exceeded"    │
│  • Violation counter: +1            │
└─────────────────────────────────────┘
              │
              ├─ Speed < Limit
              ↓
Return to NORMAL STATE

              │
              ├─ Harsh Braking Detected
              ↓
┌─────────────────────────────────────┐
│  BEHAVIOR ALERT STATE               │
│  ─────────────────────              │
│  • Harsh braking counter: +1        │
│  • Voice: "Warning: Harsh braking"  │
│  • Visual feedback (brief)          │
└─────────────────────────────────────┘
              │
              ↓
Return to NORMAL STATE
```

### Score Screen States

```
Screen Loads
    ↓
┌─────────────────────────────────────┐
│  LOADING STATE                      │
│  • Score: 0 (initial)               │
│  • Circle: Empty                    │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│  ANIMATING STATE (1 second)         │
│  • Score: 0 → 71 (animated)         │
│  • Circle: Fills progressively      │
│  • Color: Transitions to orange     │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│  FINAL STATE                        │
│  • Score: 71 (static)               │
│  • Circle: 71% filled, orange       │
│  • Description: "Good driving!"     │
│  • Badges: Displayed                │
│  • History: Scrollable list         │
└─────────────────────────────────────┘
```

---

## 🔄 Data Persistence Flow

```
Trip Completed
    ↓
┌─────────────────────────────────────┐
│  Create DrivingSession Object:     │
│  {                                  │
│    timestamp: 1705147200000,        │
│    duration: 25,                    │
│    distance: 12.5,                  │
│    safetyScore: 71,                 │
│    harshBraking: 2,                 │
│    sharpTurns: 3,                   │
│    speedViolations: 1,              │
│    averageSpeed: 45.2               │
│  }                                  │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│  Load Existing History:             │
│  • Read "driving_history" JSON      │
│  • Deserialize to List              │
│  • Current count: 15 trips          │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│  Add New Session:                   │
│  • Append to list                   │
│  • New count: 16 trips              │
│  • Check limit (max 50)             │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│  Serialize and Save:                │
│  • Convert to JSON string           │
│  • Save to SharedPreferences        │
│  • Key: "driving_history"           │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│  Update Totals:                     │
│  • total_trips: 15 → 16             │
│  • total_score: 1200 → 1271         │
│  • average_score: 80 → 79           │
└─────────────────────────────────────┘
    ↓
Data Persisted ✓
```

---

## 🎯 Feature Integration Points

```
┌─────────────────────────────────────────────────────┐
│              SensorMonitoringService                │
│  (Always Running in Background)                     │
└─────────────────────────────────────────────────────┘
                        │
        ┌───────────────┼───────────────┐
        │               │               │
        ↓               ↓               ↓
┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│ Accelerometer│ │  Gyroscope   │ │     GPS      │
└──────────────┘ └──────────────┘ └──────────────┘
        │               │               │
        └───────────────┼───────────────┘
                        ↓
        ┌───────────────────────────────┐
        │  DrivingBehaviorAnalyzer      │
        │  • analyzeAccelerometer()     │
        │  • analyzeGyroscope()         │
        │  • updateLocation()           │
        └───────────────────────────────┘
                        │
        ┌───────────────┼───────────────┐
        │               │               │
        ↓               ↓               ↓
┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│Voice Alerts  │ │  UI Updates  │ │Score Tracking│
└──────────────┘ └──────────────┘ └──────────────┘
```

---

## 🚀 Startup Sequence

```
App Launch (MainActivityNew)
    ↓
┌─────────────────────────────────────┐
│  1. Load Preferences                │
│     • dark_mode                     │
│     • user_name                     │
│     • last_location                 │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│  2. Request Permissions             │
│     • Location (Fine/Coarse)        │
│     • Camera                        │
│     • Record Audio                  │
│     • SMS, Phone                    │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│  3. Start Background Service        │
│     • SensorMonitoringService       │
│     • Initialize sensors            │
│     • Start location updates        │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│  4. Display Main Screen             │
│     • Show map                      │
│     • Display user info             │
│     • Enable navigation             │
└─────────────────────────────────────┘
    ↓
Ready for User Interaction
```

---

## 📱 Screen Hierarchy

```
RideAlertz App
│
├─ LoginActivity (Entry Point)
│   └─ On Success → MainActivityNew
│
├─ MainActivityNew (Home)
│   ├─ Map View
│   ├─ Bottom Navigation
│   │   ├─ Location Tab
│   │   ├─ Driving Tab → DrivingModeActivity
│   │   └─ Safety Tab → SafeDrivingScoreActivity
│   └─ Settings Button → SettingsActivity
│
├─ DrivingModeActivity
│   ├─ Speed Display
│   ├─ Stats Panel
│   └─ End Trip → SafeDrivingScoreActivity
│
├─ SafeDrivingScoreActivity
│   ├─ Score Circle
│   ├─ Achievements
│   ├─ Current Stats
│   └─ History List
│
└─ SettingsActivity
    ├─ Appearance (Dark Mode)
    ├─ Driving Mode (Speed Limit)
    ├─ Emergency Contacts
    └─ Monitoring Settings
```

---

**This guide provides a visual representation of how all features interconnect and flow through the application.**
