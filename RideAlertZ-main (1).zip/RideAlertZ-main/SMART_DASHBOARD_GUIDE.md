# RideAlertz - Smart Dashboard Guide

## 🎯 Overview

The Smart Dashboard is the main screen of RideAlertz, providing a comprehensive, at-a-glance view of all critical information and quick access to key features.

---

## 📱 Dashboard Components

### 1. ✅ App Logo + Name (RideAlertz)

**Location**: Top of Dashboard Header Card

**Features**:
- **Gradient Logo**: Purple-to-indigo gradient circle with car icon
- **App Name**: "RideAlertz" in bold 24sp font
- **Tagline**: "Smart Safety System" subtitle
- **Settings Icon**: Quick access to app settings

**Visual Design**:
```
┌─────────────────────────────────────┐
│  🚗 RideAlertz        ⚙️            │
│     Smart Safety System             │
└─────────────────────────────────────┘
```

---

### 2. 🛰️ Live GPS Location

**Location**: GPS Location Card (below header)

**Features**:
- **Real-time Coordinates**: Displays latitude and longitude
- **GPS Icon**: Animated GPS indicator
- **Signal Status**: Green/Red dot showing GPS signal strength
- **Auto-refresh**: Updates continuously with location changes

**Display Format**:
```
🛰️ Live GPS Location
11.0168, 76.9558
● (Green = Active, Red = No Signal)
```

**Implementation**:
- Uses `FusedLocationProviderClient` for accurate location
- Formats coordinates to 4 decimal places
- Shows "Fetching location..." while loading
- Displays "Location permission required" if denied

---

### 3. 📶 Connection Status (Online/Offline)

**Location**: Dashboard Header - Status Chips

**Features**:
- **Real-time Monitoring**: Checks network connectivity every second
- **Visual Indicators**:
  - 📶 WiFi icon (green) = Online
  - 📵 WiFi Off icon (red) = Offline
- **Color Coding**:
  - Green = Connected to internet
  - Red = No internet connection

**Status Chips Display**:
```
┌──────────────────────────────────┐
│ 👤 User    🕐 09:06 PM          │
│ 📶 Online  🔋 85%               │
└──────────────────────────────────┘
```

**Additional Status Info**:
- **User Name**: Current logged-in user
- **Current Time**: Updates every second (hh:mm AM/PM format)
- **Battery Level**: Color-coded battery percentage
  - Green (>50%)
  - Orange (20-50%)
  - Red (<20%)

---

### 4. 🚗 Start Ride / Enable Detection Button

**Location**: Large button below GPS card

**Features**:
- **Two States**:
  1. **Inactive (Green)**: "🚗 Start Ride / Enable Detection"
  2. **Active (Red)**: "🚗 Ride Active - Detection ON"
- **Pulsing Animation**: When active, shows pulsing white dot
- **One-Tap Control**: Toggle ride monitoring on/off
- **Service Management**: Starts/stops SensorMonitoringService

**Visual States**:

**Inactive State**:
```
┌─────────────────────────────────────┐
│  ▶️  🚗 Start Ride / Enable Detection│
│     Activates crash detection sensors│
└─────────────────────────────────────┘
```

**Active State**:
```
┌─────────────────────────────────────┐
│  ⚪ 🚗 Ride Active - Detection ON   │
│     Tap to stop monitoring          │
└─────────────────────────────────────┘
```

**What It Does**:
- ✅ Activates accelerometer monitoring
- ✅ Activates gyroscope monitoring
- ✅ Enables crash detection algorithms
- ✅ Starts location tracking
- ✅ Enables automatic emergency alerts

---

### 5. 🧭 Live Map View

**Location**: Center of dashboard (300dp height)

**Features**:
- **Google Maps Integration**: Full interactive map
- **Current Location Marker**: "You are here" pin
- **Auto-centering**: Camera follows your location
- **Zoom Level**: 15x zoom for optimal view
- **Overlay Label**: "🧭 Live Location" badge

**Map Display**:
```
┌─────────────────────────────────────┐
│ 🧭 Live Location                    │
│                                     │
│         [Interactive Map]           │
│              📍 You                 │
│                                     │
└─────────────────────────────────────┘
```

**Interactions**:
- Pinch to zoom
- Drag to pan
- Tap marker for info
- Auto-updates with GPS

---

### 6. ❤️ Health Data Widget

**Location**: Below map view

**Features**:
- **Heart Rate Monitor**: Displays BPM (beats per minute)
- **SpO₂ Sensor**: Shows blood oxygen saturation percentage
- **Wearable Integration**: Ready for smartwatch/fitness tracker connection
- **Status Indicators**: Shows connection status

**Widget Layout**:
```
┌─────────────────────────────────────┐
│ ❤️ Health Data                      │
│                                     │
│   💓              🫁                │
│   -- bpm          --%               │
│   Heart Rate      SpO₂             │
│   Not connected   Not connected    │
│                                     │
│ Connect a wearable device to       │
│ monitor health metrics             │
└─────────────────────────────────────┘
```

**Future Integration**:
- Bluetooth wearable pairing
- Real-time health monitoring
- Abnormal heart rate alerts
- Fatigue detection based on vitals

---

### 7. 🆘 Big SOS Button

**Location**: Prominent position in middle-lower section

**Features**:
- **Extra Large Size**: 80dp icon with pulsing scale animation
- **High Visibility**: Bright red (#DC2626) background
- **Pulsing Effect**: Continuously animates to draw attention
- **One-Tap Emergency**: Instant emergency alert activation
- **Clear Labeling**: "🆘 EMERGENCY SOS" in 28sp bold text

**Button Design**:
```
┌─────────────────────────────────────┐
│                                     │
│           ⚠️                        │
│      (Pulsing Circle)               │
│                                     │
│     🆘 EMERGENCY SOS                │
│                                     │
│  Tap for immediate emergency       │
│  assistance                         │
│                                     │
└─────────────────────────────────────┘
```

**What Happens When Pressed**:
1. Launches `CrashAlertActivity`
2. Sends SMS to emergency contacts
3. Shares current GPS location
4. Triggers emergency call option
5. Saves dashcam footage (if active)

**Safety Features**:
- No confirmation dialog (immediate action)
- Works even without ride active
- Visible in all lighting conditions
- Large touch target for easy access

---

### 8. 🔔 Notification Panel

**Location**: Bottom of dashboard

**Features**:
- **Safety Tips**: Rotating driving safety advice
- **Horizontal Scroll**: Swipe through multiple tips
- **Color-Coded Chips**: Easy-to-read pill-shaped badges
- **Educational Content**: Promotes safe driving habits

**Panel Layout**:
```
┌─────────────────────────────────────┐
│ 🔔 Safety Tips & Alerts             │
│                                     │
│ ← [Tip 1] [Tip 2] [Tip 3] →       │
└─────────────────────────────────────┘
```

**Current Tips**:
1. 💡 Maintain safe following distance
2. 🚦 Always obey traffic signals
3. 👀 Check mirrors regularly
4. ⚠️ Avoid distractions while driving
5. 🌙 Use headlights in low visibility
6. 🛑 Never drink and drive

**Future Enhancements**:
- Personalized tips based on driving behavior
- Weather-based alerts
- Traffic condition warnings
- Maintenance reminders

---

## 🎨 Quick Actions Row

**Location**: Below SOS button

**Features**: Two quick-access cards for main features

### Card 1: Driving Mode
- **Icon**: 🚗 Car icon
- **Title**: "Driving Mode"
- **Subtitle**: "Hands-free"
- **Color**: Purple (#6366F1)
- **Action**: Launches full-screen driving interface

### Card 2: Safety Score
- **Icon**: ⭐ Star icon
- **Title**: "Safety Score"
- **Subtitle**: "View stats"
- **Color**: Orange (#F59E0B)
- **Action**: Shows driving score and history

**Layout**:
```
┌──────────────────┐  ┌──────────────────┐
│   🚗             │  │   ⭐             │
│ Driving Mode     │  │ Safety Score     │
│ Hands-free       │  │ View stats       │
└──────────────────┘  └──────────────────┘
```

---

## 🎯 User Flow

### Opening the App

```
App Launch
    ↓
Login Screen (if not logged in)
    ↓
Smart Dashboard Loads
    ↓
┌─────────────────────────────────────┐
│ 1. Header with logo & status        │
│ 2. GPS location fetching            │
│ 3. Connection check                 │
│ 4. Map loading                      │
│ 5. All widgets rendered             │
└─────────────────────────────────────┘
    ↓
Ready for User Interaction
```

### Starting a Ride

```
User taps "Start Ride" button
    ↓
Button turns RED with pulsing indicator
    ↓
SensorMonitoringService starts
    ↓
┌─────────────────────────────────────┐
│ ✅ Accelerometer monitoring         │
│ ✅ Gyroscope monitoring             │
│ ✅ GPS tracking                     │
│ ✅ Crash detection active           │
│ ✅ Emergency alerts enabled         │
└─────────────────────────────────────┘
    ↓
User can now drive safely
```

### Triggering Emergency

```
User taps BIG SOS BUTTON
    ↓
Immediate Actions:
    ↓
┌─────────────────────────────────────┐
│ 1. Launch CrashAlertActivity        │
│ 2. Get current GPS location         │
│ 3. Send SMS to emergency contacts   │
│ 4. Show emergency call options      │
│ 5. Save dashcam footage             │
└─────────────────────────────────────┘
```

---

## 🎨 Design Specifications

### Color Scheme

**Primary Colors**:
- Purple: `#6366F1` - Main brand color
- Green: `#10B981` - Success, active states
- Red: `#EF4444` - Danger, emergency, alerts
- Orange: `#F59E0B` - Warnings, moderate priority

**Status Colors**:
- Online: Green `#10B981`
- Offline: Red `#EF4444`
- Battery High: Green `#10B981`
- Battery Medium: Orange `#F59E0B`
- Battery Low: Red `#EF4444`

### Typography

**Font Sizes**:
- App Name: 24sp (Bold)
- Section Headers: 16sp (Bold)
- Body Text: 14sp (Regular)
- Status Chips: 12sp (Medium)
- Subtitles: 11-12sp (Regular)
- SOS Button: 28sp (ExtraBold)

**Font Weights**:
- Bold: 700
- SemiBold: 600
- Medium: 500
- Regular: 400

### Spacing

**Padding**:
- Card Padding: 16dp
- Content Padding: 20dp
- Chip Padding: 8-12dp horizontal, 6-8dp vertical
- Section Spacing: 8dp vertical

**Corner Radius**:
- Cards: 16-20dp
- Buttons: 20-24dp
- Chips: 12dp
- Circles: 50% (CircleShape)

### Elevation

**Shadow Depths**:
- Header Card: 6dp
- Regular Cards: 2-4dp
- SOS Button: 12dp
- Floating Elements: 8dp

---

## 🔄 Real-time Updates

### Auto-Refresh Components

**Every Second**:
- ⏰ Current time display
- 📶 Network connectivity status

**On Location Change**:
- 🛰️ GPS coordinates
- 🗺️ Map camera position
- 📍 Location marker

**On State Change**:
- 🚗 Ride active/inactive status
- 🔋 Battery level
- ❤️ Health metrics (when connected)

---

## 📊 Data Display

### Status Information

**Always Visible**:
- User name
- Current time
- Connection status
- Battery level
- GPS coordinates
- Ride status

**Conditionally Visible**:
- Health metrics (when device connected)
- Alerts (when triggered)
- Notifications (when available)

---

## 🎯 Accessibility Features

### Touch Targets

**Minimum Sizes**:
- SOS Button: 80dp icon + padding = ~150dp total
- Quick Action Cards: 100dp height
- Status Chips: 40dp height
- Settings Icon: 48dp

### Visual Feedback

**Interactions**:
- Button press: Ripple effect
- Card tap: Elevation change
- Toggle: Color transition
- Loading: Shimmer/pulse animation

### Color Contrast

**WCAG Compliance**:
- Text on backgrounds: 4.5:1 minimum
- Icons on backgrounds: 3:1 minimum
- Status indicators: High contrast colors

---

## 🚀 Performance Optimizations

### Efficient Updates

**LaunchedEffect**:
- Time updates: 1-second intervals
- Location updates: On GPS change only
- Network checks: Cached with 1-second refresh

**Lazy Loading**:
- Map: Loads on demand
- Tips: Horizontal lazy list
- Images: Async loading

### Memory Management

**State Management**:
- `remember` for UI state
- `mutableStateOf` for reactive updates
- Proper cleanup in `LaunchedEffect`

---

## 🔧 Technical Implementation

### Key Components

**Composables**:
1. `SmartDashboardScreen` - Main container
2. `DashboardHeader` - Logo and status
3. `LocationCard` - GPS display
4. `RideControlButton` - Start/stop ride
5. `HealthDataWidget` - Health metrics
6. `BigSOSButton` - Emergency trigger
7. `QuickActionsRow` - Feature shortcuts
8. `NotificationPanel` - Tips and alerts

**Helper Functions**:
- `isNetworkAvailable()` - Check connectivity
- `getCurrentTime()` - Format current time
- `getBatteryLevel()` - Get battery percentage

**Services**:
- `SensorMonitoringService` - Background monitoring
- `FusedLocationProviderClient` - GPS tracking

---

## 📱 Screen States

### Loading State
```
┌─────────────────────────────────────┐
│ RideAlertz                          │
│ Loading...                          │
│ Fetching location...                │
│ [Shimmer Animation]                 │
└─────────────────────────────────────┘
```

### Normal State
```
┌─────────────────────────────────────┐
│ ✅ All data loaded                  │
│ ✅ GPS active                       │
│ ✅ Online                           │
│ ✅ Ready to use                     │
└─────────────────────────────────────┘
```

### Ride Active State
```
┌─────────────────────────────────────┐
│ 🚗 Ride Active - Detection ON       │
│ ✅ Monitoring sensors               │
│ ✅ Tracking location                │
│ ✅ Emergency ready                  │
└─────────────────────────────────────┘
```

### Offline State
```
┌─────────────────────────────────────┐
│ ⚠️ Offline Mode                     │
│ 📵 No internet connection           │
│ ✅ GPS still works                  │
│ ⚠️ Limited features                 │
└─────────────────────────────────────┘
```

---

## 🎯 Best Practices

### For Users

**Before Starting a Ride**:
1. ✅ Check GPS signal (green dot)
2. ✅ Verify online status
3. ✅ Ensure battery >20%
4. ✅ Tap "Start Ride" button
5. ✅ Confirm sensors active

**During a Ride**:
1. 🚗 Keep app in background (monitoring continues)
2. 📱 Don't force-close the app
3. 🔋 Keep device charged
4. 🆘 Know where SOS button is

**In Emergency**:
1. 🆘 Tap BIG SOS BUTTON immediately
2. 📞 Follow emergency call prompts
3. 📍 Share location with responders

### For Developers

**Code Organization**:
- Separate composables for each widget
- Reusable components (StatusChip, etc.)
- Clear function naming
- Proper state management

**Performance**:
- Minimize recompositions
- Use `remember` appropriately
- Lazy load heavy components
- Optimize animations

**Testing**:
- Test all button interactions
- Verify GPS accuracy
- Check offline behavior
- Test emergency flows

---

## 📝 Future Enhancements

### Planned Features

**Phase 1**:
- [ ] Weather widget
- [ ] Traffic alerts
- [ ] Fuel/charge level indicator
- [ ] Trip history quick view

**Phase 2**:
- [ ] Voice commands
- [ ] Gesture controls
- [ ] Customizable dashboard
- [ ] Widget reordering

**Phase 3**:
- [ ] AI-powered tips
- [ ] Predictive alerts
- [ ] Social features
- [ ] Gamification elements

---

## 🆘 Troubleshooting

### Common Issues

**GPS Not Working**:
- Check location permissions
- Enable high-accuracy mode
- Restart app
- Check device GPS settings

**Offline Status**:
- Check WiFi/mobile data
- Verify airplane mode off
- Restart network connection

**Ride Won't Start**:
- Check all permissions granted
- Verify battery saver off
- Restart app
- Clear app cache

**SOS Button Not Responding**:
- Check emergency contacts set
- Verify SMS permission
- Test with non-emergency tap
- Contact support

---

**Last Updated**: January 13, 2025  
**Version**: 2.0 - Smart Dashboard Release  
**Status**: ✅ Production Ready
