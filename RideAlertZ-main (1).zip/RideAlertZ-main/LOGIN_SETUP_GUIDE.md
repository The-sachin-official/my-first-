# RideAlertz Login System & New UI - Setup Guide

## Overview
The app now includes:
- **Login/Registration System** with MySQL database
- **New Main Screen** with Google Maps, matching your design
- **Bottom Navigation**: Location, Driving, Safety tabs (Membership removed)
- **User Profile** with name and battery status
- **Check-in and SOS buttons**

---

## Part 1: Database Setup

### Step 1: Create Users Table
1. Open phpMyAdmin: `http://localhost/phpmyadmin`
2. Select `ridealertz_db` database
3. Click "SQL" tab
4. Run the SQL from `xampp_backend/ridealertz_api/users_table.sql`:

```sql
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### Step 2: Verify API Files
Ensure these files exist in `C:\xampp\htdocs\ridealertz_api\`:
- ✅ `config.php`
- ✅ `login.php`
- ✅ `register.php`
- ✅ `get_contacts.php`
- ✅ `add_contact.php`
- ✅ `delete_contact.php`
- ✅ `set_primary.php`
- ✅ `clear_all.php`
- ✅ `test.php`

### Step 3: Test Login API
Open browser: `http://localhost/ridealertz_api/test.php`

Should see: `{"success":true,"message":"API is working!","timestamp":"..."}`

---

## Part 2: Android App Setup

### Step 1: Sync Gradle
1. Open project in Android Studio
2. Click "Sync Now" when prompted
3. New dependencies will download:
   - Retrofit (API calls)
   - Google Maps Compose
   - Coroutines

### Step 2: Add Google Maps API Key
1. Get API key from [Google Cloud Console](https://console.cloud.google.com/)
2. Enable "Maps SDK for Android"
3. Open `AndroidManifest.xml`
4. Replace `YOUR_GOOGLE_MAPS_API_KEY` with your actual key:

```xml
<meta-data
    android:name="com.google.android.geo.API_KEY"
    android:value="YOUR_ACTUAL_API_KEY_HERE" />
```

### Step 3: Configure API URL
In `app/src/main/java/com/example/ridealertz/network/ApiConfig.kt`:

**For Emulator:**
```kotlin
const val BASE_URL = "http://10.0.2.2/ridealertz_api/"
```

**For Real Device:**
```kotlin
const val BASE_URL = "http://YOUR_COMPUTER_IP/ridealertz_api/"
```

---

## Part 3: App Flow

### 1. Login Screen (First Launch)
- **Fields**: Email, Password
- **Actions**: 
  - Login button → Validates credentials with MySQL
  - "Sign Up" link → Switches to registration

### 2. Registration Screen
- **Fields**: Full Name, Email, Phone (optional), Password
- **Actions**:
  - Sign Up button → Creates account in MySQL
  - "Login" link → Switches back to login
  - After successful registration → Returns to login screen

### 3. Main Map Screen (After Login)
**Top Bar:**
- Group selector: "G Family" dropdown
- Notification icon with badge (21)
- Messages icon

**Map Area:**
- Google Maps showing current location
- Settings button (top left)
- User marker on map

**Action Buttons:**
- **Check in** button (purple)
- **SOS** button (red)

**Bottom Navigation (3 tabs):**
- 📍 **Location** - Current location tracking
- 🚗 **Driving** - Driving mode features
- 🛡️ **Safety** - Safety features and emergency contacts

**User Profile Section (Bottom):**
- Profile avatar with initial
- User name
- Battery status indicator
- Warning icon

---

## Part 4: Features Implemented

### ✅ Authentication
- Secure password hashing (bcrypt)
- Email validation
- Duplicate email prevention
- Session management with SharedPreferences
- Auto-login if already logged in

### ✅ Main Screen UI
- Google Maps integration
- Bottom navigation (Location, Driving, Safety)
- **Membership tab removed** as requested
- Check-in and SOS buttons
- User profile display
- Battery level indicator
- Group selector
- Notifications badge

### ✅ Navigation
- Settings screen
- Emergency Contacts screen
- Profile screen (placeholder)
- Logout functionality

---

## Part 5: Testing the App

### Test 1: Registration
1. Launch app
2. Click "Sign Up"
3. Fill in:
   - Name: "John Doe"
   - Email: "john@example.com"
   - Phone: "+1234567890" (optional)
   - Password: "password123"
4. Click "Sign Up"
5. Should see success message
6. Verify in phpMyAdmin → `users` table

### Test 2: Login
1. Enter registered email and password
2. Click "Login"
3. Should navigate to main map screen
4. Your name should appear at bottom

### Test 3: Auto-Login
1. Close app completely
2. Reopen app
3. Should skip login and go directly to map screen

### Test 4: Logout
1. From main screen, tap Settings
2. Find logout option
3. Tap logout
4. Should return to login screen

### Test 5: Bottom Navigation
1. Tap "Location" tab → Shows location features
2. Tap "Driving" tab → Shows driving features
3. Tap "Safety" tab → Shows safety features
4. **Verify**: No "Membership" tab exists

---

## Part 6: UI Components

### Top Bar
```
[⚙️ G Family ▼]                    [🔔21] [💬]
```

### Action Buttons
```
[📍 Check in]  [⚠️ SOS]
```

### Bottom Navigation
```
[📍 Location]  [🚗 Driving]  [🛡️ Safety]
```

### Profile Section
```
[K] KISHORE 📶
    Battery saver on
    Since 11:44 am          [⚠️]
```

---

## Part 7: Database Schema

### Users Table
```sql
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### Emergency Contacts Table (Already exists)
```sql
CREATE TABLE emergency_contacts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id VARCHAR(100) NOT NULL,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    initials VARCHAR(10) NOT NULL,
    is_primary TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

---

## Part 8: API Endpoints

### Authentication
| Endpoint | Method | Purpose |
|----------|--------|---------|
| `register.php` | POST | Create new user account |
| `login.php` | POST | Authenticate user |

### Emergency Contacts
| Endpoint | Method | Purpose |
|----------|--------|---------|
| `get_contacts.php` | GET | Fetch all contacts |
| `add_contact.php` | POST | Add new contact |
| `delete_contact.php` | POST | Remove contact |
| `set_primary.php` | POST | Set primary contact |
| `clear_all.php` | POST | Delete all contacts |

---

## Part 9: Troubleshooting

### Problem: "Network error" on login
**Solutions:**
1. Check XAMPP Apache is running
2. Test API: `http://localhost/ridealertz_api/test.php`
3. Verify `ApiConfig.kt` has correct URL
4. For real device: Check IP address and WiFi

### Problem: "Email already registered"
**Solutions:**
1. Use different email
2. Or delete from database:
   ```sql
   DELETE FROM users WHERE email = 'your@email.com';
   ```

### Problem: Map not showing
**Solutions:**
1. Verify Google Maps API key is correct
2. Enable "Maps SDK for Android" in Google Cloud Console
3. Check location permissions are granted
4. Ensure device has internet connection

### Problem: App crashes on launch
**Solutions:**
1. Sync Gradle files
2. Check all dependencies downloaded
3. Clean and rebuild project
4. Check Logcat for error messages

---

## Part 10: Next Steps

### Implement Tab Content
Currently tabs are placeholders. You can add:
- **Location Tab**: Live location tracking, location history
- **Driving Tab**: Trip recording, driving statistics
- **Safety Tab**: Emergency contacts, safety settings

### Add Profile Screen
Create `ProfileActivity.kt` with:
- User information display
- Edit profile
- Change password
- App settings
- Logout button

### Enhance Features
- Real-time GPS location updates
- Group management (G Family dropdown)
- Notifications system
- Messaging system
- Check-in functionality
- Enhanced SOS features

---

## Summary

✅ **Login System**: Complete with MySQL backend  
✅ **Registration**: Email validation, password hashing  
✅ **Main UI**: Matches your design screenshot  
✅ **Bottom Tabs**: Location, Driving, Safety (no Membership)  
✅ **User Profile**: Name and battery status displayed  
✅ **Action Buttons**: Check-in and SOS  
✅ **Google Maps**: Integrated and ready  

The app is now ready to use with login authentication and the new UI design!
