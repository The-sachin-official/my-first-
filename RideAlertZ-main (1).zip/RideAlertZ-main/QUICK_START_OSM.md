# 🚀 Quick Start: OpenStreetMap Integration

## ⚡ 5-Minute Setup

### 1. Add to Your Activity

```kotlin
class YourActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize OSM (required)
        OSMMapUtils.initializeOSM(this)
        
        setContent {
            YourTheme {
                OSMMapView(
                    modifier = Modifier.fillMaxSize(),
                    initialLocation = GeoPoint(28.6139, 77.2090),
                    initialZoom = 15.0
                )
            }
        }
    }
}
```

### 2. Add Lifecycle Methods

```kotlin
private var mapView: MapView? = null

override fun onResume() {
    super.onResume()
    mapView?.onResume()
}

override fun onPause() {
    super.onPause()
    mapView?.onPause()
}

override fun onDestroy() {
    super.onDestroy()
    mapView?.onDetach()
}
```

### 3. Request Location Permission

```kotlin
private val locationPermissionLauncher = registerForActivityResult(
    ActivityResultContracts.RequestPermission()
) { isGranted ->
    if (isGranted) {
        // Permission granted
    }
}

// Request permission
locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
```

## 📍 Common Use Cases

### Show User Location

```kotlin
OSMMapView(
    modifier = Modifier.fillMaxSize(),
    showLocationButton = true,
    onMapReady = { map ->
        // Map automatically shows user location
    }
)
```

### Add Custom Markers

```kotlin
val markers = listOf(
    MapMarker(
        position = GeoPoint(28.6139, 77.2090),
        title = "My Location",
        snippet = "This is where I am"
    )
)

OSMMapView(
    modifier = Modifier.fillMaxSize(),
    markers = markers
)
```

### Draw a Route

```kotlin
val route = listOf(
    GeoPoint(28.6139, 77.2090),
    GeoPoint(28.6200, 77.2150),
    GeoPoint(28.6300, 77.2200)
)

OSMMapView(
    modifier = Modifier.fillMaxSize(),
    routePoints = route
)
```

### Calculate Distance

```kotlin
val point1 = GeoPoint(28.6139, 77.2090)
val point2 = GeoPoint(28.7041, 77.1025)

val distance = OSMMapUtils.calculateDistance(point1, point2)
val formatted = OSMMapUtils.formatDistance(distance) // "12.34 km"

// Or use extension function
val distance2 = point1.distanceTo(point2)
```

### Share Location

```kotlin
val location = GeoPoint(28.6139, 77.2090)
OSMMapUtils.shareLocation(context, location, "Meet me here!")
```

### Open in External Map

```kotlin
val location = GeoPoint(28.6139, 77.2090)
OSMMapUtils.openInExternalMap(context, location, "My Location")
```

## 🎨 Customization

### Change Map Type

```kotlin
// In your composable
var mapType by remember { mutableStateOf(MapType.STANDARD) }

// Switch map types
mapType = MapType.SATELLITE  // Satellite view
mapType = MapType.TERRAIN    // Terrain view
mapType = MapType.STANDARD   // Standard view
```

### Control Zoom

```kotlin
OSMMapView(
    initialZoom = 15.0,  // 1-20, higher = more zoomed in
    onMapReady = { map ->
        map.controller.zoomIn()   // Zoom in
        map.controller.zoomOut()  // Zoom out
        map.controller.setZoom(18.0)  // Set specific zoom
    }
)
```

### Animate to Location

```kotlin
OSMMapView(
    onMapReady = { map ->
        val newLocation = GeoPoint(28.6139, 77.2090)
        map.animateToLocation(newLocation, zoom = 16.0)
    }
)
```

## 🗺️ Pre-defined Locations

```kotlin
// Use pre-defined Indian cities
OSMMapView(
    initialLocation = OSMMapUtils.IndianCities.DELHI,
    initialZoom = 12.0
)

// Available cities:
// DELHI, MUMBAI, BANGALORE, HYDERABAD, CHENNAI,
// KOLKATA, PUNE, AHMEDABAD, JAIPUR, LUCKNOW
```

## 🔧 Utility Functions

```kotlin
// Distance calculation
val distance = point1.distanceTo(point2)

// Bearing (direction)
val bearing = point1.bearingTo(point2)

// Check if within radius
val isNear = point1.isWithinRadius(center, 1000.0) // 1km radius

// Format coordinates
val formatted = point.format() // "28.613900, 77.209000"

// Get center of multiple points
val center = OSMMapUtils.getCenterPoint(listOfPoints)

// Zoom to show all points
OSMMapUtils.zoomToShowAllPoints(mapView, listOfPoints)
```

## 📱 Activities Available

### 1. MapActivity
Enhanced map with all features:
```kotlin
startActivity(Intent(this, MapActivity::class.java))
```

### 2. OSMDemoActivity
Demo showcasing all features:
```kotlin
startActivity(Intent(this, OSMDemoActivity::class.java))
```

## ✅ Checklist

- [x] osmdroid dependency added (6.1.18)
- [x] Permissions configured in manifest
- [x] OSM initialized in activity
- [x] Lifecycle methods implemented
- [x] Location permission requested
- [x] Map view added to UI

## 🎯 Testing

1. Run the app
2. Grant location permission
3. See your location on the map
4. Try zoom controls
5. Test "My Location" button
6. Switch map types
7. Add custom markers
8. Draw routes

## 💡 Tips

- **No API Key Needed** - Just use it!
- **Free Forever** - No billing, no limits
- **Offline Support** - Tiles are cached automatically
- **Performance** - Call lifecycle methods properly
- **Customization** - Full control over map appearance

## 🐛 Troubleshooting

### Map not showing?
- Check internet connection
- Verify permissions in manifest
- Initialize OSM configuration
- Call lifecycle methods

### Location not updating?
- Request location permission
- Check GPS is enabled
- Verify location services are on

### Tiles not loading?
- Check internet connection
- Verify INTERNET permission
- Try different tile source

## 📚 More Examples

See `OSM_INTEGRATION_GUIDE.md` for detailed documentation.

## 🎉 You're Ready!

Start using OpenStreetMap in your app with zero configuration and zero cost! 🗺️✨
