# 🚀 How to Run RideAlertz - Complete Beginner Guide

## 📋 Prerequisites (What You Need)

1. **Android Studio** - Latest version (Hedgehog or newer)
2. **Google Account** - For Firebase
3. **Android Phone** - For testing (emulator won't work well for sensors)
4. **Internet Connection** - For Firebase setup

---

## 🔥 PART 1: Firebase Setup (10 minutes)

### Step 1: Create Firebase Project

1. **Open Firebase Console**
   - Go to: https://console.firebase.google.com/
   - Click **"Go to Console"** (top right)
   - Sign in with your Google account

2. **Create New Project**
   - Click **"Add project"** or **"Create a project"**
   - Enter project name: **RideAlertz**
   - Click **"Continue"**

3. **Disable Google Analytics** (Optional)
   - Toggle OFF "Enable Google Analytics"
   - Click **"Create project"**
   - Wait 30 seconds for project creation
   - Click **"Continue"**

### Step 2: Add Android App to Firebase

1. **Add Android App**
   - In Firebase Console, click the **Android icon** (🤖)
   - Or click **"Add app"** → Select **Android**

2. **Register App**
   - **Android package name**: `com.example.ridealertz`
   - **App nickname**: `RideAlertz` (optional)
   - **Debug signing certificate**: Leave blank for now
   - Click **"Register app"**

3. **Download Config File**
   - Click **"Download google-services.json"**
   - **IMPORTANT**: Save this file, you'll need it!
   - Click **"Next"** → **"Next"** → **"Continue to console"**

### Step 3: Enable Firebase Services

#### A. Enable Realtime Database

1. In Firebase Console, click **"Build"** (left sidebar)
2. Click **"Realtime Database"**
3. Click **"Create Database"**
4. **Choose location**: 
   - Select **"United States (us-central1)"** or closest to you
   - Click **"Next"**
5. **Security rules**: 
   - Select **"Start in test mode"** (for development)
   - Click **"Enable"**
6. Wait for database creation (30 seconds)

#### B. Enable Authentication

1. In Firebase Console, click **"Build"** → **"Authentication"**
2. Click **"Get started"**
3. Click **"Sign-in method"** tab
4. Enable **"Email/Password"**:
   - Click on "Email/Password"
   - Toggle **"Enable"**
   - Click **"Save"**
5. (Optional) Enable **"Phone"** for SMS verification

#### C. Cloud Messaging (Already Enabled)
- Cloud Messaging is enabled by default
- No action needed!

---

## 💻 PART 2: Android Studio Setup (5 minutes)

### Step 1: Open Project in Android Studio

1. **Launch Android Studio**
   - Open Android Studio on your computer

2. **Open RideAlertz Project**
   - Click **"Open"** (or File → Open)
   - Navigate to: `C:\Users\Admin\AndroidStudioProjects\rideAlertz`
   - Click **"OK"**

3. **Wait for Gradle Sync**
   - Android Studio will automatically sync
   - Wait for "Gradle sync finished" message (bottom right)
   - This may take 2-5 minutes on first open

### Step 2: Add google-services.json File

1. **Locate the File**
   - Find the `google-services.json` file you downloaded from Firebase

2. **Copy to Project**
   - In Android Studio, switch to **"Project"** view (top left dropdown)
   - Navigate to: `rideAlertz` → `app` folder
   - **Drag and drop** `google-services.json` into the `app` folder
   - Or right-click `app` folder → **"Paste"**

3. **Verify Location**
   - The file should be at: `app/google-services.json`
   - **NOT** in `app/src/` or any subfolder
   - Same level as `build.gradle.kts`

### Step 3: Update build.gradle.kts

1. **Open app/build.gradle.kts**
   - In Android Studio, navigate to: `app` → `build.gradle.kts`
   - Double-click to open

2. **Add Google Services Plugin**
   - Scroll to the **VERY BOTTOM** of the file
   - After the last `}` of dependencies block
   - Add this line:

```kotlin
apply(plugin = "com.google.gms.google-services")
```

**Your file should end like this:**
```kotlin
dependencies {
    // ... all dependencies ...
    debugImplementation(libs.androidx.ui.tooling)
    debugImplementation(libs.androidx.ui.test.manifest)
}

apply(plugin = "com.google.gms.google-services")
```

3. **Save the File**
   - Press `Ctrl + S` (Windows) or `Cmd + S` (Mac)

### Step 4: Sync Gradle Again

1. **Click "Sync Now"**
   - A yellow banner will appear at the top
   - Click **"Sync Now"**
   - Or click the elephant icon 🐘 in the toolbar

2. **Wait for Sync**
   - Wait for "Gradle sync finished" message
   - If you see errors, check the Troubleshooting section below

---

## 📱 PART 3: Running on Android Device (5 minutes)

### Step 1: Prepare Your Android Phone

1. **Enable Developer Options**
   - Go to **Settings** → **About Phone**
   - Tap **"Build Number"** 7 times
   - You'll see "You are now a developer!"

2. **Enable USB Debugging**
   - Go to **Settings** → **System** → **Developer Options**
   - Toggle ON **"USB Debugging"**
   - Toggle ON **"Install via USB"** (if available)

3. **Connect Phone to Computer**
   - Use a USB cable
   - On phone, tap **"Allow USB Debugging"** when prompted
   - Check **"Always allow from this computer"**
   - Tap **"OK"**

### Step 2: Select Device in Android Studio

1. **Check Device List**
   - In Android Studio toolbar, find the device dropdown
   - You should see your phone name (e.g., "Samsung Galaxy S21")
   - If not visible, wait 10 seconds or reconnect cable

2. **Select Your Device**
   - Click the dropdown
   - Select your phone

### Step 3: Build and Run

1. **Click Run Button**
   - Click the green **Play button ▶️** in toolbar
   - Or press `Shift + F10` (Windows) or `Ctrl + R` (Mac)

2. **Wait for Build**
   - First build takes 2-5 minutes
   - You'll see progress in the bottom panel
   - Wait for "BUILD SUCCESSFUL"

3. **App Installs on Phone**
   - App will automatically install on your phone
   - App will launch automatically
   - You'll see the RideAlertz splash screen!

---

## 🎮 PART 4: First Time App Setup

### Step 1: Complete Onboarding

1. **Welcome Screen**
   - Read the features
   - Tap **"Next"** or **"Get Started"**

2. **Grant Permissions**
   - Tap **"Allow"** for all permissions:
     - ✅ Location (Always)
     - ✅ Camera
     - ✅ Microphone
     - ✅ SMS
     - ✅ Phone
     - ✅ Notifications

3. **Add Emergency Contacts**
   - Tap **"Add Contact"**
   - Enter name and phone number
   - Mark one as **"Primary"**
   - Add at least 2-3 contacts
   - Tap **"Save"** or **"Next"**

4. **Select Vehicle**
   - Choose **Car** or **Bike**
   - Enter vehicle name (e.g., "Honda City")
   - Enter vehicle number (optional)
   - Tap **"Continue"**

### Step 2: Explore Dashboard

1. **Main Dashboard**
   - You'll see the home screen with:
     - Vehicle info
     - Speed display
     - Emergency SOS button
     - Quick Actions (Hospitals, Travels, etc.)

2. **Bottom Navigation**
   - 🏠 **Home** - Main dashboard
   - 🗺️ **Map** - Live location map
   - ❤️ **Health** - Health metrics
   - 🔔 **Alerts** - Notifications
   - ⚙️ **Settings** - App settings

---

## 🧪 PART 5: Testing Features

### Test 1: Start a Ride

1. **Tap "Start Ride"** on dashboard
2. You should see:
   - ✅ Speed starts updating
   - ✅ "Ride Active" indicator
   - ✅ Notification appears (monitoring active)

### Test 2: Hospital Finder

1. **Tap "Hospitals"** in Quick Actions
2. **Add Sample Hospital Data** (if empty):
   - Go to Firebase Console
   - Click **"Realtime Database"**
   - Click **"+"** next to root
   - Copy this JSON:

```json
{
  "hospitals": {
    "hospital1": {
      "id": "hospital1",
      "name": "City General Hospital",
      "address": "123 Main Street, Your City",
      "latitude": 12.9716,
      "longitude": 77.5946,
      "phone": "+91-80-12345678",
      "emergencyPhone": "108",
      "hasAmbulance": true,
      "availableAmbulances": 5,
      "rating": 4.5
    }
  }
}
```

3. **Refresh App** - You should see the hospital!

### Test 3: Emergency SOS

1. **Hold the SOS button** for 2 seconds
2. You should see:
   - ✅ Crash alert screen
   - ✅ Alarm sound
   - ✅ Vibration
   - ✅ 20-second countdown
3. **Tap "I'm OK"** to cancel

### Test 4: Travel History

1. **Complete a short ride** (start → drive → stop)
2. **Tap "Travels"** in Quick Actions
3. You should see your trip with:
   - Distance
   - Duration
   - Safety score
   - Route on map

---

## 🔧 Troubleshooting

### Problem: "google-services.json not found"

**Solution:**
```
1. Check file location: app/google-services.json
2. NOT in app/src/ folder
3. Delete and re-download from Firebase
4. Sync Gradle again
```

### Problem: "Gradle sync failed"

**Solution:**
```
1. File → Invalidate Caches → Invalidate and Restart
2. Wait for Android Studio to restart
3. Click "Sync Now" again
```

### Problem: "Device not detected"

**Solution:**
```
1. Reconnect USB cable
2. Try different USB port
3. Install phone drivers (Google "USB drivers for [your phone model]")
4. Enable "File Transfer" mode on phone (not just charging)
```

### Problem: "App crashes on startup"

**Solution:**
```
1. Check Logcat (bottom panel in Android Studio)
2. Grant all permissions manually:
   - Settings → Apps → RideAlertz → Permissions → Allow all
3. Restart app
```

### Problem: "Firebase permission denied"

**Solution:**
```
1. Go to Firebase Console
2. Realtime Database → Rules
3. Change to test mode:
   {
     "rules": {
       ".read": true,
       ".write": true
     }
   }
4. Click "Publish"
```

### Problem: "Hospital Finder shows no results"

**Solution:**
```
1. Add sample hospital data (see Test 2 above)
2. Check internet connection
3. Check Firebase database rules
```

### Problem: "Crash detection not working"

**Solution:**
```
1. Must test on REAL device (not emulator)
2. Grant location permission (Always)
3. Start a ride first
4. Shake phone vigorously to test
```

---

## 📊 Viewing Firebase Data

### Check Realtime Database

1. **Open Firebase Console**
   - Go to: https://console.firebase.google.com/
   - Select your **RideAlertz** project

2. **View Data**
   - Click **"Build"** → **"Realtime Database"**
   - Click **"Data"** tab
   - You'll see all your app data in real-time!

3. **Data Structure**
   ```
   ridealertz-db/
   ├── users/
   ├── hospitals/
   ├── ambulances/
   ├── accidents/
   ├── travel_history/
   └── notifications/
   ```

### Add Test Data Manually

1. **Click "+" next to root**
2. **Enter key**: `hospitals`
3. **Paste JSON** (see Test 2 above)
4. **Click "Add"**
5. **Refresh app** to see data

---

## 🎯 Quick Commands Reference

### Android Studio

```
Build Project:        Ctrl + F9 (Windows) / Cmd + F9 (Mac)
Run App:              Shift + F10 (Windows) / Ctrl + R (Mac)
Sync Gradle:          Click elephant icon 🐘
Clean Project:        Build → Clean Project
Rebuild Project:      Build → Rebuild Project
View Logcat:          Alt + 6 (Windows) / Cmd + 6 (Mac)
```

### Gradle Commands (Terminal)

```bash
# Clean build
./gradlew clean

# Build debug APK
./gradlew assembleDebug

# Install on device
./gradlew installDebug

# Run all tasks
./gradlew build
```

---

## 📱 Testing Checklist

Before deploying, test these:

- [ ] App launches successfully
- [ ] Onboarding flow completes
- [ ] All permissions granted
- [ ] Start/Stop ride works
- [ ] Speed updates in real-time
- [ ] Emergency SOS triggers
- [ ] Hospital finder shows results
- [ ] Travel history saves trips
- [ ] Firebase data syncs
- [ ] Crash detection works (shake phone)
- [ ] SMS sends to emergency contacts
- [ ] Dashcam records (if camera available)

---

## 🚀 Next Steps After Testing

### 1. Add More Sample Data

Add hospitals, ambulances, and test users to Firebase for realistic testing.

### 2. Customize Settings

- Change speed limits
- Adjust crash sensitivity
- Customize emergency contacts
- Set up notification preferences

### 3. Test All Features

- Drive with the app active
- Test crash detection (carefully!)
- Share location with family
- View travel history
- Check safety scores

### 4. Prepare for Production

- Switch Firebase to production rules
- Enable Firebase Analytics
- Add Crashlytics for error tracking
- Create Play Store listing

---

## 📞 Need Help?

### Common Issues

1. **Build errors**: Clean and rebuild project
2. **Firebase errors**: Check internet connection
3. **Permission errors**: Grant all permissions manually
4. **Sensor errors**: Test on real device only

### Useful Links

- **Firebase Console**: https://console.firebase.google.com/
- **Android Studio**: https://developer.android.com/studio
- **Firebase Docs**: https://firebase.google.com/docs
- **Project Guides**: Check other .md files in project folder

---

## ✅ Success Checklist

You're ready when you see:

- ✅ App installs on phone
- ✅ Firebase data syncs
- ✅ All permissions granted
- ✅ Ride tracking works
- ✅ Emergency features work
- ✅ Hospital finder shows data
- ✅ Travel history saves

---

## 🎉 You're All Set!

Your RideAlertz app is now running! 🚀

**What you can do now:**
1. ✅ Test all features
2. ✅ Add sample data to Firebase
3. ✅ Customize settings
4. ✅ Start tracking rides
5. ✅ Share with friends for testing

**Every Second Counts ⏱️**

---

## 📝 Quick Reference Card

```
┌─────────────────────────────────────────┐
│         RIDEALERTZ QUICK START          │
├─────────────────────────────────────────┤
│ 1. Firebase Console                     │
│    → Create project "RideAlertz"        │
│    → Download google-services.json      │
│    → Enable Realtime Database           │
│                                         │
│ 2. Android Studio                       │
│    → Open project                       │
│    → Add google-services.json to app/  │
│    → Add apply plugin to build.gradle  │
│    → Sync Gradle                        │
│                                         │
│ 3. Run on Phone                         │
│    → Enable USB Debugging               │
│    → Connect phone                      │
│    → Click Run ▶️                       │
│                                         │
│ 4. Test                                 │
│    → Complete onboarding                │
│    → Grant all permissions              │
│    → Start a ride                       │
│    → Test features                      │
└─────────────────────────────────────────┘
```

**Total Time**: ~20 minutes  
**Difficulty**: Easy 😊  
**Status**: Ready to Go! 🚀
