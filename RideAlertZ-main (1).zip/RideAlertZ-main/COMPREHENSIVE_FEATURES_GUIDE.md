# RideAlertz - Comprehensive Safety System Guide 🚘📱

## 🎯 System Overview

RideAlertz is a complete mobile safety companion that transforms your smartphone into an intelligent accident detection and prevention system for bikers and car drivers. It combines multiple safety features into one unified platform.

---

## 🚘 1. Vehicle Registration Module

### Features:
- **Vehicle Type Selection**: Choose between Bike 🏍️ or Car 🚗
- **Vehicle Model**: Select from popular models or enter custom name
  - Bikes: Yamaha R15, Royal Enfield, Honda CBR, KTM Duke, Bajaj Pulsar
  - Cars: Hyundai i20, Maruti Swift, Honda City, Tata Nexon, Mahindra XUV
- **Vehicle Number**: Optional registration number (e.g., TN01AB1234)
- **Custom Speed Limits**: Set personalized speed limits
  - Default for Bikes: 80 km/h
  - Default for Cars: 100 km/h
  - Range: 40-200 km/h (adjustable in 10 km/h increments)

### Implementation:
- File: `VehicleSelectionActivity.kt`
- Data stored in SharedPreferences
- Editable later from Settings

---

## ⚡ 2. Speed Monitoring System

### Features:
- **Real-time GPS Speed Tracking**: Updates every 1 second
- **Live Speed Display**: Shows current speed on dashboard
- **Overspeed Detection**: Compares with set speed limit
- **Multi-modal Alerts**:
  - 🔴 Visual: Red flashing notification
  - 📳 Haptic: Vibration pattern
  - 🔊 Audio: Text-to-Speech voice alert ("Speed limit exceeded! Slow down.")
  - 📱 Notification: Persistent overspeed warning

### Alert System:
- **Cooldown Period**: 10 seconds between alerts (prevents spam)
- **Auto-clear**: Notification disappears when speed normalizes
- **Event Logging**: All overspeed events saved with:
  - Timestamp
  - Speed value
  - GPS coordinates
  - Speed limit at the time

### Implementation:
- Service: `SpeedMonitoringService.kt`
- Foreground service with location tracking
- Uses Google Play Services Location API
- Text-to-Speech for voice alerts

---

## 📸 3. Dash Cam Feature

### Features:
- **Continuous Recording**: Rolling buffer system
- **Segment-based**: 10-second segments
- **Buffer Size**: Last 30 seconds (3 segments)
- **Auto-save on Impact**: Saves footage when accident detected
- **Video Specifications**:
  - Resolution: 1920x1080 (Full HD)
  - Frame Rate: 30 FPS
  - Format: MP4 (H.264 video, AAC audio)
  - Bitrate: 10 Mbps

### Storage:
- **Temporary**: `/Movies/temp/` (rolling buffer)
- **Permanent**: `/Movies/RideAlertz_Impacts/` (saved accidents)
- **Naming**: `impact_YYYYMMDD_HHMMSS.mp4`

### Future Enhancements (Optional):
- GPS coordinates overlay on video
- Timestamp watermark
- Speed overlay
- Merge multiple segments using FFmpeg

### Implementation:
- Service: `DashcamRecorderService.kt`
- Uses Camera2 API and MediaRecorder
- Foreground service with camera permission

---

## 🧩 4. Accident Detection System

### Detection Methods:
1. **Accelerometer**: Detects sudden impact (>40 m/s² delta)
2. **Gyroscope**: Detects sharp turns and rotations
3. **Rotation Vector**: Detects phone tilt (>90° = fall/crash)
4. **GPS**: Detects sudden stops

### Detection Logic:
- **Combined Trigger**: Requires both spike AND tilt
- **Spike Threshold**: >40 m/s² change within 150ms
- **Tilt Threshold**: >90° from normal orientation
- **Time Window**: 3 seconds to correlate events
- **Cooldown**: 60 seconds between detections

### Response Flow:
1. ✅ Accident detected
2. 📹 Save dashcam footage
3. 📝 Log accident details
4. 🚨 Show crash alert screen (10-second countdown)
5. 📞 Send SMS to emergency contacts
6. 📍 Share GPS location
7. 📹 Initiate emergency video call (after 5 seconds)

### Implementation:
- Service: `SensorMonitoringService.kt`
- Uses hardware sensors (accelerometer, gyroscope, rotation vector)
- Integrates with all other services

---

## 📍 5. Location and Emergency Alert

### Features:
- **Auto-detect Accident**: Sensor-based detection
- **GPS Location**: Real-time coordinates
- **Google Maps Link**: Direct navigation link
- **Emergency SMS**: Sent to all saved contacts

### SMS Format:
```
🚨 RIDEALERTZ EMERGENCY ALERT 🚨
Possible accident detected!

📍 Location: [latitude], [longitude]
🗺️ Maps: https://maps.google.com/?q=[lat],[lng]
⚡ Speed: [speed] km/h
🚗 Vehicle: [Type] - [Model]
🔢 Number: [Registration]
⏰ Time: [Date and Time]
```

### Emergency Contacts:
- Managed in `EmergencyContactsActivity`
- Supports multiple contacts
- Primary contact designation
- Stored in SharedPreferences (JSON format)

---

## 📞 6. Emergency Video Call System

### Features:
- **Auto-initiate**: Starts 5 seconds after accident detection
- **10-second Countdown**: User can cancel if false alarm
- **Multiple Options**:
  1. 📹 **Jitsi Meet Video Call**: Web-based video conferencing
  2. 💬 **WhatsApp Call**: Direct WhatsApp video/voice call
  3. 📞 **Phone Call**: Traditional phone call

### Jitsi Meet Integration:
- **Room Generation**: Unique room ID per emergency
- **Format**: `ridealertz_emergency_[timestamp]`
- **Link Sharing**: SMS sent to emergency contact
- **Auto-join**: Opens Jitsi Meet in browser/app

### Implementation:
- Activity: `EmergencyVideoCallActivity.kt`
- Uses Jitsi Meet SDK (optional) or web links
- Fallback to WhatsApp/Phone if Jitsi unavailable
- Primary contact called first

---

## 📊 7. Dashboard Design

### Tabs:
1. **🏠 Home**: Main dashboard with speed, vehicle info, emergency button
2. **🗺️ Map**: Live GPS tracking with Google Maps
3. **❤️ Health**: Health metrics (future: wearable integration)
4. **🔔 Alerts**: Accident log and notifications
5. **⚙️ Settings**: App configuration

### Home Tab Features:
- Vehicle information card
- Real-time speed display
- Overspeed warnings
- Location display
- Ride status (Active/Inactive)
- Big SOS emergency button

### Map Tab Features:
- Google Maps integration
- Live location marker
- Real-time tracking
- "You are here" indicator

### Alerts Tab Features:
- **Accident Log Button**: View all past incidents
- Safety notifications
- Emergency alerts history
- Safety tips

### Color Themes:
- **Dark Mode**: Primary theme (modern, less eye strain)
- **Bike Mode**: 🟢 Neon Green accents (#10B981)
- **Car Mode**: 🔵 Blue accents (#6366F1)
- **Emergency**: 🔴 Red (#EF4444)

---

## 📝 8. Accident Log

### Features:
- **Complete History**: All detected accidents
- **Detailed Records**:
  - Date and time
  - GPS coordinates
  - Speed at impact
  - Vehicle details
  - Severity level (High/Medium/Low)
  - Video evidence (if available)

### Actions:
- **View Location**: Opens Google Maps
- **Play Video**: Opens saved dashcam footage
- **Share**: Export accident report

### Implementation:
- Activity: `AccidentLogActivity.kt`
- Data stored in SharedPreferences (JSON)
- Lazy loading for performance

---

## 🧰 Tech Stack

| Component | Technology |
|-----------|-----------|
| **Platform** | Android (Kotlin) |
| **UI Framework** | Jetpack Compose |
| **Architecture** | MVVM with Services |
| **Sensors** | Accelerometer, Gyroscope, Rotation Vector |
| **Location** | Google Play Services Location API |
| **Maps** | Google Maps SDK + Maps Compose |
| **Camera** | Camera2 API + MediaRecorder |
| **Video Call** | Jitsi Meet SDK (web-based fallback) |
| **Storage** | SharedPreferences + File System |
| **Serialization** | Gson |
| **Notifications** | NotificationCompat |
| **Text-to-Speech** | Android TTS |

---

## 🔧 Services Architecture

### Foreground Services:
1. **SensorMonitoringService**: Accident detection
   - Type: `location`
   - Runs continuously when ride active
   
2. **SpeedMonitoringService**: Speed tracking and alerts
   - Type: `location`
   - GPS-based speed calculation
   
3. **DashcamRecorderService**: Video recording
   - Type: `camera`
   - Rolling buffer system

### Service Lifecycle:
- **Start**: When user taps "Start Ride"
- **Stop**: When user taps "Stop Ride"
- **Persist**: Services survive app closure
- **Foreground**: Persistent notifications

---

## 📱 Permissions Required

### Essential:
- ✅ `ACCESS_FINE_LOCATION`: GPS tracking
- ✅ `ACCESS_COARSE_LOCATION`: Network location
- ✅ `ACCESS_BACKGROUND_LOCATION`: Background tracking
- ✅ `CAMERA`: Dashcam recording
- ✅ `RECORD_AUDIO`: Audio in videos
- ✅ `SEND_SMS`: Emergency alerts
- ✅ `CALL_PHONE`: Emergency calls
- ✅ `POST_NOTIFICATIONS`: Alerts (Android 13+)

### Optional:
- ⚪ `READ_CONTACTS`: Import emergency contacts
- ⚪ `INTERNET`: Maps and video calls
- ⚪ `VIBRATE`: Haptic feedback

---

## 🎯 Key Features Summary

✅ **Vehicle Registration** with custom speed limits  
✅ **Real-time Speed Monitoring** with voice alerts  
✅ **Continuous Dashcam Recording** (30-second buffer)  
✅ **Multi-sensor Accident Detection**  
✅ **Automatic Emergency SMS** with GPS location  
✅ **Emergency Video Call** (Jitsi/WhatsApp/Phone)  
✅ **Comprehensive Accident Log**  
✅ **Modern Dashboard** with 5 tabs  
✅ **Google Maps Integration**  
✅ **Overspeed Event Logging**  
✅ **Foreground Services** for reliability  

---

## 🚀 How to Use

### First Time Setup:
1. Launch app → Splash screen
2. Welcome screen → Tap "Get Started"
3. Select vehicle type (Bike/Car)
4. Enter vehicle details and speed limit
5. Login/Register
6. Grant all permissions
7. Add emergency contacts

### Daily Use:
1. Open app → Dashboard
2. Tap "Start Ride" → All services activate
3. Drive safely → App monitors in background
4. If accident detected → Auto-alerts sent
5. Tap "Stop Ride" → Services stop

### Emergency:
- **Manual**: Press & hold SOS button
- **Automatic**: Sensors detect crash
- **Response**: SMS + Location + Video Call

---

## 🔮 Future Enhancements

### Planned Features:
- 🤖 **AI Dash Cam**: Object detection (vehicles, pedestrians)
- 📊 **Trip Recorder**: Distance, duration, average speed
- 🏥 **Medical QR Code**: Emergency medical info
- ☁️ **Cloud Backup**: Firebase storage for videos
- 🔐 **Encryption**: Secure video storage
- 📈 **Analytics**: Driving behavior insights
- 🌐 **Web Dashboard**: View data on desktop
- 👥 **Family Tracking**: Share location with family
- 🎙️ **Voice Commands**: Hands-free control

---

## 📄 Files Structure

```
app/src/main/java/com/example/ridealertz/
├── VehicleSelectionActivity.kt          # Vehicle setup
├── MainActivityNew.kt                   # Main dashboard
├── AccidentLogActivity.kt               # Accident history
├── service/
│   ├── SensorMonitoringService.kt       # Accident detection
│   ├── SpeedMonitoringService.kt        # Speed tracking
│   ├── DashcamRecorderService.kt        # Video recording
│   ├── EmergencyVideoCallActivity.kt    # Video call UI
│   ├── EmergencyContactsActivity.kt     # Contact management
│   └── CrashAlertActivity.kt            # Crash confirmation
└── ui/theme/                            # Compose themes
```

---

## 🎨 Design Philosophy

- **Safety First**: All features prioritize user safety
- **Minimal Interaction**: Auto-detection reduces driver distraction
- **Reliable**: Foreground services ensure continuous monitoring
- **Privacy**: All data stored locally (optional cloud)
- **Modern UI**: Jetpack Compose with Material 3
- **Performance**: Efficient battery and resource usage

---

## 📞 Support

For issues or questions:
- Check logs in Android Studio
- Verify all permissions granted
- Ensure GPS and sensors working
- Test in real driving conditions

---

**Stay Safe on the Road! 🚗💨**

*RideAlertz - Your Smart Safety Companion*
