package com.example.ridealertz.model

/**
 * Shared snapshot for weather summaries shown across rider and driver dashboards.
 */
data class WeatherSnapshot(
    val location: String = "Chennai",
    val condition: String = "Clear",
    val temperatureC: Int = 30,
    val humidity: Int = 55,
    val windKmph: Int = 8,
    val alert: String? = null
)
