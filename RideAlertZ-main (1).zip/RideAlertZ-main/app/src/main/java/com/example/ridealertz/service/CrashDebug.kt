package com.example.ridealertz.service

import android.content.Context
import android.os.SystemClock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

data class CrashSample(
    val timestamp: Long,
    val audioProb: Float,
    val accelMag: Float,
    val gyroMag: Float,
    val tilt: Float,
    val finalScore: Float,
    val accelThreshold: Float,
    val gyroThreshold: Float,
    val triggered: Boolean
)

object CrashLogger {
    private var writer: BufferedWriter? = null
    private var currentFile: File? = null
    private val formatter = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US)

    fun start(context: Context) {
        if (writer != null) return
        val dir = File(context.getExternalFilesDir(null), "crashlogs")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        currentFile = File(dir, "crash_${formatter.format(Date())}.csv")
        writer = BufferedWriter(FileWriter(currentFile!!, true)).apply {
            write("timestamp,audio,accel,gyro,tilt,finalScore,accelThreshold,gyroThreshold,triggered")
            newLine()
            flush()
        }
    }

    fun logSample(sample: CrashSample) {
        writer?.let {
            it.write(
                "${sample.timestamp}," +
                        "${sample.audioProb}," +
                        "${sample.accelMag}," +
                        "${sample.gyroMag}," +
                        "${sample.tilt}," +
                        "${sample.finalScore}," +
                        "${sample.accelThreshold}," +
                        "${sample.gyroThreshold}," +
                        "${sample.triggered}"
            )
            it.newLine()
            it.flush()
        }
    }

    fun logEvent(message: String) {
        writer?.let {
            it.write("# ${SystemClock.elapsedRealtime()} $message")
            it.newLine()
            it.flush()
        }
    }

    fun stop() {
        try {
            writer?.flush()
            writer?.close()
        } catch (_: Exception) {
        } finally {
            writer = null
        }
    }
}

data class CrashDebugState(
    val waveform: FloatArray = FloatArray(0),
    val audioProb: Float = 0f,
    val accelMag: Float = 0f,
    val gyroMag: Float = 0f,
    val finalScore: Float = 0f
)

object CrashDebugBus {
    private val _state = MutableStateFlow(CrashDebugState())
    val state: StateFlow<CrashDebugState> = _state

    fun update(
        waveform: FloatArray? = null,
        audioProb: Float? = null,
        accelMag: Float? = null,
        gyroMag: Float? = null,
        finalScore: Float? = null
    ) {
        val current = _state.value
        _state.value = current.copy(
            waveform = waveform ?: current.waveform,
            audioProb = audioProb ?: current.audioProb,
            accelMag = accelMag ?: current.accelMag,
            gyroMag = gyroMag ?: current.gyroMag,
            finalScore = finalScore ?: current.finalScore
        )
    }
}

class AdaptiveThresholdManager(
    private val accelBase: Float = 4.5f,
    private val gyroBase: Float = 0.8f
) {
    private var accelEMA = accelBase
    private var gyroEMA = gyroBase
    private var samples = 0

    fun updateAccel(magnitude: Float) {
        accelEMA = smooth(accelEMA, magnitude)
    }

    fun updateGyro(magnitude: Float) {
        gyroEMA = smooth(gyroEMA, magnitude)
    }

    private fun smooth(ema: Float, value: Float): Float {
        samples++
        val alpha = if (samples < 200) 0.1f else 0.03f
        return ema + alpha * (value - ema)
    }

    fun accelThreshold(): Float = max(accelBase, accelEMA * 2.2f)

    fun gyroThreshold(): Float = max(gyroBase, gyroEMA * 2.0f)
}

class PreCrashAudioBuffer(
    sampleRate: Int,
    seconds: Int
) {
    private val capacity = sampleRate * seconds
    private val buffer = ShortArray(capacity)
    private var index = 0
    private var filled = false

    fun append(data: ShortArray, length: Int) {
        var i = 0
        while (i < length) {
            buffer[index] = data[i]
            index = (index + 1) % capacity
            if (index == 0) filled = true
            i++
        }
    }

    fun dumpToFile(context: Context, prefix: String = "precrash"): File? {
        val dir = File(context.getExternalFilesDir(null), "crashlogs")
        if (!dir.exists()) dir.mkdirs()
        val file = File(dir, "${prefix}_${System.currentTimeMillis()}.pcm")
        return try {
            file.outputStream().use { output ->
                if (filled) {
                    val tail = buffer.copyOfRange(index, capacity)
                    output.write(tail.toByteArray())
                    output.write(buffer.copyOfRange(0, index).toByteArray())
                } else {
                    val slice = buffer.copyOfRange(0, index)
                    output.write(slice.toByteArray())
                }
            }
            file
        } catch (e: Exception) {
            null
        }
    }

    private fun ShortArray.toByteArray(): ByteArray {
        val out = ByteArray(size * 2)
        var j = 0
        for (value in this) {
            out[j++] = (value.toInt() and 0xFF).toByte()
            out[j++] = ((value.toInt() shr 8) and 0xFF).toByte()
        }
        return out
    }
}
