package com.example.ridealertz.ui.theme

import androidx.compose.ui.graphics.Color

// Emergency Theme Colors - Modern & Bold
val EmergencyRed = Color(0xFFDC2626)        // Primary Emergency Red
val EmergencyRedLight = Color(0xFFEF4444)   // Light emergency
val EmergencyRedDark = Color(0xFFB91C1C)    // Dark emergency

val NeonGreen = Color(0xFF10B981)           // Active/Success - Neon Green
val NeonGreenLight = Color(0xFF34D399)      // Light neon
val NeonGreenDark = Color(0xFF059669)       // Dark neon

val AlertOrange = Color(0xFFF59E0B)         // Warning
val AlertOrangeLight = Color(0xFFFBBF24)    // Light warning
val AlertOrangeDark = Color(0xFFD97706)     // Dark warning

// Dark Theme Base
val BlackPrimary = Color(0xFF0F172A)        // Deep black background
val BlackSecondary = Color(0xFF1E293B)      // Secondary black
val BlackTertiary = Color(0xFF334155)       // Tertiary black

// Light Theme Base  
val WhitePrimary = Color(0xFFFAFAFA)        // Off-white background
val WhiteSecondary = Color(0xFFFFFFFF)      // Pure white
val GrayLight = Color(0xFFE2E8F0)           // Light gray
val GrayMedium = Color(0xFF94A3B8)          // Medium gray
val GrayDark = Color(0xFF475569)            // Dark gray

// Accent Colors
val AccentBlue = Color(0xFF3B82F6)          // Information blue
val AccentBlueLight = Color(0xFF60A5FA)     // Light info
val AccentPurple = Color(0xFF8B5CF6)        // Special features
val AccentPurpleLight = Color(0xFFA78BFA)   // Light special

// Status Colors
val StatusSuccess = NeonGreen               // Success state
val StatusWarning = AlertOrange             // Warning state  
val StatusError = EmergencyRed              // Error state
val StatusInfo = AccentBlue                 // Info state

// Legacy compatibility
val SafetyRed = EmergencyRed
val SafetyRedLight = EmergencyRedLight
val SafetyRedDark = EmergencyRedDark
val SafetyGreen = NeonGreen
val SafetyGreenLight = NeonGreenLight
val SafetyGreenDark = NeonGreenDark
val SafetyOrange = AlertOrange
val SafetyOrangeLight = AlertOrangeLight
val SafetyOrangeDark = AlertOrangeDark
val NeutralGray = GrayDark
val NeutralGrayLight = GrayMedium
val NeutralGrayDark = BlackTertiary
val BackgroundLight = WhitePrimary
val BackgroundDark = BlackPrimary
val SurfaceLight = WhiteSecondary
val SurfaceDark = BlackSecondary

val Purple80 = AccentPurpleLight
val PurpleGrey80 = GrayMedium
val Pink80 = EmergencyRedLight
val Purple40 = AccentPurple
val PurpleGrey40 = GrayDark
val Pink40 = EmergencyRed