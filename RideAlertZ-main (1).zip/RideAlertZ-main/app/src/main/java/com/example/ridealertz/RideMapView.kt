package com.example.ridealertz

import android.content.Context
import android.preference.PreferenceManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuffColorFilter
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.core.content.ContextCompat
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay

@Composable
fun RideMapView(
    modifier: Modifier = Modifier,
    selectedCategory: String? = null
) {
    val context = LocalContext.current

    val mapViewState = remember { mutableStateOf<MapView?>(null) }
    val locationOverlayState = remember { mutableStateOf<MyLocationNewOverlay?>(null) }
    val poiMarkers = remember { mutableStateListOf<Marker>() }

    Box(modifier = modifier) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx: Context ->
                // Load osmdroid configuration
                Configuration.getInstance().load(ctx, PreferenceManager.getDefaultSharedPreferences(ctx))

                MapView(ctx).apply {
                    mapViewState.value = this

                    setTileSource(TileSourceFactory.MAPNIK)
                    setMultiTouchControls(true)

                    // Default zoom and a safe initial point (0,0) until GPS arrives
                    controller.setZoom(16.0)
                    controller.setCenter(GeoPoint(0.0, 0.0))

                    // Location overlay used for auto-follow, but icon hidden (we show a pin instead)
                    val myLocationOverlay = MyLocationNewOverlay(GpsMyLocationProvider(ctx), this)
                    locationOverlayState.value = myLocationOverlay
                    applyDarkLocatorStyle(ctx, myLocationOverlay)

                    myLocationOverlay.enableMyLocation()
                    myLocationOverlay.enableFollowLocation()
                    overlays.add(myLocationOverlay)
                }
            }
        )

        // Fetch and display nearby POIs from OpenStreetMap Overpass when category changes
        LaunchedEffect(selectedCategory) {
            val category = selectedCategory
            val mapView = mapViewState.value ?: return@LaunchedEffect

            // Clear previous POI markers
            poiMarkers.forEach { marker ->
                mapView.overlays.remove(marker)
            }
            poiMarkers.clear()

            if (category == null) {
                mapView.postInvalidate()
                return@LaunchedEffect
            }

            // Read last known location from SharedPreferences (set by SensorMonitoringService)
            val prefs = context.getSharedPreferences("ridealertz", Context.MODE_PRIVATE)
            val lat = prefs.getFloat("last_lat", Float.NaN)
            val lng = prefs.getFloat("last_lng", Float.NaN)
            if (lat.isNaN() || lng.isNaN()) {
                // No location yet; don't query
                return@LaunchedEffect
            }

            val latD = lat.toDouble()
            val lngD = lng.toDouble()

            val overpassQuery = buildOverpassQuery(category, latD, lngD)
            if (overpassQuery.isEmpty()) return@LaunchedEffect

            val response = withContext(Dispatchers.IO) {
                try {
                    val url = java.net.URL("https://overpass-api.de/api/interpreter")
                    val conn = (url.openConnection() as java.net.HttpURLConnection).apply {
                        requestMethod = "POST"
                        doOutput = true
                        setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                    }
                    conn.outputStream.use { os ->
                        val bytes = overpassQuery.toByteArray(Charsets.UTF_8)
                        os.write(bytes)
                    }
                    val code = conn.responseCode
                    if (code == 200) {
                        conn.inputStream.bufferedReader().use { it.readText() }
                    } else {
                        null
                    }
                } catch (_: Exception) {
                    null
                }
            }

            if (response.isNullOrEmpty()) return@LaunchedEffect

            try {
                val root = JSONObject(response)
                val elements = root.optJSONArray("elements") ?: return@LaunchedEffect
                for (i in 0 until elements.length()) {
                    val el = elements.optJSONObject(i) ?: continue
                    val poiLat = el.optDouble("lat", Double.NaN)
                    val poiLon = el.optDouble("lon", Double.NaN)
                    if (poiLat.isNaN() || poiLon.isNaN()) continue
                    val tags = el.optJSONObject("tags")
                    val name = tags?.optString("name")?.takeIf { it.isNotBlank() } ?: category

                    val point = GeoPoint(poiLat, poiLon)
                    val marker = Marker(mapView).apply {
                        position = point
                        title = name
                        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)

                        val baseDrawable: Drawable? = ContextCompat.getDrawable(
                            context,
                            org.osmdroid.library.R.drawable.marker_default
                        )
                        if (baseDrawable is BitmapDrawable) {
                            var bmp = baseDrawable.bitmap
                            val tinted = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
                            val canvas = Canvas(tinted)
                            val paintColor = when (category) {
                                "Food" -> Color.parseColor("#22C55E")
                                "Fuel" -> Color.parseColor("#F97316")
                                "Hospitals" -> Color.parseColor("#EF4444")
                                "ATMs" -> Color.parseColor("#0EA5E9")
                                else -> Color.parseColor("#22C55E")
                            }
                            val paint = android.graphics.Paint().apply {
                                colorFilter = android.graphics.PorterDuffColorFilter(
                                    paintColor,
                                    android.graphics.PorterDuff.Mode.SRC_IN
                                )
                            }
                            canvas.drawBitmap(bmp, 0f, 0f, paint)
                            bmp = tinted
                            icon = BitmapDrawable(context.resources, bmp)
                        }
                    }
                    mapView.overlays.add(marker)
                    poiMarkers.add(marker)
                }
                mapView.postInvalidate()
            } catch (_: Exception) {
                // Ignore parse errors
            }
        }

        // Simple zoom / center controls overlaid in the bottom-right corner
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(8.dp)
        ) {
            FilledIconButton(onClick = { mapViewState.value?.controller?.zoomIn() }) {
                Icon(Icons.Default.Add, contentDescription = "Zoom in")
            }
            FilledIconButton(onClick = {
                val overlay = locationOverlayState.value
                val loc = overlay?.myLocation
                if (loc != null) {
                    mapViewState.value?.controller?.animateTo(GeoPoint(loc.latitude, loc.longitude))
                }
            }) {
                Icon(Icons.Default.MyLocation, contentDescription = "Center on me")
            }
            FilledIconButton(onClick = { mapViewState.value?.controller?.zoomOut() }) {
                Icon(Icons.Default.Remove, contentDescription = "Zoom out")
            }
        }
    }
}

private fun applyDarkLocatorStyle(context: Context, overlay: MyLocationNewOverlay) {
    val tintColor = Color.parseColor("#C81E1E")
    val personBitmap = createTintedBitmap(
        context,
        org.osmdroid.library.R.drawable.person,
        tintColor
    )
    val arrowBitmap = createArrowBitmap(tintColor)
    personBitmap?.let { overlay.setPersonIcon(it) }
    if (personBitmap != null && arrowBitmap != null) {
        overlay.setDirectionArrow(personBitmap, arrowBitmap)
    }
}

private fun createTintedBitmap(context: Context, drawableRes: Int, tintColor: Int): Bitmap? {
    val drawable = ContextCompat.getDrawable(context, drawableRes) as? BitmapDrawable ?: return null
    val original = drawable.bitmap
    val tinted = Bitmap.createBitmap(original.width, original.height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(tinted)
    val paint = android.graphics.Paint().apply {
        colorFilter = PorterDuffColorFilter(
            tintColor,
            android.graphics.PorterDuff.Mode.SRC_IN
        )
        isAntiAlias = true
    }
    canvas.drawBitmap(original, 0f, 0f, paint)
    return tinted
}

private fun createArrowBitmap(colorInt: Int): Bitmap {
    val size = 64
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = colorInt
        style = Paint.Style.FILL
    }
    val path = Path().apply {
        moveTo(size / 2f, 0f)
        lineTo(size.toFloat(), size.toFloat())
        lineTo(size / 2f, size * 0.7f)
        lineTo(0f, size.toFloat())
        close()
    }
    canvas.drawPath(path, paint)
    return bitmap
}

// Build a simple Overpass QL query for the selected category around the given point
private fun buildOverpassQuery(category: String, lat: Double, lng: Double): String {
    // Radius in meters
    val radius = 3000
    val filters = when (category) {
        "Food" -> listOf(
            "node[\"amenity\"=\"restaurant\"](around:$radius,$lat,$lng);",
            "node[\"amenity\"=\"cafe\"](around:$radius,$lat,$lng);",
            "node[\"amenity\"=\"fast_food\"](around:$radius,$lat,$lng);"
        )
        "Fuel" -> listOf(
            "node[\"amenity\"=\"fuel\"](around:$radius,$lat,$lng);"
        )
        "Hospitals" -> listOf(
            "node[\"amenity\"=\"hospital\"](around:$radius,$lat,$lng);"
        )
        "ATMs" -> listOf(
            "node[\"amenity\"=\"atm\"](around:$radius,$lat,$lng);"
        )
        else -> emptyList()
    }

    if (filters.isEmpty()) return ""

    val body = buildString {
        append("[out:json];(")
        filters.forEach { append(it) }
        append(");out center 40;")
    }

    // Overpass expects the query as plain text in the POST body
    return body
}
