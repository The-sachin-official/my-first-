package com.example.ridealertz

import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.example.ridealertz.ui.theme.RideAlertzTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ProfileActivity : ComponentActivity() {
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("ridealertz", MODE_PRIVATE)

        val userId = ((prefs.getString("user_email", null)
            ?: prefs.getString("user_phone", null)
            ?: "guest")).replace("@", "_")

        setContent {
            RideAlertzTheme {
                Surface(color = Color(0xFF0D0D0D)) {
                    ProfileScreen(userId = userId) { finish() }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(userId: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("ridealertz", android.content.Context.MODE_PRIVATE) }

    var fullName by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var bloodGroup by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }

    var conditions by remember { mutableStateOf("") }
    var allergies by remember { mutableStateOf("") }
    var medications by remember { mutableStateOf("") }
    var injuries by remember { mutableStateOf("") }

    var bikeModel by remember { mutableStateOf("") }
    var bikeNumber by remember { mutableStateOf("") }
    var insuranceNumber by remember { mutableStateOf("") }
    var rcExpiry by remember { mutableStateOf("") }
    var helmetUsed by remember { mutableStateOf(true) }

    val scope = rememberCoroutineScope()

    LaunchedEffect(userId) {
        scope.launch {
            // Prefill from local prefs
            fullName = prefs.getString("first_name", "") ?: ""
            phone = prefs.getString("user_phone", "") ?: ""
            bloodGroup = prefs.getString("bloodGroup", "") ?: ""
            address = prefs.getString("address", "") ?: ""
            conditions = prefs.getString("conditions", "") ?: ""
            allergies = prefs.getString("allergies", "") ?: ""
            medications = prefs.getString("medications", "") ?: ""
            injuries = prefs.getString("preferredHospital", "") ?: ""
            bikeModel = prefs.getString("insuranceProvider", "") ?: ""
            bikeNumber = prefs.getString("insurancePolicy", "") ?: ""
            insuranceNumber = prefs.getString("doctorName", "") ?: ""
            rcExpiry = prefs.getString("doctorContact", "") ?: ""
            helmetUsed = prefs.getBoolean("helmet_used", true)

            // Best-effort: try to load from Firebase profile if available
            try {
                val map = withContext(Dispatchers.IO) { FirebaseHelper.readUserProfile(userId) }
                if (map != null) {
                    (map["firstName"] as? String)?.let { fullName = it }
                    (map["phone"] as? String)?.let { phone = it }
                    (map["bloodGroup"] as? String)?.let { bloodGroup = it }
                    (map["address"] as? String)?.let { address = it }
                    (map["conditions"] as? String)?.let { conditions = it }
                    (map["allergies"] as? String)?.let { allergies = it }
                    (map["medications"] as? String)?.let { medications = it }
                    (map["preferredHospital"] as? String)?.let { injuries = it }
                    (map["insuranceProvider"] as? String)?.let { bikeModel = it }
                    (map["insurancePolicy"] as? String)?.let { bikeNumber = it }
                    (map["doctorName"] as? String)?.let { insuranceNumber = it }
                    (map["doctorContact"] as? String)?.let { rcExpiry = it }
                    (map["helmet_used"] as? Boolean)?.let { helmetUsed = it }
                }
            } catch (_: Exception) { }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                title = {
                    Text("My Profile", color = Color.White, fontWeight = FontWeight.Bold)
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF101010),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        containerColor = Color(0xFF0D0D0D)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFF0D0D0D))
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Personal Information
            SectionCard(title = "Personal Information") {
                InfoRow("Full Name", fullName)
                InfoRow("Age", age)
                InfoRow("Phone Number", phone)
                InfoRow("Blood Group", bloodGroup)
                InfoRow("Address", address)
                Spacer(modifier = Modifier.height(4.dp))
                HelperText(
                    "Used to share your identity with emergency contacts & ambulance.\n" +
                        "Helps responders reach you faster.\n" +
                        "Blood group helps in emergency treatment."
                )
            }

            // Medical Details
            SectionCard(title = "Medical Details") {
                InfoRow("Medical Conditions", conditions)
                InfoRow("Allergies", allergies)
                InfoRow("Current Medications", medications)
                InfoRow("Previous Injuries", injuries)
                Spacer(modifier = Modifier.height(4.dp))
                HelperText(
                    "Critical information for ambulance/hospital.\n" +
                        "Helps doctors treat you immediately.\n" +
                        "Ensures no wrong medication during emergencies."
                )
            }

            // Bike / Vehicle Details
            SectionCard(title = "Bike / Vehicle Details") {
                InfoRow("Bike Model", bikeModel)
                InfoRow("Bike Number Plate", bikeNumber)
                InfoRow("Insurance Number", insuranceNumber)
                InfoRow("RC Expiry Date", rcExpiry)
                InfoRow("Helmet Usage", if (helmetUsed) "Yes" else "No")
                Spacer(modifier = Modifier.height(4.dp))
                HelperText(
                    "Helps with insurance & accident verification.\n" +
                        "Police/ambulance can identify your vehicle quickly."
                )
            }
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1F2933)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = Color(0xFF9CA3AF), fontSize = 13.sp)
        Text(value.ifBlank { "-" }, color = Color.White, fontSize = 13.sp)
    }
}

@Composable
private fun HelperText(text: String) {
    Text(
        text = text,
        color = Color(0xFF9CA3AF),
        fontSize = 12.sp
    )
}
