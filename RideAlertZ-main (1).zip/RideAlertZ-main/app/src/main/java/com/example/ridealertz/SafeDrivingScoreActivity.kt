package com.example.ridealertz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ridealertz.service.DrivingBehaviorAnalyzer
import com.example.ridealertz.service.DrivingSession
import com.example.ridealertz.ui.theme.RideAlertzTheme
import java.text.SimpleDateFormat
import java.util.*

class SafeDrivingScoreActivity : ComponentActivity() {
    private lateinit var behaviorAnalyzer: DrivingBehaviorAnalyzer
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        behaviorAnalyzer = DrivingBehaviorAnalyzer(this)
        
        setContent {
            RideAlertzTheme {
                SafeDrivingScoreScreen(
                    analyzer = behaviorAnalyzer,
                    onBackPressed = { finish() }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SafeDrivingScoreScreen(
    analyzer: DrivingBehaviorAnalyzer,
    onBackPressed: () -> Unit
) {
    val stats = analyzer.getCurrentStats()
    val score = analyzer.calculateSafetyScore()
    val history = analyzer.getDrivingHistory()
    val totalStats = analyzer.getTotalStats()
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        "Safe Driving Score",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackPressed) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Current Score Card
            item {
                ScoreCard(score = score)
            }
            
            // Achievement Badges
            item {
                AchievementSection(totalStats.totalTrips, totalStats.averageScore)
            }
            
            // Current Trip Stats
            item {
                CurrentTripStats(stats)
            }
            
            // Driving History Header
            item {
                Text(
                    text = "Recent Trips",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            
            // History List
            items(history.reversed()) { session ->
                TripHistoryCard(session)
            }
        }
    }
}

@Composable
fun ScoreCard(score: Int) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        ),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Your Safety Score",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Animated Score Circle
            AnimatedScoreCircle(score = score)
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Score Description
            Text(
                text = getScoreDescription(score),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }
}

@Composable
fun AnimatedScoreCircle(score: Int) {
    val animatedScore by animateIntAsState(
        targetValue = score,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label = "score"
    )
    
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.size(200.dp)
    ) {
        Canvas(modifier = Modifier.size(200.dp)) {
            val strokeWidth = 20f
            val radius = (size.minDimension - strokeWidth) / 2
            
            // Background circle
            drawCircle(
                color = Color.LightGray.copy(alpha = 0.3f),
                radius = radius,
                style = Stroke(width = strokeWidth)
            )
            
            // Score arc
            val sweepAngle = (animatedScore / 100f) * 360f
            val color = when {
                animatedScore >= 80 -> Color(0xFF10B981) // Green
                animatedScore >= 60 -> Color(0xFFF59E0B) // Orange
                else -> Color(0xFFEF4444) // Red
            }
            
            drawArc(
                color = color,
                startAngle = -90f,
                sweepAngle = sweepAngle,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                size = Size(radius * 2, radius * 2),
                topLeft = Offset(
                    (size.width - radius * 2) / 2,
                    (size.height - radius * 2) / 2
                )
            )
        }
        
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "$animatedScore",
                fontSize = 48.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "/ 100",
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun AchievementSection(totalTrips: Int, averageScore: Int) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Achievements",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                AchievementBadge(
                    icon = Icons.Default.DirectionsCar,
                    title = "$totalTrips",
                    subtitle = "Total Trips",
                    color = Color(0xFF6366F1)
                )
                
                AchievementBadge(
                    icon = Icons.Default.Star,
                    title = "$averageScore",
                    subtitle = "Avg Score",
                    color = Color(0xFFF59E0B)
                )
                
                AchievementBadge(
                    icon = Icons.Default.EmojiEvents,
                    title = getBadgeLevel(averageScore),
                    subtitle = "Level",
                    color = Color(0xFF10B981)
                )
            }
        }
    }
}

@Composable
fun AchievementBadge(
    icon: ImageVector,
    title: String,
    subtitle: String,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(100.dp)
    ) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(32.dp)
            )
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = title,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
        )
        
        Text(
            text = subtitle,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun CurrentTripStats(stats: com.example.ridealertz.service.DrivingStats) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Current Trip",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            StatRow(
                icon = Icons.Default.Speed,
                label = "Current Speed",
                value = "${String.format("%.1f", stats.currentSpeed)} km/h",
                color = Color(0xFF6366F1)
            )
            
            StatRow(
                icon = Icons.Default.Route,
                label = "Distance",
                value = "${String.format("%.2f", stats.totalDistance)} km",
                color = Color(0xFF10B981)
            )
            
            StatRow(
                icon = Icons.Default.Warning,
                label = "Harsh Braking",
                value = "${stats.harshBrakingCount}",
                color = Color(0xFFEF4444)
            )
            
            StatRow(
                icon = Icons.Default.TurnRight,
                label = "Sharp Turns",
                value = "${stats.sharpTurnCount}",
                color = Color(0xFFF59E0B)
            )
            
            StatRow(
                icon = Icons.Default.Speed,
                label = "Speed Violations",
                value = "${stats.speedViolationCount}",
                color = Color(0xFFEF4444)
            )
        }
    }
}

@Composable
fun StatRow(
    icon: ImageVector,
    label: String,
    value: String,
    color: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(20.dp)
            )
        }
        
        Spacer(modifier = Modifier.width(12.dp))
        
        Text(
            text = label,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyMedium
        )
        
        Text(
            text = value,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
fun TripHistoryCard(session: DrivingSession) {
    val dateFormat = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Score Circle
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(CircleShape)
                    .background(getScoreColor(session.safetyScore).copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${session.safetyScore}",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = getScoreColor(session.safetyScore)
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = dateFormat.format(Date(session.timestamp)),
                    fontWeight = FontWeight.Medium
                )
                
                Text(
                    text = "${String.format("%.2f", session.distance)} km • ${session.duration} min",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                
                Text(
                    text = "Violations: ${session.harshBraking + session.sharpTurns + session.speedViolations}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

fun getScoreDescription(score: Int): String {
    return when {
        score >= 90 -> "Excellent! You're a safe driver! 🌟"
        score >= 80 -> "Great job! Keep it up! 👍"
        score >= 70 -> "Good driving! Room for improvement."
        score >= 60 -> "Fair. Try to drive more carefully."
        else -> "Needs improvement. Drive safely!"
    }
}

fun getScoreColor(score: Int): Color {
    return when {
        score >= 80 -> Color(0xFF10B981) // Green
        score >= 60 -> Color(0xFFF59E0B) // Orange
        else -> Color(0xFFEF4444) // Red
    }
}

fun getBadgeLevel(averageScore: Int): String {
    return when {
        averageScore >= 90 -> "Gold"
        averageScore >= 75 -> "Silver"
        averageScore >= 60 -> "Bronze"
        else -> "Novice"
    }
}
