package com.example.ridealertz.service

import android.content.Context
import android.hardware.SensorEvent
import android.location.Location
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class DrivingBehaviorAnalyzer(private val context: Context) {
    private var currentStats = DrivingStats()
    private val history = mutableListOf<DrivingSession>()

    private var tripStartTime: Long = 0L
    private var lastLocation: Location? = null

    private var onHarshBrake: ((Double) -> Unit)? = null
    private var onSharpTurn: ((Double) -> Unit)? = null
    private var onSpeedViolation: ((Double, Double) -> Unit)? = null

    fun setCallbacks(
        onHarshBrake: (Double) -> Unit,
        onSharpTurn: (Double) -> Unit,
        onSpeedViolation: (Double, Double) -> Unit
    ) {
        this.onHarshBrake = onHarshBrake
        this.onSharpTurn = onSharpTurn
        this.onSpeedViolation = onSpeedViolation
    }

    fun startTrip() {
        tripStartTime = System.currentTimeMillis()
        currentStats = DrivingStats()
        lastLocation = null
    }

    fun endTrip() {
        if (tripStartTime == 0L) return

        val durationMinutes = ((System.currentTimeMillis() - tripStartTime) / 60000L).toInt()
        val score = calculateSafetyScore()

        val session = DrivingSession(
            timestamp = tripStartTime,
            distance = currentStats.totalDistance,
            duration = max(durationMinutes, 0),
            safetyScore = score,
            harshBraking = currentStats.harshBrakingCount,
            sharpTurns = currentStats.sharpTurnCount,
            speedViolations = currentStats.speedViolationCount
        )

        history.add(session)
        tripStartTime = 0L
    }

    fun analyzeAccelerometer(event: SensorEvent) {
        val ax = event.values.getOrNull(0)?.toDouble() ?: 0.0
        val ay = event.values.getOrNull(1)?.toDouble() ?: 0.0
        val az = event.values.getOrNull(2)?.toDouble() ?: 0.0

        val magnitude = sqrt(ax * ax + ay * ay + az * az)
        val threshold = 15.0
        if (magnitude > threshold) {
            currentStats = currentStats.copy(
                harshBrakingCount = currentStats.harshBrakingCount + 1
            )
            onHarshBrake?.invoke(magnitude)
        }

        updateDuration()
    }

    fun analyzeGyroscope(event: SensorEvent) {
        val wx = event.values.getOrNull(0)?.toDouble() ?: 0.0
        val wy = event.values.getOrNull(1)?.toDouble() ?: 0.0
        val wz = event.values.getOrNull(2)?.toDouble() ?: 0.0

        val magnitude = sqrt(wx * wx + wy * wy + wz * wz)
        val threshold = 2.0
        if (magnitude > threshold) {
            currentStats = currentStats.copy(
                sharpTurnCount = currentStats.sharpTurnCount + 1
            )
            onSharpTurn?.invoke(magnitude)
        }

        updateDuration()
    }

    fun updateLocation(location: Location) {
        val last = lastLocation
        if (last != null) {
            val distanceMeters = last.distanceTo(location).toDouble()
            val distanceKm = distanceMeters / 1000.0
            currentStats = currentStats.copy(
                totalDistance = currentStats.totalDistance + distanceKm
            )
        }
        lastLocation = location

        val speedKmh = location.speed.toDouble() * 3.6
        val newStats = currentStats.copy(currentSpeed = speedKmh)
        currentStats = newStats

        val speedLimit = 60.0
        if (speedKmh > speedLimit) {
            currentStats = currentStats.copy(
                speedViolationCount = currentStats.speedViolationCount + 1
            )
            onSpeedViolation?.invoke(speedKmh, speedLimit)
        }

        updateDuration()
    }

    fun getCurrentStats(): DrivingStats = currentStats

    fun calculateSafetyScore(): Int {
        var score = 100
        score -= currentStats.harshBrakingCount * 5
        score -= currentStats.sharpTurnCount * 5
        score -= currentStats.speedViolationCount * 3
        score = min(100, max(0, score))
        return score
    }

    fun getDrivingHistory(): List<DrivingSession> = history.toList()

    fun getTotalStats(): TotalDrivingStats {
        if (history.isEmpty()) {
            return TotalDrivingStats(totalTrips = 0, averageScore = 0)
        }
        val totalTrips = history.size
        val avgScore = history.map { it.safetyScore }.average().toInt()
        return TotalDrivingStats(totalTrips = totalTrips, averageScore = avgScore)
    }

    private fun updateDuration() {
        if (tripStartTime == 0L) return
        val minutes = ((System.currentTimeMillis() - tripStartTime) / 60000L).toInt()
        if (minutes != currentStats.duration) {
            currentStats = currentStats.copy(duration = max(minutes, 0))
        }
    }
}

data class DrivingStats(
    val currentSpeed: Double = 0.0,
    val totalDistance: Double = 0.0,
    val duration: Int = 0,
    val harshBrakingCount: Int = 0,
    val sharpTurnCount: Int = 0,
    val speedViolationCount: Int = 0
)

data class DrivingSession(
    val timestamp: Long,
    val distance: Double,
    val duration: Int,
    val safetyScore: Int,
    val harshBraking: Int,
    val sharpTurns: Int,
    val speedViolations: Int
)

data class TotalDrivingStats(
    val totalTrips: Int,
    val averageScore: Int
)
