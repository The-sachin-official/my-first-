package com.example.ridealertz

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Event
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.example.ridealertz.ui.theme.RideAlertzTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class VehicleDetailsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("ridealertz", MODE_PRIVATE)
        val userId = prefs.getString("user_uid", null)
            ?: ((
                prefs.getString("user_email", null)
                    ?: prefs.getString("user_phone", null)
                    ?: "guest"
                ).replace("@", "_")
            )
        setContent {
            RideAlertzTheme {
                VehicleDetailsScreen(
                    onBack = { finish() },
                    onNext = { details ->
                        lifecycleScope.launch {
                            withTimeoutOrNull(5000L) {
                                try {
                                    val vehicleMap = mutableMapOf<String, Any>(
                                        "vehicle_type" to details.vehicleType,
                                        "vehicle_name" to details.model,
                                        "vehicle_number" to details.numberPlate,
                                        "vehicle_color" to details.color,
                                        "insurance_policy" to details.insuranceNumber,
                                        "insurance_provider" to "",
                                        "rc_expiry" to details.rcExpiry,
                                        "helmet_used" to details.helmetUsed,
                                        "last_service" to details.lastService
                                    )
                                    details.rcExpiryTimestamp?.let { vehicleMap["rc_expiry_ts"] = it }
                                    details.lastServiceTimestamp?.let { vehicleMap["last_service_ts"] = it }
                                    withContext(Dispatchers.IO) {
                                        FirebaseHelper.writeUserVehicle(userId, vehicleMap)
                                        FirebaseHelper.updateUserVehicleFirestore(userId, vehicleMap)
                                    }
                                } catch (_: Exception) { }
                            }

                            // Also persist key vehicle values locally for ProfileTab display
                            prefs.edit().apply {
                                putString("vehicle_type", details.vehicleType)
                                putString("vehicle_name", details.model)
                                putString("vehicle_number", details.numberPlate)
                                putString("vehicle_color", details.color)
                                apply()
                            }

                            startActivity(Intent(this@VehicleDetailsActivity, ReviewActivity::class.java))
                            finish()
                        }
                    }
                )
            }
        }
    }
}

data class VehicleDetails(
    val vehicleType: String,
    val model: String,
    val numberPlate: String,
    val color: String,
    val insuranceNumber: String,
    val rcExpiry: String,
    val rcExpiryTimestamp: Long?,
    val helmetUsed: Boolean,
    val lastService: String,
    val lastServiceTimestamp: Long?
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VehicleDetailsScreen(onBack: () -> Unit, onNext: (VehicleDetails) -> Unit) {
    val vehicleType = remember { mutableStateOf("Bike") }
    val model = remember { mutableStateOf("") }
    val numberPlate = remember { mutableStateOf("") }
    val vehicleColor = remember { mutableStateOf("") }
    val insuranceNumber = remember { mutableStateOf("") }
    val rcExpiry = remember { mutableStateOf("") }
    val rcExpiryTimestamp = remember { mutableStateOf<Long?>(null) }
    val helmetUsed = remember { mutableStateOf(true) }
    val lastService = remember { mutableStateOf("") }
    val lastServiceTimestamp = remember { mutableStateOf<Long?>(null) }
    val context = LocalContext.current
    val dateFormatter = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }
    val isSubmitting = remember { mutableStateOf(false) }
    val scrollState = rememberScrollState()

    fun openDatePicker(onResult: (Long, String) -> Unit) {
        val calendar = Calendar.getInstance()
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                calendar.set(Calendar.YEAR, year)
                calendar.set(Calendar.MONTH, month)
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                calendar.set(Calendar.MILLISECOND, 0)
                val millis = calendar.timeInMillis
                onResult(millis, dateFormatter.format(calendar.time))
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                title = { Text("Vehicle Details", color = Color.White) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF020617))
            )
        },
        containerColor = Color(0xFF020617)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp)
                .background(Color(0xFF020617)),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .weight(1f, fill = true)
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Vehicle Type", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    FilterChip(
                        selected = vehicleType.value == "Bike",
                        onClick = { vehicleType.value = "Bike" },
                        label = { Text("Bike") }
                    )
                    FilterChip(
                        selected = vehicleType.value == "Car",
                        onClick = { vehicleType.value = "Car" },
                        label = { Text("Car") }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text("${'$'}{vehicleType.value} Details", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(value = model.value, onValueChange = { model.value = it }, label = { Text("Model") }, modifier = Modifier.fillMaxWidth(), colors = outlinedDarkColors())
                OutlinedTextField(value = numberPlate.value, onValueChange = { numberPlate.value = it }, label = { Text("Number Plate") }, modifier = Modifier.fillMaxWidth(), colors = outlinedDarkColors())
                OutlinedTextField(
                    value = vehicleColor.value,
                    onValueChange = { vehicleColor.value = it },
                    label = { Text("Vehicle Color") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = outlinedDarkColors()
                )
                OutlinedTextField(
                    value = insuranceNumber.value,
                    onValueChange = { insuranceNumber.value = it },
                    label = { Text("Insurance Number") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = outlinedDarkColors()
                )
                OutlinedTextField(
                    value = rcExpiry.value,
                    onValueChange = {},
                    label = { Text("RC Expiry Date") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            openDatePicker { millis, label ->
                                rcExpiryTimestamp.value = millis
                                rcExpiry.value = label
                            }
                        },
                    readOnly = true,
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                openDatePicker { millis, label ->
                                    rcExpiryTimestamp.value = millis
                                    rcExpiry.value = label
                                }
                            }
                        ) {
                            Icon(Icons.Default.Event, contentDescription = "Pick RC expiry date")
                        }
                    },
                    colors = outlinedDarkColors()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Helmet Used", color = Color.White)
                    Switch(checked = helmetUsed.value, onCheckedChange = { helmetUsed.value = it })
                }

                OutlinedTextField(
                    value = lastService.value,
                    onValueChange = {},
                    label = { Text("Last Service Date") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            openDatePicker { millis, label ->
                                lastServiceTimestamp.value = millis
                                lastService.value = label
                            }
                        },
                    readOnly = true,
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                openDatePicker { millis, label ->
                                    lastServiceTimestamp.value = millis
                                    lastService.value = label
                                }
                            }
                        ) {
                            Icon(Icons.Default.Event, contentDescription = "Pick last service date")
                        }
                    },
                    colors = outlinedDarkColors()
                )
 
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                OutlinedButton(
                    onClick = onBack,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF93C5FD))
                ) {
                    Text("Back")
                }
                Spacer(modifier = Modifier.width(12.dp))
                Button(
                    enabled = !isSubmitting.value,
                    onClick = {
                        if (isSubmitting.value) return@Button
                        isSubmitting.value = true
                        onNext(
                            VehicleDetails(
                                vehicleType = vehicleType.value,
                                model = model.value,
                                numberPlate = numberPlate.value,
                                color = vehicleColor.value,
                                insuranceNumber = insuranceNumber.value,
                                rcExpiry = rcExpiry.value,
                                rcExpiryTimestamp = rcExpiryTimestamp.value,
                                helmetUsed = helmetUsed.value,
                                lastService = lastService.value,
                                lastServiceTimestamp = lastServiceTimestamp.value
                            )
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
                ) {
                    Text("Next", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
