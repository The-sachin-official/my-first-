package com.example.ridealertz.service

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

class AccidentConfirmActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                val seconds = remember { mutableIntStateOf(10) }
                LaunchedEffect(Unit) {
                    while (seconds.intValue > 0) {
                        delay(1000)
                        seconds.intValue = seconds.intValue - 1
                    }
                    sendBroadcast(Intent(ACTION_CONFIRM_RESULT).putExtra(EXTRA_CONFIRMED, false))
                    finish()
                }
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Possible accident detected")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Are you safe? Sending alert in ${'$'}{seconds.intValue}s")
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = {
                        sendBroadcast(Intent(ACTION_CONFIRM_RESULT).putExtra(EXTRA_CONFIRMED, true))
                        setResult(Activity.RESULT_OK)
                        finish()
                    }) { Text("I'm Safe - Cancel Alert") }
                }
            }
        }
    }

    companion object {
        const val ACTION_CONFIRM_RESULT = "com.example.ridealertz.CONFIRM_RESULT"
        const val EXTRA_CONFIRMED = "confirmed"
    }
}


