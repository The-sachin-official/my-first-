package com.example.ridealertz.data

import com.google.firebase.database.IgnoreExtraProperties

/**
 * Firebase Data Models for RideAlertz
 * Updated Schema:
 * users ──< emergency_contacts
 *   │
 *   └──< rides ──< crash_events ──< alerts
 * hospitals ──< ambulances
 */

@IgnoreExtraProperties
data class User(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val phone: String = "",
    val vehicleType: String = "",
    val vehicleName: String = "",
    val vehicleNumber: String = "",
    val role: String = "rider", // rider, admin, driver
    val hospitalId: String? = null, // For admin and driver roles
    val createdAt: Long = System.currentTimeMillis(),
    val lastActive: Long = System.currentTimeMillis()
)

@IgnoreExtraProperties
data class EmergencyContact(
    val id: String = "",
    val userId: String = "",
    val name: String = "",
    val phone: String = "",
    val relation: String = "",
    val isPrimary: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@IgnoreExtraProperties
data class Ride(
    val id: String = "",
    val userId: String = "",
    val startTime: Long = System.currentTimeMillis(),
    val endTime: Long? = null,
    val duration: Long = 0L, // milliseconds
    val distance: Double = 0.0, // kilometers
    val avgSpeed: Float = 0f, // km/h
    val maxSpeed: Float = 0f, // km/h
    val routePoints: List<RoutePoint> = emptyList(),
    val harshBrakes: Int = 0,
    val sharpTurns: Int = 0,
    val speedViolations: Int = 0,
    val safetyScore: Int = 100,
    val vehicleType: String = "",
    val vehicleNumber: String = "",
    val status: String = "active", // active, completed, cancelled
    val createdAt: Long = System.currentTimeMillis()
)

@IgnoreExtraProperties
data class CrashEvent(
    val id: String = "",
    val rideId: String = "",
    val userId: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val speed: Float = 0f,
    val severity: String = "Medium", // Low, Medium, High, Critical
    val vehicleType: String = "",
    val vehicleNumber: String = "",
    val videoPath: String = "",
    val status: String = "detected", // detected, confirmed, false_alarm
    val sensorData: SensorData? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@IgnoreExtraProperties
data class SensorData(
    val accelerometerX: Float = 0f,
    val accelerometerY: Float = 0f,
    val accelerometerZ: Float = 0f,
    val gyroscopeX: Float = 0f,
    val gyroscopeY: Float = 0f,
    val gyroscopeZ: Float = 0f,
    val magnitude: Float = 0f,
    val timestamp: Long = System.currentTimeMillis()
)

@IgnoreExtraProperties
data class Alert(
    val id: String = "",
    val crashEventId: String = "",
    val userId: String = "",
    val alertType: String = "crash", // crash, sos, manual
    val timestamp: Long = System.currentTimeMillis(),
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val status: String = "pending", // pending, sent, delivered, responded
    val emergencyContactsNotified: List<String> = emptyList(), // Contact IDs
    val smsSent: Boolean = false,
    val callMade: Boolean = false,
    val whatsappSent: Boolean = false,
    val hospitalNotified: Boolean = false,
    val ambulanceRequested: Boolean = false,
    val responseTime: Long? = null,
    val resolvedTime: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@IgnoreExtraProperties
data class Hospital(
    val id: String = "",
    val name: String = "",
    val address: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val phone: String = "",
    val emergencyPhone: String = "",
    val hasAmbulance: Boolean = false,
    val availableAmbulances: Int = 0,
    val rating: Float = 0f,
    val distance: Double = 0.0, // Calculated field
    val createdAt: Long = System.currentTimeMillis()
)

@IgnoreExtraProperties
data class Ambulance(
    val id: String = "",
    val hospitalId: String = "",
    val hospitalName: String = "",
    val vehicleNumber: String = "",
    val driverName: String = "",
    val driverPhone: String = "",
    val currentLatitude: Double = 0.0,
    val currentLongitude: Double = 0.0,
    val isAvailable: Boolean = true,
    val currentMissionId: String? = null,
    val status: String = "available", // available, dispatched, on_mission, maintenance
    val createdAt: Long = System.currentTimeMillis()
)

@IgnoreExtraProperties
data class RoutePoint(
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val timestamp: Long = 0L,
    val speed: Float = 0f
)

// Legacy models for backward compatibility
@IgnoreExtraProperties
data class AccidentReport(
    val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val userPhone: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val speed: Float = 0f,
    val severity: String = "Medium",
    val vehicleType: String = "",
    val vehicleName: String = "",
    val vehicleNumber: String = "",
    val videoPath: String = "",
    val status: String = "pending",
    val assignedAmbulanceId: String? = null,
    val assignedHospitalId: String? = null,
    val responseTime: Long? = null,
    val resolvedTime: Long? = null
)

@IgnoreExtraProperties
data class TravelHistory(
    val id: String = "",
    val userId: String = "",
    val startTime: Long = 0L,
    val endTime: Long = 0L,
    val duration: Long = 0L,
    val distance: Double = 0.0,
    val avgSpeed: Float = 0f,
    val maxSpeed: Float = 0f,
    val routePoints: List<RoutePoint> = emptyList(),
    val harshBrakes: Int = 0,
    val sharpTurns: Int = 0,
    val speedViolations: Int = 0,
    val safetyScore: Int = 100,
    val accidentDetected: Boolean = false,
    val vehicleType: String = "",
    val vehicleNumber: String = ""
)

@IgnoreExtraProperties
data class EmergencyMission(
    val id: String = "",
    val accidentId: String = "",
    val ambulanceId: String = "",
    val hospitalId: String = "",
    val victimLatitude: Double = 0.0,
    val victimLongitude: Double = 0.0,
    val status: String = "dispatched",
    val dispatchTime: Long = System.currentTimeMillis(),
    val acceptedTime: Long? = null,
    val arrivalTime: Long? = null,
    val completionTime: Long? = null,
    val eta: Int = 0,
    val liveTrackingUrl: String = "",
    val riderId: String = "",
    val riderName: String = "",
    val riderPhone: String = "",
    val severity: String = "Medium"
)

@IgnoreExtraProperties
data class Notification(
    val id: String = "",
    val userId: String = "",
    val title: String = "",
    val message: String = "",
    val type: String = "info",
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val actionUrl: String? = null
)

@IgnoreExtraProperties
data class AdminDashboard(
    val hospitalId: String = "",
    val hospitalName: String = "",
    val totalAccidents: Int = 0,
    val pendingAccidents: Int = 0,
    val resolvedAccidents: Int = 0,
    val availableAmbulances: Int = 0,
    val totalAmbulances: Int = 0,
    val averageResponseTime: Long = 0L,
    val lastUpdated: Long = System.currentTimeMillis()
)

@IgnoreExtraProperties
data class CrashAlert(
    val alertId: String = "",
    val userId: String = "",
    val userName: String = "",
    val userPhone: String = "",
    val hospitalId: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val speed: Float = 0f,
    val severity: String = "Medium",
    val status: String = "pending",
    val assignedDriver: String? = null,
    val assignedAmbulanceId: String? = null,
    val nearestHospital: String = "",
    val nearestHospitalDistance: Double = 0.0,
    val responseTime: Long? = null,
    val resolvedTime: Long? = null
)
