package com.example.ridealertz.admin

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.example.ridealertz.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class AdminDashboardActivity : ComponentActivity() {
    private val firebaseRepository = FirebaseRepository.getInstance()
    private var hospitalId: String = ""
    private var hospitalName: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Get hospital info from intent or shared preferences
        hospitalId = intent.getStringExtra("hospitalId") ?: "H01" // Default for demo
        hospitalName = intent.getStringExtra("hospitalName") ?: "Apollo Hospital"
        
        setContent {
            MaterialTheme {
                AdminDashboardScreen(
                    hospitalId = hospitalId,
                    hospitalName = hospitalName,
                    onBackPressed = { finish() },
                    onCallRider = { phone -> callRider(phone) },
                    onDispatchAmbulance = { alertId, ambulanceId, driverName -> 
                        dispatchAmbulance(alertId, ambulanceId, driverName) 
                    },
                    onTrackLocation = { lat, lng -> openLocationInMaps(lat, lng) },
                    onResolveAlert = { alertId -> resolveAlert(alertId) }
                )
            }
        }
    }
    
    private fun callRider(phone: String) {
        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:$phone")
        }
        startActivity(intent)
    }
    
    private fun dispatchAmbulance(alertId: String, ambulanceId: String, driverName: String) {
        lifecycleScope.launch {
            val result = firebaseRepository.dispatchAmbulance(alertId, ambulanceId, driverName)
            result.onSuccess {
                // Show success message
            }.onFailure { error ->
                // Show error message
            }
        }
    }
    
    private fun openLocationInMaps(lat: Double, lng: Double) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("geo:$lat,$lng?q=$lat,$lng")
        }
        startActivity(intent)
    }
    
    private fun resolveAlert(alertId: String) {
        lifecycleScope.launch {
            val result = firebaseRepository.resolveCrashAlert(alertId)
            result.onSuccess {
                // Show success message
            }.onFailure { error ->
                // Show error message
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    hospitalId: String,
    hospitalName: String,
    onBackPressed: () -> Unit,
    onCallRider: (String) -> Unit,
    onDispatchAmbulance: (String, String, String) -> Unit,
    onTrackLocation: (Double, Double) -> Unit,
    onResolveAlert: (String) -> Unit
) {
    val firebaseRepository = FirebaseRepository.getInstance()
    var dashboard by remember { mutableStateOf<AdminDashboard?>(null) }
    var crashAlerts by remember { mutableStateOf<List<CrashAlert>>(emptyList()) }
    var availableAmbulances by remember { mutableStateOf<List<Ambulance>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    
    LaunchedEffect(hospitalId) {
        // Load dashboard data
        val dashboardResult = firebaseRepository.getAdminDashboard(hospitalId)
        dashboardResult.onSuccess { dashboard = it }
        
        // Load available ambulances
        val ambulancesResult = firebaseRepository.getAvailableAmbulances(hospitalId)
        ambulancesResult.onSuccess { availableAmbulances = it }
        
        isLoading = false
    }
    
    // Observe crash alerts in real-time
    LaunchedEffect(hospitalId) {
        firebaseRepository.observeCrashAlertsForHospital(hospitalId).collect { alerts ->
            crashAlerts = alerts
        }
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        "Hospital Dashboard",
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackPressed) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { padding ->
        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Color(0xFFF5F5F5))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Hospital Info Header
                item {
                    HospitalInfoCard(hospitalName = hospitalName)
                }
                
                // Dashboard Stats
                item {
                    DashboardStatsCard(dashboard = dashboard)
                }
                
                // Available Ambulances
                item {
                    AvailableAmbulancesCard(
                        ambulances = availableAmbulances,
                        onDispatchAmbulance = onDispatchAmbulance
                    )
                }
                
                // Crash Alerts
                item {
                    Text(
                        text = "🚨 Active Crash Alerts",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
                
                items(crashAlerts.filter { it.status == "pending" }) { alert ->
                    CrashAlertCard(
                        alert = alert,
                        onCallRider = onCallRider,
                        onDispatchAmbulance = onDispatchAmbulance,
                        onTrackLocation = onTrackLocation,
                        onResolveAlert = onResolveAlert,
                        availableAmbulances = availableAmbulances
                    )
                }
                
                if (crashAlerts.filter { it.status == "pending" }.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "✅ No active alerts",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HospitalInfoCard(hospitalName: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD)),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.LocalHospital,
                contentDescription = null,
                tint = Color(0xFF1976D2),
                modifier = Modifier.size(32.dp)
            )
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column {
                Text(
                    text = hospitalName,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1976D2)
                )
                Text(
                    text = "Emergency Response Center",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF1565C0)
                )
            }
        }
    }
}

@Composable
fun DashboardStatsCard(dashboard: AdminDashboard?) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Text(
                text = "📊 Dashboard Statistics",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                StatItem(
                    label = "Total Accidents",
                    value = dashboard?.totalAccidents?.toString() ?: "0",
                    color = Color(0xFF2196F3)
                )
                StatItem(
                    label = "Pending",
                    value = dashboard?.pendingAccidents?.toString() ?: "0",
                    color = Color(0xFFFF9800)
                )
                StatItem(
                    label = "Resolved",
                    value = dashboard?.resolvedAccidents?.toString() ?: "0",
                    color = Color(0xFF4CAF50)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                StatItem(
                    label = "Available Ambulances",
                    value = "${dashboard?.availableAmbulances ?: 0}/${dashboard?.totalAmbulances ?: 0}",
                    color = Color(0xFF9C27B0)
                )
            }
        }
    }
}

@Composable
fun StatItem(label: String, value: String, color: Color) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = color
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun AvailableAmbulancesCard(
    ambulances: List<Ambulance>,
    onDispatchAmbulance: (String, String, String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Text(
                text = "🚑 Available Ambulances",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            
            if (ambulances.isEmpty()) {
                Text(
                    text = "No ambulances available",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                ambulances.forEach { ambulance ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalHospital,
                            contentDescription = null,
                            tint = Color(0xFF4CAF50),
                            modifier = Modifier.size(20.dp)
                        )
                        
                        Spacer(modifier = Modifier.width(12.dp))
                        
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = ambulance.vehicleNumber,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Driver: ${ambulance.driverName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        
                        Text(
                            text = "Available",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF4CAF50),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CrashAlertCard(
    alert: CrashAlert,
    onCallRider: (String) -> Unit,
    onDispatchAmbulance: (String, String, String) -> Unit,
    onTrackLocation: (Double, Double) -> Unit,
    onResolveAlert: (String) -> Unit,
    availableAmbulances: List<Ambulance>
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = Color(0xFFD32F2F),
                    modifier = Modifier.size(24.dp)
                )
                
                Spacer(modifier = Modifier.width(12.dp))
                
                Text(
                    text = "🚨 Accident Detected!",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFD32F2F)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            AlertDetailRow("Rider", alert.userName)
            AlertDetailRow("Phone", alert.userPhone)
            AlertDetailRow("Location", "${String.format("%.4f", alert.latitude)}, ${String.format("%.4f", alert.longitude)}")
            AlertDetailRow("Time", SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(alert.timestamp)))
            AlertDetailRow("Speed", "${alert.speed.toInt()} km/h")
            AlertDetailRow("Severity", alert.severity)
            AlertDetailRow("Nearest Hospital", "${alert.nearestHospital} (${String.format("%.1f", alert.nearestHospitalDistance)} km)")
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { onCallRider(alert.userPhone) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))
                ) {
                    Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Call Rider", fontSize = 12.sp)
                }
                
                Button(
                    onClick = { onTrackLocation(alert.latitude, alert.longitude) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2196F3))
                ) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Track", fontSize = 12.sp)
                }
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            if (availableAmbulances.isNotEmpty()) {
                Button(
                    onClick = { 
                        val ambulance = availableAmbulances.first()
                        onDispatchAmbulance(alert.alertId, ambulance.id, ambulance.driverName)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))
                ) {
                    Icon(Icons.Default.LocalHospital, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("🚑 Dispatch Ambulance")
                }
            } else {
                Text(
                    text = "⚠️ No ambulances available",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFFFF9800),
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun AlertDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = "$label:",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium
        )
    }
}
