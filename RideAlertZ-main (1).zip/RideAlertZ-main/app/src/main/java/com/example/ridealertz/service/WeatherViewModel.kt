package com.example.ridealertz.service

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class WeatherUiState(
    val isLoading: Boolean = false,
    val data: WeatherData? = null,
    val hourly: List<HourlyForecast> = emptyList(),
    val daily: List<DailyForecast> = emptyList(),
    val error: String? = null
)

class WeatherViewModel(
    application: Application,
    private val weatherService: WeatherService = WeatherService()
) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("ridealertz", Context.MODE_PRIVATE)
    private val _uiState = MutableStateFlow(WeatherUiState(isLoading = true))
    val uiState: StateFlow<WeatherUiState> = _uiState.asStateFlow()

    init {
        refreshWeather()
    }

    fun refreshWeather() {
        viewModelScope.launch {
            val lat = prefs.getFloat("last_lat", Float.NaN).takeUnless { it.isNaN() }?.toDouble()
            val lng = prefs.getFloat("last_lng", Float.NaN).takeUnless { it.isNaN() }?.toDouble()
            if (lat == null || lng == null) {
                _uiState.value = WeatherUiState(error = "Location unavailable", isLoading = false)
                return@launch
            }
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)
            val current = weatherService.getCurrentWeather(lat, lng)
            val hourly = weatherService.getHourlyForecast(lat, lng) ?: emptyList()
            val daily = weatherService.getDailyForecast(lat, lng) ?: emptyList()
            _uiState.value = WeatherUiState(
                isLoading = false,
                data = current,
                hourly = hourly,
                daily = daily,
                error = current?.let { null } ?: "Weather unavailable"
            )
        }
    }
}
