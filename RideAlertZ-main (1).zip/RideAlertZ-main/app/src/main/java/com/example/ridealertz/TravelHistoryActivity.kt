package com.example.ridealertz

import android.os.Bundle
import android.preference.PreferenceManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.example.ridealertz.data.FirebaseRepository
import com.example.ridealertz.data.TravelHistory
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class TravelHistoryActivity : ComponentActivity() {
    private lateinit var firebaseRepo: FirebaseRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        firebaseRepo = FirebaseRepository.getInstance()
        
        setContent {
            MaterialTheme {
                TravelHistoryScreen(
                    onBackPressed = { finish() }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TravelHistoryScreen(
    onBackPressed: () -> Unit
) {
    var travels by remember { mutableStateOf<List<TravelHistory>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var selectedTravel by remember { mutableStateOf<TravelHistory?>(null) }
    
    val firebaseRepo = FirebaseRepository.getInstance()
    
    // Load travel history
    LaunchedEffect(Unit) {
        // Mock user ID - replace with actual user ID from auth
        val result = firebaseRepo.getUserTravelHistory("user123", 50)
        result.onSuccess {
            travels = it
            isLoading = false
        }.onFailure {
            isLoading = false
        }
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        "Travel History",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackPressed) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.surfaceVariant
                        )
                    )
                )
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center)
                )
            } else if (selectedTravel != null) {
                TravelDetailView(
                    travel = selectedTravel!!,
                    onBack = { selectedTravel = null }
                )
            } else {
                TravelListView(
                    travels = travels,
                    onTravelClick = { selectedTravel = it }
                )
            }
        }
    }
}

@Composable
fun TravelListView(
    travels: List<TravelHistory>,
    onTravelClick: (TravelHistory) -> Unit
) {
    if (travels.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    Icons.Default.DirectionsCar,
                    contentDescription = null,
                    modifier = Modifier.size(64.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    "No travel history yet",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "Start a ride to track your journey",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    } else {
        Column(modifier = Modifier.fillMaxSize()) {
            // Summary Stats
            TravelSummaryCard(travels)
            
            // Travel List
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(travels) { travel ->
                    TravelCard(
                        travel = travel,
                        onClick = { onTravelClick(travel) }
                    )
                }
            }
        }
    }
}

@Composable
fun TravelSummaryCard(travels: List<TravelHistory>) {
    val totalDistance = travels.sumOf { it.distance }
    val totalTrips = travels.size
    val avgScore = if (travels.isNotEmpty()) travels.map { it.safetyScore }.average().toInt() else 0
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            SummaryItem(
                icon = Icons.Default.Route,
                value = "${String.format("%.1f", totalDistance)} km",
                label = "Total Distance"
            )
            SummaryItem(
                icon = Icons.Default.DirectionsCar,
                value = "$totalTrips",
                label = "Total Trips"
            )
            SummaryItem(
                icon = Icons.Default.Star,
                value = "$avgScore",
                label = "Avg Score"
            )
        }
    }
}

@Composable
fun SummaryItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    value: String,
    label: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            icon,
            contentDescription = null,
            modifier = Modifier.size(24.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun TravelCard(
    travel: TravelHistory,
    onClick: () -> Unit
) {
    val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
    val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
    val durationMinutes = (travel.duration / 60000).toInt()
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = dateFormat.format(Date(travel.startTime)),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${timeFormat.format(Date(travel.startTime))} - ${timeFormat.format(Date(travel.endTime))}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                
                // Safety Score Badge
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                travel.safetyScore >= 90 -> Color(0xFF4CAF50)
                                travel.safetyScore >= 70 -> Color(0xFFFFC107)
                                else -> Color(0xFFE53E3E)
                            }.copy(alpha = 0.2f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${travel.safetyScore}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = when {
                            travel.safetyScore >= 90 -> Color(0xFF2E7D32)
                            travel.safetyScore >= 70 -> Color(0xFFF57C00)
                            else -> Color(0xFFB71C1C)
                        }
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Stats Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TravelStat(
                    icon = Icons.Default.Route,
                    value = "${String.format("%.1f", travel.distance)} km"
                )
                TravelStat(
                    icon = Icons.Default.Timer,
                    value = "$durationMinutes min"
                )
                TravelStat(
                    icon = Icons.Default.Speed,
                    value = "${String.format("%.0f", travel.avgSpeed)} km/h"
                )
            }
            
            // Warnings (if any)
            if (travel.harshBrakes > 0 || travel.sharpTurns > 0 || travel.speedViolations > 0) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (travel.harshBrakes > 0) {
                        WarningChip("⚠️ ${travel.harshBrakes} harsh brakes")
                    }
                    if (travel.sharpTurns > 0) {
                        WarningChip("🔄 ${travel.sharpTurns} sharp turns")
                    }
                    if (travel.speedViolations > 0) {
                        WarningChip("🚨 ${travel.speedViolations} speed alerts")
                    }
                }
            }
            
            // Accident Warning
            if (travel.accidentDetected) {
                Spacer(modifier = Modifier.height(12.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFE53E3E).copy(alpha = 0.1f))
                        .padding(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Warning,
                            contentDescription = null,
                            tint = Color(0xFFE53E3E),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Accident detected during this trip",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFB71C1C),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TravelStat(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    value: String
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            icon,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun WarningChip(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFFFC107).copy(alpha = 0.2f))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFFF57C00),
            fontWeight = FontWeight.Medium
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TravelDetailView(
    travel: TravelHistory,
    onBack: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Back button
        IconButton(
            onClick = onBack,
            modifier = Modifier.padding(8.dp)
        ) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
        }
        
        // Placeholder where the map used to be
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF111827)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Route map disabled",
                    color = Color(0xFF9CA3AF),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        
        // Trip details
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Trip Details",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))
                
                DetailRow("Distance", "${String.format("%.2f", travel.distance)} km")
                DetailRow("Duration", "${(travel.duration / 60000)} minutes")
                DetailRow("Avg Speed", "${String.format("%.1f", travel.avgSpeed)} km/h")
                DetailRow("Max Speed", "${String.format("%.1f", travel.maxSpeed)} km/h")
                DetailRow("Safety Score", "${travel.safetyScore}/100")
                DetailRow("Vehicle", "${travel.vehicleType} - ${travel.vehicleNumber}")
            }
        }
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold
        )
    }
}
