package com.example.ridealertz

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.edit
import com.example.ridealertz.ui.theme.RideAlertzTheme

class VehicleSelectionActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        setContent {
            RideAlertzTheme {
                VehicleSelectionScreen(
                    onVehicleSelected = { vehicleType, vehicleName ->
                        saveVehicleInfo(vehicleType, vehicleName)
                        navigateToMain()
                    }
                )
            }
        }
    }
    
    private fun saveVehicleInfo(vehicleType: String, vehicleName: String) {
        val prefs = getSharedPreferences("ridealertz", MODE_PRIVATE)
        prefs.edit {
            putString("vehicle_type", vehicleType)
            putString("vehicle_name", vehicleName)
            putBoolean("vehicle_selected", true)
        }
    }
    
    private fun navigateToMain() {
        startActivity(Intent(this, MainActivityNew::class.java))
        finish()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VehicleSelectionScreen(
    onVehicleSelected: (String, String) -> Unit
) {
    var selectedVehicle by remember { mutableStateOf<String?>(null) }
    var showNameDialog by remember { mutableStateOf(false) }
    
    Scaffold(
        containerColor = Color(0xFF1A1A1A)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Title
            Text(
                text = "Select Your Vehicle Type 🚘",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text(
                text = "Choose your primary mode of transport",
                fontSize = 16.sp,
                color = Color.Gray,
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(48.dp))
            
            // Vehicle Options
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Bike Option
                VehicleCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.TwoWheeler,
                    title = "Bike",
                    emoji = "🏍️",
                    isSelected = selectedVehicle == "Bike",
                    color = Color(0xFFEF4444),
                    onClick = {
                        selectedVehicle = "Bike"
                        showNameDialog = true
                    }
                )
                
                // Car Option
                VehicleCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.DirectionsCar,
                    title = "Car",
                    emoji = "🚗",
                    isSelected = selectedVehicle == "Car",
                    color = Color(0xFF6366F1),
                    onClick = {
                        selectedVehicle = "Car"
                        showNameDialog = true
                    }
                )
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Info Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF2A2A2A)
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp)
                ) {
                    Text(
                        text = "💡 Why we need this?",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFF59E0B)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• Customized speed limits (Bike: 90 km/h, Car: 120 km/h)\n" +
                              "• Better crash detection algorithms\n" +
                              "• Accurate driving behavior analysis\n" +
                              "• Personalized safety tips",
                        fontSize = 14.sp,
                        color = Color.Gray,
                        lineHeight = 20.sp
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text(
                text = "You can change this later in Settings",
                fontSize = 12.sp,
                color = Color.Gray,
                textAlign = TextAlign.Center
            )
        }
    }
    
    // Vehicle Name Dialog
    if (showNameDialog && selectedVehicle != null) {
        VehicleNameDialog(
            vehicleType = selectedVehicle!!,
            onDismiss = { showNameDialog = false },
            onConfirm = { name ->
                showNameDialog = false
                onVehicleSelected(selectedVehicle!!, name)
            }
        )
    }
}

@Composable
fun VehicleCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    title: String,
    emoji: String,
    isSelected: Boolean,
    color: Color,
    onClick: () -> Unit
) {
    val scale by animateFloatAsState(
        targetValue = if (isSelected) 1.05f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "scale"
    )
    
    Card(
        modifier = modifier
            .aspectRatio(0.85f)
            .scale(scale)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) color.copy(alpha = 0.2f) else Color(0xFF2A2A2A)
        ),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (isSelected) 8.dp else 2.dp
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .then(
                    if (isSelected) {
                        Modifier.border(
                            width = 3.dp,
                            color = color,
                            shape = RoundedCornerShape(20.dp)
                        )
                    } else Modifier
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Emoji
                Text(
                    text = emoji,
                    fontSize = 64.sp
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Icon
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = if (isSelected) color else Color.Gray,
                    modifier = Modifier.size(48.dp)
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // Title
                Text(
                    text = title,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) color else Color.White
                )
                
                if (isSelected) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "✓ Selected",
                        fontSize = 12.sp,
                        color = color,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VehicleNameDialog(
    vehicleType: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var vehicleName by remember { mutableStateOf("") }
    
    val suggestions = if (vehicleType == "Bike") {
        listOf("Yamaha R15", "Royal Enfield", "Honda CBR", "KTM Duke", "Bajaj Pulsar", "Custom")
    } else {
        listOf("Hyundai i20", "Maruti Swift", "Honda City", "Tata Nexon", "Mahindra XUV", "Custom")
    }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF2A2A2A),
        title = {
            Text(
                text = "Name Your $vehicleType",
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column {
                Text(
                    text = "Choose a model or enter custom name",
                    color = Color.Gray,
                    fontSize = 14.sp
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Suggestions
                suggestions.forEach { suggestion ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable {
                                if (suggestion != "Custom") {
                                    vehicleName = suggestion
                                }
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = if (vehicleName == suggestion) 
                                Color(0xFF6366F1).copy(alpha = 0.3f) 
                            else Color(0xFF1A1A1A)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = suggestion,
                            modifier = Modifier.padding(12.dp),
                            color = Color.White,
                            fontSize = 14.sp
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // Custom input
                OutlinedTextField(
                    value = vehicleName,
                    onValueChange = { vehicleName = it },
                    label = { Text("Or type custom name", color = Color.Gray) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF6366F1),
                        unfocusedBorderColor = Color.Gray,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = Color(0xFF6366F1),
                        focusedLabelColor = Color.Gray,
                        unfocusedLabelColor = Color.Gray
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (vehicleName.isNotBlank()) {
                        onConfirm(vehicleName)
                    }
                },
                enabled = vehicleName.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF6366F1)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Confirm")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                colors = ButtonDefaults.textButtonColors(
                    contentColor = Color.Gray
                )
            ) {
                Text("Cancel")
            }
        }
    )
}
