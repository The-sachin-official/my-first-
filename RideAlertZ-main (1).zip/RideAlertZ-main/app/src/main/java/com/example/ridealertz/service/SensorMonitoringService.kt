package com.example.ridealertz.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.ridealertz.MainActivityNew
import com.example.ridealertz.R
import android.app.Service
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import android.location.Location
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.Priority
import android.telephony.SmsManager
import android.content.SharedPreferences
import kotlin.math.sqrt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.FileInputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import org.tensorflow.lite.Interpreter
import java.io.IOException
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.isActive
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import org.tensorflow.lite.task.audio.classifier.AudioClassifier
import org.tensorflow.lite.task.audio.classifier.Classifications

class SensorMonitoringService : Service(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var gyroscope: Sensor? = null
    private var rotationVector: Sensor? = null

    private var lastAccelMagnitude: Double = 0.0
    private var lastTimestampNs: Long = 0L
    private var lastAlertMs: Long = 0L

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var prefs: SharedPreferences
    private var lastKnownLocation: Location? = null
    private lateinit var behaviorAnalyzer: DrivingBehaviorAnalyzer
    private var lastSpeedKmh: Double = 0.0
    private var lastEmergencyCallMs: Long = 0L
    private var lastDeltaMeters: Float = 0f
    private var lastLocationForDelta: Location? = null

    private var crashMlDetector: CrashMlDetector? = null
    private var lastMlCrashProb: Float = 0f

    private val latestAccel = FloatArray(3)
    private val latestGyro = FloatArray(3)
    private val latestOrientation = FloatArray(2)

    private var crashSoundPlayer: MediaPlayer? = null
    private var audioCrashDetector: AudioCrashDetector? = null
    private var lastAudioCrashProb: Float = 0f
    private val adaptiveThresholds = AdaptiveThresholdManager()
    private var currentAccelThreshold = 5.0f
    private var currentGyroThreshold = 0.7f
    private var lastGyroMagnitude: Double = 0.0
    private var lastFusionScore: Float = 0f
    private val sensorFusion = SensorFusionEngine()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        rotationVector = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        startInForeground()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        prefs = getSharedPreferences("ridealertz", MODE_PRIVATE)
        behaviorAnalyzer = DrivingBehaviorAnalyzer(this)
        crashMlDetector = CrashMlDetector(this)
        audioCrashDetector = AudioCrashDetector(this) { probability ->
            lastAudioCrashProb = probability
            if (probability > 0f) {
                Log.d("SensorMonitoring", "Audio crash probability=${"%.2f".format(probability)}")
            }
            CrashDebugBus.update(audioProb = probability)
        }
        CrashLogger.start(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        gyroscope?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        rotationVector?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        requestLocationUpdates()
        audioCrashDetector?.start()
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        sensorManager.unregisterListener(this)
        crashMlDetector?.close()
        audioCrashDetector?.stop()
        CrashLogger.stop()

        // Release crash sound player
        try {
            crashSoundPlayer?.release()
        } catch (_: Exception) { }
        crashSoundPlayer = null
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> handleAccelerometer(event)
            Sensor.TYPE_GYROSCOPE -> handleGyroscope(event)
            Sensor.TYPE_ROTATION_VECTOR -> handleRotation(event)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun handleAccelerometer(event: SensorEvent) {
        val ax = event.values[0].toDouble()
        val ay = event.values[1].toDouble()
        val az = event.values[2].toDouble()
        val magnitude = sqrt(ax * ax + ay * ay + az * az)
        val now = event.timestamp // ns

        latestAccel[0] = ax.toFloat()
        latestAccel[1] = ay.toFloat()
        latestAccel[2] = az.toFloat()
        val accelMagFloat = magnitude.toFloat()

        // Test-friendly impact threshold: 5 m/s^2 (make easier to trigger during testing)
        adaptiveThresholds.updateAccel(accelMagFloat)
        currentAccelThreshold = adaptiveThresholds.accelThreshold()
        val impact = magnitude > currentAccelThreshold
        if (impact) pendingAccelHitMs = System.currentTimeMillis()

        Log.d(
            "SensorMonitoring",
            "ACC mag=${"%.2f".format(magnitude)} impact=$impact speed=${"%.2f".format(lastSpeedKmh)} km/h threshold=$currentAccelThreshold"
        )

        lastAccelMagnitude = magnitude
        lastTimestampNs = now
        CrashDebugBus.update(accelMag = accelMagFloat)
        
        // Analyze for driving behavior
        behaviorAnalyzer.analyzeAccelerometer(event)
        feedMlSample()
    }

    private fun handleGyroscope(event: SensorEvent) {
        val wx = event.values[0].toDouble()
        val wy = event.values[1].toDouble()
        val wz = event.values[2].toDouble()
        val magnitude = sqrt(wx * wx + wy * wy + wz * wz)
        latestGyro[0] = wx.toFloat()
        latestGyro[1] = wy.toFloat()
        latestGyro[2] = wz.toFloat()
        val gyroMagFloat = magnitude.toFloat()

        // Test-friendly rotation threshold: 0.7 rad/s (make easier to trigger during testing)
        adaptiveThresholds.updateGyro(gyroMagFloat)
        currentGyroThreshold = adaptiveThresholds.gyroThreshold()
        val rotationHit = magnitude > currentGyroThreshold
        if (rotationHit) pendingGyroHitMs = System.currentTimeMillis()

        Log.d(
            "SensorMonitoring",
            "GYRO mag=${"%.2f".format(magnitude)} hit=$rotationHit threshold=$currentGyroThreshold"
        )

        lastGyroMagnitude = magnitude
        CrashDebugBus.update(gyroMag = gyroMagFloat)

        // Analyze for driving behavior (sharp turns)
        behaviorAnalyzer.analyzeGyroscope(event)
    }

    private var pendingAccelHitMs: Long = 0L
    private var pendingGyroHitMs: Long = 0L
    private fun tryCombinedTrigger() {
        val nowMs = System.currentTimeMillis()
        val accelRecent = pendingAccelHitMs != 0L && (nowMs - pendingAccelHitMs) <= 2000
        val gyroRecent = pendingGyroHitMs != 0L && (nowMs - pendingGyroHitMs) <= 2000
        val tiltExceeded = currentTiltDegrees >= 45f // lower tilt for easier testing

        Log.d(
            "SensorMonitoring",
            "CHECK accelRecent=$accelRecent gyroRecent=$gyroRecent tilt=$currentTiltDegrees speed=${"%.2f".format(lastSpeedKmh)}"
        )

        val snapshot = SensorSnapshot(
            mlProb = lastMlCrashProb,
            audioProb = lastAudioCrashProb,
            accelMagnitude = lastAccelMagnitude.toFloat(),
            gyroMagnitude = lastGyroMagnitude.toFloat(),
            tiltDegrees = currentTiltDegrees,
            accelThreshold = currentAccelThreshold,
            gyroThreshold = currentGyroThreshold,
            accelRecent = accelRecent,
            gyroRecent = gyroRecent,
            tiltExceeded = tiltExceeded
        )
        val fusion = sensorFusion.evaluate(snapshot)
        lastFusionScore = fusion.finalScore
        CrashDebugBus.update(finalScore = fusion.finalScore)

        if (fusion.triggered) {
            notifyPossibleAccident(currentTiltDegrees.toDouble())
            launchConfirmation()
            lastMlCrashProb = 0f
            lastAudioCrashProb = 0f
        } else if (fusion.strongMotion) {
            launchEmergencyCall()
        }

        CrashLogger.logSample(
            CrashSample(
                timestamp = System.currentTimeMillis(),
                audioProb = snapshot.audioProb,
                accelMag = snapshot.accelMagnitude,
                gyroMag = snapshot.gyroMagnitude,
                tilt = snapshot.tiltDegrees,
                finalScore = fusion.finalScore,
                accelThreshold = snapshot.accelThreshold,
                gyroThreshold = snapshot.gyroThreshold,
                triggered = fusion.triggered
            )
        )
    }

    private fun handleRotation(event: SensorEvent) {
        val rotationMatrix = FloatArray(9)
        SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
        val orientations = FloatArray(3)
        SensorManager.getOrientation(rotationMatrix, orientations)
        val pitch = Math.toDegrees(orientations[1].toDouble()).toFloat()
        val roll = Math.toDegrees(orientations[2].toDouble()).toFloat()
        latestOrientation[0] = pitch
        latestOrientation[1] = roll
        currentTiltDegrees = kotlin.math.max(kotlin.math.abs(pitch), kotlin.math.abs(roll))
        tryCombinedTrigger()
    }

    private var currentTiltDegrees: Float = 0f

    private fun notifyPossibleAccident(intensity: Double) {
        val manager = NotificationManagerCompat.from(this)
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Possible accident detected")
            .setContentText("Intensity: %.1f".format(intensity))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        manager.notify(ACCIDENT_NOTIFICATION_ID, notification)
    }

    private fun startInForeground() {
        createChannel()
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivityNew::class.java),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
        )
        val stopIntent = PendingIntent.getBroadcast(
            this,
            1,
            Intent(this, StopRideReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("RideAlertz")
            .setContentText("Monitoring active. Safe ride initiated.")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .addAction(
                NotificationCompat.Action.Builder(
                    0,
                    "END RIDE",
                    stopIntent
                ).build()
            )
            .setOngoing(true)
            .build()
        startForeground(FOREGROUND_NOTIFICATION_ID, notification)
    }

    private fun fetchLocationAndSendSms() {
        try {
            val fresh = lastKnownLocation
            if (fresh != null) {
                sendSmsWithLocation(fresh)
            } else {
                fusedLocationClient.lastLocation
                    .addOnSuccessListener { location: Location? ->
                        sendSmsWithLocation(location)
                    }
                    .addOnFailureListener {
                        sendSmsWithLocation(null)
                    }
            }
        } catch (_: SecurityException) {
            // missing location permission
        }
    }

    private fun sendSmsWithLocation(location: Location?) {
        val emergencyContactsJson = prefs.getString("emergency_contacts", "[]")
        val emergencyContacts = try {
            val gson = com.google.gson.Gson()
            val type = object : com.google.gson.reflect.TypeToken<List<EmergencyContact>>() {}.type
            gson.fromJson<List<EmergencyContact>>(emergencyContactsJson, type)
        } catch (e: Exception) {
            emptyList()
        }
        
        if (emergencyContacts.isEmpty()) return
        
        val message = buildString {
            append("🚨 RIDEALERTZ EMERGENCY ALERT 🚨\n")
            append("Possible accident detected!\n\n")
            if (location != null) {
                append("📍 Location: ")
                append(location.latitude)
                append(", ")
                append(location.longitude)
                append("\n")
                append("🗺️ Maps: https://maps.google.com/?q=")
                append(location.latitude)
                append(",")
                append(location.longitude)
                append("\n")
                append("⏰ Time: ${java.text.SimpleDateFormat("MMM dd, yyyy 'at' HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())}")
            } else {
                append("📍 Location unavailable")
            }
        }
        
        try {
            @Suppress("DEPRECATION")
            val sms = SmsManager.getDefault()
            emergencyContacts.forEach { contact ->
                sms.sendTextMessage(contact.phone, null, message, null, null)
            }
        } catch (_: SecurityException) {
            // missing SMS permission
        }
    }
    
    data class EmergencyContact(
        val name: String,
        val phone: String,
        val initials: String,
        var isPrimary: Boolean = false
    )

    private fun requestLocationUpdates() {
        try {
            val request = LocationRequest.Builder(3000)
                .setPriority(Priority.PRIORITY_HIGH_ACCURACY)
                .setMinUpdateIntervalMillis(1500)
                .build()
            fusedLocationClient.requestLocationUpdates(
                request,
                { location: Location ->
                    val previous = lastKnownLocation
                    lastKnownLocation = location
                    // m/s * 3.6 = km/h
                    lastSpeedKmh = (location.speed * 3.6).toDouble()
                    previous?.let {
                        lastDeltaMeters = it.distanceTo(location)
                    } ?: run { lastDeltaMeters = 0f }
                    lastLocationForDelta = location
                    // Persist last known location for other screens/SMS to use
                    try {
                        prefs.edit()
                            .putFloat("last_lat", location.latitude.toFloat())
                            .putFloat("last_lng", location.longitude.toFloat())
                            .putFloat("last_acc", if (location.hasAccuracy()) location.accuracy else -1f)
                            .putLong("last_time", location.time)
                            .apply()
                    } catch (_: Exception) { }
                    
                    // Update behavior analyzer with location
                    behaviorAnalyzer.updateLocation(location)
                },
                mainLooper
            )
        } catch (_: SecurityException) {
        }
    }

    private fun feedMlSample() {
        val detector = crashMlDetector ?: return
        val sample = floatArrayOf(
            normalize(latestAccel[0], 20f),
            normalize(latestAccel[1], 20f),
            normalize(latestAccel[2], 20f),
            normalize(latestGyro[0], 10f),
            normalize(latestGyro[1], 10f),
            normalize(latestGyro[2], 10f),
            normalize(latestOrientation[0], 180f),
            normalize(latestOrientation[1], 180f),
            normalize(lastSpeedKmh.toFloat(), 160f),
            normalize(lastDeltaMeters, 50f),
            normalize(currentTiltDegrees, 90f),
            normalize(lastAccelMagnitude.toFloat(), 25f)
        )
        val probability = detector.addSample(sample)
        if (probability > 0f) {
            lastMlCrashProb = probability
            Log.d("SensorMonitoring", "ML crash probability=${"%.2f".format(probability)}")
        }
    }

    private fun normalize(value: Float, max: Float): Float {
        if (max == 0f) return 0f
        return (value / max).coerceIn(-1f, 1f)
    }

    private fun launchConfirmation() {
        Log.d("SensorMonitoring", "launchConfirmation: crash detected, opening CrashAlertActivity")
        playCrashSound()
        // Show crash alert screen first
        val intent = Intent(this, CrashAlertActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)

        // Log accident as before
        logAccident()
    }

    private fun launchEmergencyCall() {
        playCrashSound()
        // Use the same crash warning screen for extra emergency triggers
        val intent = Intent(this, CrashAlertActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }
    
    private fun playCrashSound() {
        try {
            // Stop any previous instance
            crashSoundPlayer?.stop()
            crashSoundPlayer?.release()
            crashSoundPlayer = null

            // Use system default notification sound as crash impact effect
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            crashSoundPlayer = MediaPlayer.create(this, uri)
            crashSoundPlayer?.setOnCompletionListener { mp ->
                try { mp.release() } catch (_: Exception) { }
                if (crashSoundPlayer === mp) {
                    crashSoundPlayer = null
                }
            }
            crashSoundPlayer?.start()
        } catch (_: Exception) { }
    }
    
    private fun logAccident() {
        val location = lastKnownLocation
        val vehicleType = prefs.getString("vehicle_type", "Unknown") ?: "Unknown"
        val vehicleName = prefs.getString("vehicle_name", "Unknown") ?: "Unknown"
        val vehicleNumber = prefs.getString("vehicle_number", "") ?: ""
        val userName = prefs.getString("user_name", "Unknown Rider") ?: "Unknown Rider"
        val userPhone = prefs.getString("user_phone", "") ?: ""
        val userId = prefs.getString("user_id", "") ?: ""
        
        val accident = AccidentRecord(
            timestamp = System.currentTimeMillis(),
            latitude = location?.latitude ?: 0.0,
            longitude = location?.longitude ?: 0.0,
            speed = location?.speed?.times(3.6f) ?: 0f,
            vehicleName = "$vehicleType - $vehicleName",
            vehicleNumber = vehicleNumber,
            severity = "High",
            videoPath = ""
        )
        
        // Save locally
        val gson = com.google.gson.Gson()
        val accidentsJson = prefs.getString("accident_log", "[]") ?: "[]"
        val type = object : com.google.gson.reflect.TypeToken<MutableList<AccidentRecord>>() {}.type
        val accidents: MutableList<AccidentRecord> = try {
            gson.fromJson(accidentsJson, type)
        } catch (e: Exception) {
            mutableListOf()
        }
        
        accidents.add(accident)
        prefs.edit()
            .putString("accident_log", gson.toJson(accidents))
            .apply()
        
        // Send to Firebase for emergency response
        sendAccidentToFirebase(userId, userName, userPhone, accident)
    }
    
    private fun sendAccidentToFirebase(userId: String, userName: String, userPhone: String, accident: AccidentRecord) {
        try {
            val firebaseRepository = com.example.ridealertz.data.FirebaseRepository.getInstance()
            
            val accidentReport = com.example.ridealertz.data.AccidentReport(
                userId = userId,
                userName = userName,
                userPhone = userPhone,
                timestamp = accident.timestamp,
                latitude = accident.latitude,
                longitude = accident.longitude,
                speed = accident.speed,
                severity = accident.severity,
                vehicleType = accident.vehicleName.split(" - ").firstOrNull() ?: "Unknown",
                vehicleName = accident.vehicleName,
                vehicleNumber = accident.vehicleNumber,
                videoPath = accident.videoPath,
                status = "pending"
            )
            
            // Report accident to Firebase in background
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val result = firebaseRepository.reportAccident(accidentReport)
                    result.onSuccess { accidentId ->
                        android.util.Log.d("SensorMonitoring", "Accident reported to Firebase: $accidentId")
                    }.onFailure { error ->
                        android.util.Log.e("SensorMonitoring", "Failed to report accident: ${error.message}")
                    }
                } catch (e: Exception) {
                    android.util.Log.e("SensorMonitoring", "Error reporting accident: ${e.message}")
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("SensorMonitoring", "Failed to send accident to Firebase: ${e.message}")
        }
    }
    
    data class AccidentRecord(
        val timestamp: Long,
        val latitude: Double,
        val longitude: Double,
        val speed: Float,
        val vehicleName: String,
        val vehicleNumber: String,
        val severity: String,
        val videoPath: String = ""
    )

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "RideAlertz Monitoring",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    companion object {
        private const val CHANNEL_ID = "ridealertz.monitor"
        private const val FOREGROUND_NOTIFICATION_ID = 1001
        private const val ACCIDENT_NOTIFICATION_ID = 2001
        private const val AUDIO_MODEL_FILE = "audio_crash_model.tflite"
        private const val AUDIO_CRASH_LABEL = "crash"
    }

    private inner class AudioCrashDetector(
        private val context: Context,
        private val onProbability: (Float) -> Unit
    ) {
        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        private val classifier: AudioClassifier? = try {
            AudioClassifier.createFromFile(context, AUDIO_MODEL_FILE)
        } catch (e: Exception) {
            Log.e("SensorMonitoring", "Audio classifier init failed: ${e.message}")
            null
        }
        private val tensorAudio = classifier?.createInputTensorAudio()
        private val tensorFormat = classifier?.requiredTensorAudioFormat
        private val audioRecord: AudioRecord? = try {
            val format = tensorFormat ?: throw IllegalStateException("Missing tensor format")
            val audioFormat = AudioFormat.Builder()
                .setSampleRate(format.sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()
            val minBuffer = AudioRecord.getMinBufferSize(
                format.sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.UNPROCESSED)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(minBuffer * 2)
                .build()
        } catch (e: Exception) {
            Log.e("SensorMonitoring", "AudioRecord init failed: ${e.message}")
            null
        }
        private var recordingJob: Job? = null

        fun start() {
            if (classifier == null || tensorAudio == null) return
            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) return
            if (recordingJob?.isActive == true) return
            audioRecord?.startRecording()
            recordingJob = scope.launch {
                try {
                    while (isActive) {
                        tensorAudio.load(audioRecord)
                        val results = classifier.classify(tensorAudio)
                        val prob = extractCrashProbability(results)
                        onProbability(prob)
                    }
                } catch (e: Exception) {
                    Log.e("SensorMonitoring", "Audio loop stopped: ${e.message}")
                }
            }
        }

        fun stop() {
            recordingJob?.cancel()
            recordingJob = null
            try {
                audioRecord?.stop()
                audioRecord?.release()
            } catch (_: Exception) { }
            classifier?.close()
            scope.cancel()
        }

        private fun extractCrashProbability(results: List<Classifications>): Float {
            if (results.isEmpty()) return 0f
            val categories = results.first().categories
            if (categories.isEmpty()) return 0f
            val crashCategory = categories.firstOrNull {
                it.label.equals(AUDIO_CRASH_LABEL, ignoreCase = true)
            }
            return (crashCategory ?: categories.maxByOrNull { it.score })?.score ?: 0f
        }
    }

    private inner class CrashMlDetector(context: Context) {
        private val windowSize = 100
        private val featureCount = 12
        private val sampleWindow: ArrayDeque<FloatArray> = ArrayDeque(windowSize)
        private val interpreter: Interpreter? = try {
            val options = Interpreter.Options().apply {
                setNumThreads(2)
            }
            Interpreter(loadModelFile(context, "crash_model.tflite"), options)
        } catch (e: Exception) {
            Log.e("SensorMonitoring", "Failed to load crash_model.tflite: ${e.message}")
            null
        }

        fun addSample(features: FloatArray): Float {
            if (features.size != featureCount) return 0f
            if (interpreter == null) return 0f
            sampleWindow.addLast(features)
            if (sampleWindow.size < windowSize) return 0f
            while (sampleWindow.size > windowSize) sampleWindow.removeFirst()

            val input = Array(1) { Array(windowSize) { FloatArray(featureCount) } }
            sampleWindow.forEachIndexed { index, sample ->
                for (i in 0 until featureCount) {
                    input[0][index][i] = sample[i]
                }
            }
            val output = Array(1) { FloatArray(4) }
            interpreter.run(input, output)
            // Class order expected: [normal, braking, turn, crash]
            return output[0].getOrNull(3) ?: 0f
        }

        fun close() {
            interpreter?.close()
        }

        private fun loadModelFile(context: Context, fileName: String): MappedByteBuffer {
            context.assets.openFd(fileName).use { assetDescriptor ->
                FileInputStream(assetDescriptor.fileDescriptor).use { input ->
                    val channel = input.channel
                    val startOffset = assetDescriptor.startOffset
                    val declaredLength = assetDescriptor.declaredLength
                    return channel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
                }
            }
        }
    }
}


