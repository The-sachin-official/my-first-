package com.example.ridealertz.service

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class WeatherData(
    val temperature: Double,
    val description: String,
    val humidity: Int,
    val windSpeed: Double,
    val visibility: Int,
    val condition: String,
    val feelsLike: Double = 0.0,
    val pressure: Int = 0,
    val uvIndex: Double = 0.0,
    val cloudCover: Int = 0,
    val dewPoint: Double = 0.0,
    val windDirection: Int = 0,
    val drivingSafetyScore: Int = 100,
    val safetyAlerts: List<String> = emptyList(),
    val recommendations: List<String> = emptyList()
)

data class HourlyForecast(
    val time: Long,
    val temperature: Double,
    val condition: String,
    val description: String,
    val precipitationChance: Int,
    val windSpeed: Double
)

data class DailyForecast(
    val date: Long,
    val highTemp: Double,
    val lowTemp: Double,
    val condition: String,
    val description: String,
    val precipitationChance: Int,
    val windSpeed: Double,
    val drivingSafetyScore: Int
)

data class WeatherAlert(
    val severity: String,
    val type: String,
    val message: String,
    val icon: String
)

class WeatherService(
    private val apiKey: String = "71d303101b8dea8b7645721a1041925e"
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val baseUrl = "https://api.openweathermap.org/data/2.5"

    suspend fun getCurrentWeather(latitude: Double, longitude: Double): WeatherData? = withContext(Dispatchers.IO) {
        if (!isApiKeyConfigured()) return@withContext null
        try {
            val url = "$baseUrl/weather?lat=$latitude&lon=$longitude&appid=$apiKey&units=metric"
            val json = executeRequest(url) ?: return@withContext null
            parseCurrentWeather(json)
        } catch (e: Exception) {
            Log.e("WeatherService", "Error fetching weather: ${e.message}", e)
            null
        }
    }

    suspend fun getHourlyForecast(latitude: Double, longitude: Double): List<HourlyForecast>? = withContext(Dispatchers.IO) {
        if (!isApiKeyConfigured()) return@withContext null
        try {
            val url = "$baseUrl/forecast?lat=$latitude&lon=$longitude&appid=$apiKey&units=metric"
            val json = executeRequest(url) ?: return@withContext null
            val list = json.getJSONArray("list")
            val forecasts = mutableListOf<HourlyForecast>()
            for (i in 0 until minOf(list.length(), 24)) {
                val item = list.getJSONObject(i)
                val main = item.getJSONObject("main")
                val weather = item.getJSONArray("weather").getJSONObject(0)
                val wind = item.optJSONObject("wind")
                val rain = item.optJSONObject("rain")?.optDouble("3h") ?: 0.0
                val snow = item.optJSONObject("snow")?.optDouble("3h") ?: 0.0
                val precipitationChance = if (rain + snow > 0) minOf(100, ((rain + snow) * 10).toInt()) else 0
                forecasts.add(
                    HourlyForecast(
                        time = item.getLong("dt") * 1000,
                        temperature = main.getDouble("temp"),
                        condition = weather.getString("main"),
                        description = weather.getString("description"),
                        precipitationChance = precipitationChance,
                        windSpeed = wind?.optDouble("speed") ?: 0.0
                    )
                )
            }
            forecasts
        } catch (e: Exception) {
            Log.e("WeatherService", "Error fetching hourly forecast: ${e.message}", e)
            null
        }
    }

    suspend fun getDailyForecast(latitude: Double, longitude: Double): List<DailyForecast>? = withContext(Dispatchers.IO) {
        if (!isApiKeyConfigured()) return@withContext null
        try {
            val url = "$baseUrl/forecast?lat=$latitude&lon=$longitude&appid=$apiKey&units=metric"
            val json = executeRequest(url) ?: return@withContext null
            val list = json.getJSONArray("list")
            val dailyData = mutableMapOf<String, DailyData>()
            val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            for (i in 0 until list.length()) {
                val item = list.getJSONObject(i)
                val dateTime = item.getLong("dt") * 1000
                val dateKey = formatter.format(Date(dateTime))
                val main = item.getJSONObject("main")
                val temp = main.getDouble("temp")
                val weather = item.getJSONArray("weather").getJSONObject(0)
                val wind = item.optJSONObject("wind")
                val rain = item.optJSONObject("rain")?.optDouble("3h") ?: 0.0
                val snow = item.optJSONObject("snow")?.optDouble("3h") ?: 0.0
                val precipitationChance = if (rain + snow > 0) 50 else 0
                val existing = dailyData[dateKey]
                if (existing == null) {
                    dailyData[dateKey] = DailyData(
                        date = dateTime,
                        highTemp = temp,
                        lowTemp = temp,
                        condition = weather.getString("main"),
                        description = weather.getString("description"),
                        windSpeed = wind?.optDouble("speed") ?: 0.0,
                        precipitationChance = precipitationChance
                    )
                } else {
                    dailyData[dateKey] = existing.copy(
                        highTemp = maxOf(existing.highTemp, temp),
                        lowTemp = minOf(existing.lowTemp, temp)
                    )
                }
            }
            dailyData.values.take(7).map { data ->
                val (score, _, _) = calculateDrivingSafety(
                    data.condition,
                    data.windSpeed,
                    -1,
                    0,
                    data.highTemp,
                    data.precipitationChance
                )
                DailyForecast(
                    date = data.date,
                    highTemp = data.highTemp,
                    lowTemp = data.lowTemp,
                    condition = data.condition,
                    description = data.description,
                    precipitationChance = data.precipitationChance,
                    windSpeed = data.windSpeed,
                    drivingSafetyScore = score
                )
            }
        } catch (e: Exception) {
            Log.e("WeatherService", "Error fetching daily forecast: ${e.message}", e)
            null
        }
    }

    private data class DailyData(
        val date: Long,
        val highTemp: Double,
        val lowTemp: Double,
        val condition: String,
        val description: String,
        val windSpeed: Double,
        val precipitationChance: Int
    )

    private fun isApiKeyConfigured(): Boolean = apiKey.isNotBlank()

    private fun executeRequest(url: String): JSONObject? {
        val request = Request.Builder().url(url).build()
        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            Log.e("WeatherService", "API error: ${response.code} ${response.message}")
            return null
        }
        val body = response.body?.string() ?: return null
        return JSONObject(body)
    }

    private fun parseCurrentWeather(json: JSONObject): WeatherData {
        val main = json.getJSONObject("main")
        val weather = json.getJSONArray("weather").getJSONObject(0)
        val wind = json.optJSONObject("wind")
        val clouds = json.optJSONObject("clouds")
        val visibility = json.optInt("visibility", -1)
        val temp = main.getDouble("temp")
        val feelsLike = main.optDouble("feels_like", temp)
        val pressure = main.optInt("pressure", 0)
        val humidity = main.getInt("humidity")
        val windSpeed = wind?.optDouble("speed") ?: 0.0
        val windDirection = wind?.optInt("deg") ?: 0
        val cloudCover = clouds?.optInt("all") ?: 0
        val description = weather.getString("description")
        val condition = weather.getString("main")
        val visibilityKm = if (visibility > 0) visibility / 1000 else -1
        val (score, alerts, recommendations) = calculateDrivingSafety(
            condition,
            windSpeed,
            visibilityKm,
            humidity,
            temp,
            precipitationChance = 0
        )
        return WeatherData(
            temperature = temp,
            description = description,
            humidity = humidity,
            windSpeed = windSpeed,
            visibility = visibilityKm,
            condition = condition,
            feelsLike = feelsLike,
            pressure = pressure,
            cloudCover = cloudCover,
            dewPoint = main.optDouble("temp_min", temp),
            windDirection = windDirection,
            drivingSafetyScore = score,
            safetyAlerts = alerts,
            recommendations = recommendations
        )
    }

    private fun calculateDrivingSafety(
        condition: String,
        windSpeed: Double,
        visibility: Int,
        humidity: Int,
        temperature: Double,
        precipitationChance: Int
    ): Triple<Int, List<String>, List<String>> {
        var score = 100
        val alerts = mutableListOf<String>()
        val recommendations = mutableListOf<String>()
        when (condition.lowercase()) {
            "clear" -> {}
            "clouds" -> score -= 5
            "drizzle", "rain" -> {
                score -= 20
                alerts.add("🌧️ Rain Alert: Reduced visibility and traction")
                recommendations += listOf(
                    "Reduce speed by 20-30%",
                    "Increase following distance",
                    "Use windshield wipers and defogger"
                )
            }
            "thunderstorm" -> {
                score -= 35
                alerts += listOf("⛈️ Severe Weather: Thunderstorm", "⚠️ High risk driving conditions")
                recommendations += listOf(
                    "Consider delaying your trip",
                    "Reduce speed by 40-50%",
                    "Pull over if visibility drops"
                )
            }
            "snow" -> {
                score -= 30
                alerts += listOf("❄️ Snow Alert: Extremely dangerous conditions")
                recommendations += listOf(
                    "Use winter tires",
                    "Reduce speed by 50%",
                    "Avoid sudden braking"
                )
            }
            "mist", "fog", "haze" -> {
                score -= 25
                alerts += "🌫️ Visibility Alert: Fog/Mist" 
                recommendations += listOf(
                    "Use low beam headlights",
                    "Reduce speed significantly",
                    "Increase following distance"
                )
            }
        }
        when {
            windSpeed > 15.0 -> {
                score -= 15
                alerts += "💨 High Wind Alert"
                recommendations += listOf(
                    "Be cautious on bridges",
                    "Reduce speed",
                    "Grip steering wheel firmly"
                )
            }
            windSpeed > 10.0 -> score -= 8
        }
        when {
            visibility > 0 && visibility < 1 -> {
                score -= 25
                alerts += "⚠️ Critical Visibility: <1km"
                recommendations += "Drive slowly or pull over"
            }
            visibility in 1..5 -> {
                score -= 15
                alerts += "👁️ Low Visibility: ${visibility}km"
            }
        }
        when {
            temperature < -10 -> {
                score -= 15
                alerts += "🥶 Extreme Cold"
            }
            temperature > 35 -> {
                score -= 10
                alerts += "🔥 Extreme Heat"
            }
        }
        if (precipitationChance > 70) {
            score -= 10
            alerts += "📊 High precipitation chance: ${precipitationChance}%"
        }
        score = maxOf(0, score)
        return Triple(score, alerts, recommendations)
    }

    fun getWeatherConditionEmoji(condition: String) = when (condition.lowercase()) {
        "clear" -> "☀️"
        "clouds" -> "☁️"
        "rain", "drizzle" -> "🌧️"
        "thunderstorm" -> "⛈️"
        "snow" -> "❄️"
        "mist", "fog", "haze" -> "🌫️"
        else -> "🌤️"
    }

    fun getSafetyLevel(score: Int) = when {
        score >= 80 -> "Excellent"
        score >= 60 -> "Good"
        score >= 40 -> "Moderate"
        else -> "Poor"
    }
}
