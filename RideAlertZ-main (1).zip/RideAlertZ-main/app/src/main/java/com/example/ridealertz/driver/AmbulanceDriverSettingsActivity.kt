package com.example.ridealertz.driver

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ridealertz.NeonDarkTokens
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
class AmbulanceDriverSettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AmbulanceDriverSettingsScreen(onBackPressed = { finish() })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AmbulanceDriverSettingsScreen(onBackPressed: () -> Unit) {
    val scrollState = rememberScrollState()
    val infinite = rememberInfiniteTransition(label = "settings-bg")
    val offset by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1600f,
        animationSpec = infiniteRepeatable(animation = tween(22000, easing = LinearEasing)),
        label = "settings-offset"
    )

    var autoDispatch by remember { mutableStateOf(true) }
    var liveNavigation by remember { mutableStateOf(true) }
    var nightMode by remember { mutableStateOf(false) }
    var pushAlerts by remember { mutableStateOf(true) }
    var hospitalSync by remember { mutableStateOf(true) }
    var showWeather by remember { mutableStateOf(true) }

    val scope = rememberCoroutineScope()

    Scaffold(
        containerColor = NeonDarkTokens.BgBase,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Ambulance Settings", color = NeonDarkTokens.TextPrimary, fontSize = 18.sp)
                        Text("Customize your mission preferences", color = NeonDarkTokens.TextSecondary, fontSize = 12.sp)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackPressed) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(NeonDarkTokens.mainBackground(offset))
                .verticalScroll(scrollState)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            SettingsGlassCard(title = "Mission Preferences", subtitle = "Control dispatch behavior and routing") {
                SettingsToggleRow(
                    title = "Auto-dispatch",
                    subtitle = "Automatically accept missions from control room",
                    checked = autoDispatch,
                    onCheckedChange = { autoDispatch = it }
                )
                SettingsToggleRow(
                    title = "Live navigation",
                    subtitle = "Start navigation overlay as soon as mission begins",
                    checked = liveNavigation,
                    onCheckedChange = { liveNavigation = it }
                )
                SettingsToggleRow(
                    title = "Night mode cluster",
                    subtitle = "Dim UI and enable soft alerts during 10PM–6AM",
                    checked = nightMode,
                    onCheckedChange = { nightMode = it }
                )
            }

            SettingsGlassCard(title = "Notifications", subtitle = "Alert & escalation controls") {
                SettingsToggleRow(
                    title = "Push notifications",
                    subtitle = "Receive control-room updates on lock screen",
                    checked = pushAlerts,
                    onCheckedChange = { pushAlerts = it }
                )
                SettingsToggleRow(
                    title = "Hospital sync",
                    subtitle = "Share ETA + vitals with assigned hospital",
                    checked = hospitalSync,
                    onCheckedChange = { hospitalSync = it }
                )
                SettingsToggleRow(
                    title = "Weather overlay",
                    subtitle = "Display weather risk card on dashboard",
                    checked = showWeather,
                    onCheckedChange = { showWeather = it }
                )
            }

            SettingsGlassCard(title = "Support", subtitle = "Need help on the field?") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    SupportActionButton(
                        modifier = Modifier.fillMaxWidth(0.3f),
                        icon = Icons.Default.Call,
                        label = "Control Room"
                    ) {
                        scope.launch {
                            // placeholder for call action
                        }
                    }
                    SupportActionButton(
                        modifier = Modifier.fillMaxWidth(0.3f),
                        icon = Icons.Default.Security,
                        label = "Safety SOP"
                    ) { }
                    SupportActionButton(
                        modifier = Modifier.fillMaxWidth(0.3f),
                        icon = Icons.Default.Route,
                        label = "Route Tips"
                    ) { }
                }
            }

            SettingsGlassCard(title = "Account", subtitle = "Profile + logout") {
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(
                        onClick = { /* TODO: edit profile */ },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonDarkTokens.OutlineFocused)
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Edit Profile")
                    }
                    Button(
                        onClick = { /* TODO: logout flow */ },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(NeonDarkTokens.CtaGradient, RoundedCornerShape(16.dp))
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Logout", color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsGlassCard(
    title: String,
    subtitle: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(NeonDarkTokens.GlassCardColor)
            .padding(20.dp)
    ) {
        Text(title, color = NeonDarkTokens.TextPrimary, fontSize = 18.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
        Text(subtitle, color = NeonDarkTokens.TextSecondary, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = NeonDarkTokens.TextPrimary, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium)
            Text(subtitle, color = NeonDarkTokens.TextSecondary, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun SupportActionButton(
    modifier: Modifier = Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier,
        colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonDarkTokens.TextPrimary)
    ) {
        Icon(icon, contentDescription = null)
        Spacer(Modifier.width(6.dp))
        Text(label)
    }
}
