package com.example.ridealertz.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = AccentBlue,
    onPrimary = Color.White,
    primaryContainer = BlackTertiary,
    onPrimaryContainer = AccentBlueLight,
    
    secondary = NeonGreen,
    onSecondary = BlackPrimary,
    secondaryContainer = BlackTertiary,
    onSecondaryContainer = NeonGreenLight,
    
    tertiary = AlertOrange,
    onTertiary = BlackPrimary,
    tertiaryContainer = BlackTertiary,
    onTertiaryContainer = AlertOrangeLight,
    
    background = BlackPrimary,
    onBackground = Color.White,
    surface = BlackSecondary,
    onSurface = Color.White,
    surfaceVariant = BlackTertiary,
    onSurfaceVariant = GrayLight,
    
    error = EmergencyRed,
    onError = Color.White,
    errorContainer = BlackTertiary,
    onErrorContainer = EmergencyRedLight,
    
    outline = GrayDark,
    outlineVariant = BlackTertiary
)

private val LightColorScheme = lightColorScheme(
    primary = AccentBlue,
    onPrimary = Color.White,
    primaryContainer = GrayLight,
    onPrimaryContainer = AccentBlue,
    
    secondary = NeonGreen,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD1FAE5),
    onSecondaryContainer = NeonGreenDark,
    
    tertiary = AlertOrange,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFEF3C7),
    onTertiaryContainer = AlertOrangeDark,
    
    background = WhitePrimary,
    onBackground = BlackPrimary,
    surface = WhiteSecondary,
    onSurface = BlackPrimary,
    surfaceVariant = GrayLight,
    onSurfaceVariant = GrayDark,
    
    error = EmergencyRed,
    onError = Color.White,
    errorContainer = Color(0xFFFEE2E2),
    onErrorContainer = EmergencyRedDark,
    
    outline = GrayMedium,
    outlineVariant = GrayLight
)

@Composable
fun RideAlertzTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Dynamic color is available on Android 12+
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }

        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}