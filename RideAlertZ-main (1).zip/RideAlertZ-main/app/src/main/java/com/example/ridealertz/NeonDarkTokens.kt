package com.example.ridealertz

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object NeonDarkTokens {
    val BgBase = Color(0xFF020617)

    val BgGradientColors = listOf(
        Color(0xFF020617),   // near-black navy
        Color(0xFF020617),   // keep base dark longer
        Color(0xFF0B1120),   // very dark blue
        Color(0xFF1D4ED8),   // deep royal blue
        Color(0xFF4C1D95)    // dark purple (replaces bright cyan)
    )

    fun mainBackground(offset: Float): Brush = Brush.linearGradient(
        colors = BgGradientColors,
        start = Offset(offset, 0f),
        end = Offset(0f, offset)
    )

    val GlassCardColor = Color.White.copy(alpha = 0.08f)
    val GlassBorderColor = Color.White.copy(alpha = 0.20f)

    val TextPrimary = Color.White
    val TextSecondary = Color.White.copy(alpha = 0.78f)
    val TextMuted = Color.White.copy(alpha = 0.65f)

    val DangerBg = Color(0xFF3F1F1F)
    val DangerBorder = Color(0xFFEF4444)
    val DangerText = Color(0xFFFCA5A5)

    val CtaGradient = Brush.horizontalGradient(
        listOf(
            Color(0xFF4F46E5),
            Color(0xFF22C55E)
        )
    )

    val OutlineUnfocused = Color(0xFF1E293B)
    val OutlineFocused = Color(0xFF60A5FA)
    val OutlineLabelUnfocused = Color(0xFF6B7280)
    val OutlineLabelFocused = Color(0xFF93C5FD)
}
