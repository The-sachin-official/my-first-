package com.example.ridealertz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ridealertz.NeonDarkTokens
import androidx.compose.animation.core.*
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import com.example.ridealertz.ui.theme.RideAlertzTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class AmbulanceDriverRegisterActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RideAlertzTheme {
                AmbulanceDriverRegisterScreen(onRegistered = { finish() })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AmbulanceDriverRegisterScreen(onRegistered: () -> Unit) {
    val scope = rememberCoroutineScope()

    var driverId by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var license by remember { mutableStateOf("") }
    var experienceYears by remember { mutableStateOf("") }
    var ambulanceNo by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }

    var isLoading by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }
    var successText by remember { mutableStateOf<String?>(null) }

    val scrollState = rememberScrollState()
    val infinite = rememberInfiniteTransition(label = "bg")
    val offset by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1200f,
        animationSpec = infiniteRepeatable(animation = tween(16000, easing = LinearEasing)),
        label = "offset"
    )

    Scaffold(containerColor = NeonDarkTokens.BgBase) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(NeonDarkTokens.mainBackground(offset))
                .verticalScroll(scrollState)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Register Ambulance Driver",
                color = NeonDarkTokens.TextPrimary,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Secure access for emergency responders",
                color = NeonDarkTokens.TextSecondary,
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(24.dp))

            AuthCard {
                NeonTextField(
                    value = driverId,
                    onValueChange = { driverId = it.uppercase() },
                    label = "Driver ID (e.g., AMB-TN-001)"
                )
                Spacer(Modifier.height(10.dp))
                NeonTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = "Full Name"
                )
                Spacer(Modifier.height(10.dp))
                NeonTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = "Phone Number",
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                )
                Spacer(Modifier.height(10.dp))

                NeonTextField(
                    value = license,
                    onValueChange = { license = it },
                    label = "License Number"
                )
                Spacer(Modifier.height(10.dp))
                NeonTextField(
                    value = experienceYears,
                    onValueChange = { experienceYears = it.filter { ch -> ch.isDigit() } },
                    label = "Experience (years)",
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Spacer(Modifier.height(10.dp))
                NeonTextField(
                    value = ambulanceNo,
                    onValueChange = { ambulanceNo = it.uppercase() },
                    label = "Ambulance Number (e.g., TN-09-AB-1234)"
                )
            }
            Spacer(Modifier.height(16.dp))

            AuthCard {
                NeonTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = "Password",
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
                Spacer(Modifier.height(10.dp))
                NeonTextField(
                    value = confirmPassword,
                    onValueChange = { confirmPassword = it },
                    label = "Confirm Password",
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
            }

            if (errorText != null) {
                Spacer(Modifier.height(8.dp))
                Text(text = errorText!!, color = NeonDarkTokens.DangerText, fontSize = 12.sp)
            }
            if (successText != null) {
                Spacer(Modifier.height(8.dp))
                Text(text = successText!!, color = NeonDarkTokens.TextPrimary, fontSize = 12.sp)
            }

            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    errorText = null
                    successText = null
                    if (driverId.isBlank() || name.isBlank() || phone.isBlank() || password.isBlank()) {
                        errorText = "Please fill all required fields"
                        return@Button
                    }
                    if (password != confirmPassword) {
                        errorText = "Passwords do not match"
                        return@Button
                    }
                    isLoading = true
                    scope.launch {
                        val db = FirebaseDatabase.getInstance().reference
                        val auth = FirebaseAuth.getInstance()
                        try {
                            // Normalize driver ID: trim whitespace and ensure uppercase
                            val normalizedDriverId = driverId.trim().uppercase()
                            // Use a synthetic email based on driverId for Firebase Auth
                            val email = "$normalizedDriverId@ambulance.ridealertz.com"
                            android.util.Log.d("AmbulanceDriverRegister", "Creating user with email: $email, driverId: $normalizedDriverId")

                            // Create auth user
                            val authResult = withContext(Dispatchers.IO) {
                                auth.createUserWithEmailAndPassword(email, password).await()
                            }
                            val uid = authResult.user?.uid
                                ?: throw IllegalStateException("Failed to create user")

                            val path = db.child("ambulance_drivers").child(uid)
                            val exists = withContext(Dispatchers.IO) { path.get().await().exists() }
                            if (exists) {
                                errorText = "Driver already exists for this account"
                            } else {
                                val data = mapOf(
                                    "driver_id" to normalizedDriverId,
                                    "personal_info" to mapOf(
                                        "name" to name,
                                        "phone" to phone,
                                        "license" to license,
                                        "experience" to (experienceYears.toIntOrNull() ?: 0)
                                    ),
                                    "vehicle_info" to mapOf(
                                        "ambulance_no" to ambulanceNo,
                                        "type" to "Ambulance",
                                        "capacity" to 1
                                    ),
                                    "status" to "active",
                                    "login_status" to false,
                                    "performance" to mapOf(
                                        "rating" to 5.0,
                                        "completed_missions" to 0
                                    )
                                )
                                withContext(Dispatchers.IO) {
                                    path.setValue(data).await()
                                }
                                successText = "Driver registered. You can now log in."
                                onRegistered()
                            }
                        } catch (e: Exception) {
                            errorText = "Registration failed: ${e.message ?: "unknown error"}"
                        } finally {
                            isLoading = false
                        }
                    }
                },
                enabled = !isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(NeonDarkTokens.CtaGradient, shape = RoundedCornerShape(18.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                    } else {
                        Text("REGISTER", fontWeight = FontWeight.Bold, color = NeonDarkTokens.TextPrimary)
                    }
                }
            }
        }
    }
}

@Composable
private fun AuthCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, NeonDarkTokens.GlassBorderColor, RoundedCornerShape(20.dp))
            .background(NeonDarkTokens.GlassCardColor, RoundedCornerShape(20.dp))
            .padding(20.dp),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NeonTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        keyboardOptions = keyboardOptions,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonDarkTokens.OutlineFocused,
            unfocusedBorderColor = NeonDarkTokens.OutlineUnfocused,
            focusedLabelColor = NeonDarkTokens.OutlineLabelFocused,
            unfocusedLabelColor = NeonDarkTokens.OutlineLabelUnfocused,
            cursorColor = NeonDarkTokens.OutlineFocused,
            focusedTextColor = NeonDarkTokens.TextPrimary,
            unfocusedTextColor = NeonDarkTokens.TextPrimary
        )
    )
}
