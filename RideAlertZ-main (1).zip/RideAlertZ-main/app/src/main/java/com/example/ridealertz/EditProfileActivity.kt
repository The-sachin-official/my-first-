package com.example.ridealertz

import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ridealertz.ui.theme.RideAlertzTheme
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class EditProfileActivity : ComponentActivity() {
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("ridealertz", MODE_PRIVATE)
        val userId = ((prefs.getString("user_email", null)
            ?: prefs.getString("user_phone", null)
            ?: "guest")).replace("@", "_")

        setContent {
            RideAlertzTheme {
                EditProfileScreen(
                    firstNameInit = prefs.getString("first_name", "") ?: "",
                    lastNameInit = prefs.getString("last_name", "") ?: "",
                    emailInit = prefs.getString("user_email", "") ?: "",
                    phoneInit = prefs.getString("user_phone", "") ?: "",
                    cityInit = prefs.getString("city", "") ?: "",
                    countryInit = prefs.getString("country", "India") ?: "India",
                    addressInit = prefs.getString("address", "") ?: "",
                    stateInit = prefs.getString("state", "") ?: "",
                    postalInit = prefs.getString("postalCode", "") ?: "",
                    bloodInit = prefs.getString("bloodGroup", "") ?: "",
                    allergiesInit = prefs.getString("allergies", "") ?: "",
                    conditionsInit = prefs.getString("conditions", "") ?: "",
                    medsInit = prefs.getString("medications", "") ?: "",
                    emgNameInit = prefs.getString("emgName", "") ?: "",
                    emgPhoneInit = prefs.getString("emgPhone", "") ?: "",
                    emgRelationInit = prefs.getString("emgRelation", "") ?: "",
                    hospitalInit = prefs.getString("preferredHospital", "") ?: "",
                    insProviderInit = prefs.getString("insuranceProvider", "") ?: "",
                    insPolicyInit = prefs.getString("insurancePolicy", "") ?: "",
                    doctorInit = prefs.getString("doctorName", "") ?: "",
                    doctorContactInit = prefs.getString("doctorContact", "") ?: "",
                    userId = userId,
                    onBack = { finish() },
                    onSave = { f, l, e, phone, addr, city, state, postal, country, blood, allergies, conditions, meds, emgName, emgPhone, emgRel, hospital, insProv, insPol, doc, docContact, helmetUsed ->
                        prefs.edit()
                            .putString("first_name", f)
                            .putString("last_name", l)
                            .putString("user_email", e)
                            .putString("user_phone", phone)
                            .putString("address", addr)
                            .putString("city", city)
                            .putString("state", state)
                            .putString("postalCode", postal)
                            .putString("country", country)
                            .putString("bloodGroup", blood)
                            .putString("allergies", allergies)
                            .putString("conditions", conditions)
                            .putBoolean("helmet_used", helmetUsed)
                            .putString("emgName", emgName)
                            .putString("emgPhone", emgPhone)
                            .putString("emgRelation", emgRel)
                            .apply()
                        // Write to Firebase (best-effort) under users/{userId}/profile
                        val profile = mapOf(
                            "firstName" to f,
                            "lastName" to l,
                            "email" to e,
                            "phone" to phone,
                            "address" to addr,
                            "city" to city,
                            "state" to state,
                            "postalCode" to postal,
                            "country" to country,
                            "bloodGroup" to blood,
                            "allergies" to allergies,
                            "conditions" to conditions,
                            "medications" to meds,
                            "helmet_used" to helmetUsed,
                            "emergencyContactName" to emgName,
                            "emergencyContactPhone" to emgPhone,
                            "emergencyContactRelation" to emgRel,
                            "preferredHospital" to hospital,
                            "insuranceProvider" to insProv,
                            "insurancePolicy" to insPol,
                            "doctorName" to doc,
                            "doctorContact" to docContact,
                        )
                        lifecycleScope.launch {
                            try { FirebaseHelper.writeUserProfile(userId, profile) } catch (_: Exception) { }
                        }
                        finish()
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProfileScreen(
    firstNameInit: String,
    lastNameInit: String,
    emailInit: String,
    phoneInit: String,
    cityInit: String,
    countryInit: String,
    addressInit: String,
    stateInit: String,
    postalInit: String,
    bloodInit: String,
    allergiesInit: String,
    conditionsInit: String,

    medsInit: String,
    emgNameInit: String,
    emgPhoneInit: String,
    emgRelationInit: String,
    hospitalInit: String,
    insProviderInit: String,
    insPolicyInit: String,
    doctorInit: String,
    doctorContactInit: String,
    helmetUsedInit: Boolean = true,
    userId: String,
    onBack: () -> Unit,
    onSave: (
        String, String, String, String, String, String, String, String, String,
        String, String, String, String, String, String, String, String, String, String, String, String, Boolean
    ) -> Unit
) {
    var firstName by remember { mutableStateOf(firstNameInit) }
    var lastName by remember { mutableStateOf(lastNameInit) }
    var email by remember { mutableStateOf(emailInit) }
    var phone by remember { mutableStateOf(phoneInit) }
    var city by remember { mutableStateOf(cityInit) }
    var country by remember { mutableStateOf(countryInit) }
    var address by remember { mutableStateOf(addressInit) }
    var state by remember { mutableStateOf(stateInit) }
    var postal by remember { mutableStateOf(postalInit) }
    var blood by remember { mutableStateOf(bloodInit) }
    var allergies by remember { mutableStateOf(allergiesInit) }
    var conditions by remember { mutableStateOf(conditionsInit) }
    var meds by remember { mutableStateOf(medsInit) }
    var emgName by remember { mutableStateOf(emgNameInit) }
    var emgPhone by remember { mutableStateOf(emgPhoneInit) }
    var emgRelation by remember { mutableStateOf(emgRelationInit) }
    var hospital by remember { mutableStateOf(hospitalInit) }
    var insProvider by remember { mutableStateOf(insProviderInit) }
    var insPolicy by remember { mutableStateOf(insPolicyInit) }
    var doctor by remember { mutableStateOf(doctorInit) }
    var doctorContact by remember { mutableStateOf(doctorContactInit) }
    var helmetUsed by remember { mutableStateOf(helmetUsedInit) }

    // Country dropdown data and flag helper
    val countryOptions = listOf("India", "United States", "United Kingdom", "Canada", "Australia")
    var isCountryDropdownExpanded by remember { mutableStateOf(false) }


    // Prefill from Firebase if available (users/{userId}/profile)
    LaunchedEffect(userId) {
        try {
            val map = withContext(Dispatchers.IO) { FirebaseHelper.readUserProfile(userId) }
            if (map != null) {
                (map["firstName"] as? String)?.let { firstName = it }
                (map["lastName"] as? String)?.let { lastName = it }
                (map["email"] as? String)?.let { email = it }
                (map["phone"] as? String)?.let { phone = it }
                (map["address"] as? String)?.let { address = it }
                (map["city"] as? String)?.let { city = it }
                (map["state"] as? String)?.let { state = it }
                (map["postalCode"] as? String)?.let { postal = it }
                (map["country"] as? String)?.let { country = it }
                (map["bloodGroup"] as? String)?.let { blood = it }
                (map["allergies"] as? String)?.let { allergies = it }
                (map["conditions"] as? String)?.let { conditions = it }
                (map["medications"] as? String)?.let { meds = it }
                (map["emergencyContactName"] as? String)?.let { emgName = it }
                (map["emergencyContactPhone"] as? String)?.let { emgPhone = it }
                (map["emergencyContactRelation"] as? String)?.let { emgRelation = it }
                (map["preferredHospital"] as? String)?.let { hospital = it }
                (map["insuranceProvider"] as? String)?.let { insProvider = it }
                (map["insurancePolicy"] as? String)?.let { insPolicy = it }
                (map["doctorName"] as? String)?.let { doctor = it }
                (map["doctorContact"] as? String)?.let { doctorContact = it }
                (map["helmet_used"] as? Boolean)?.let { helmetUsed = it }
            }
        } catch (_: Exception) { }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                },
                title = { Text("Edit Profile", fontWeight = FontWeight.Bold) },
                actions = {
                    TextButton(onClick = {
                        onSave(
                            firstName, lastName, email, phone, address, city, state, postal, country,
                            blood, allergies, conditions, meds, emgName, emgPhone, emgRelation,
                            hospital, insProvider, insPolicy, doctor, doctorContact, helmetUsed
                        )
                    }) {
                        Text("Save")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF101010),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color(0xFF22C55E)
                )
            )
        },
        containerColor = Color(0xFF0D0D0D)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFF0D0D0D))
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Personal Information", color = Color.White, fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = firstName, onValueChange = { firstName = it }, label = { Text("Full Name") },
                singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)
            )
            OutlinedTextField(
                value = phone, onValueChange = { phone = it }, label = { Text("Phone Number") },
                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)
            )
            OutlinedTextField(
                value = blood, onValueChange = { blood = it }, label = { Text("Blood Group") },
                singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)
            )
            OutlinedTextField(
                value = address, onValueChange = { address = it }, label = { Text("Address (optional)") },
                singleLine = false, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)
            )
            Text(
                text = "Used to share your identity with emergency contacts & ambulance.\nHelps responders reach you faster.\nBlood group helps in emergency treatment.",
                color = Color(0xFF9CA3AF),
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
            )

            Text("Medical Details", color = Color.White, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = conditions, onValueChange = { conditions = it }, label = { Text("Medical Conditions (Diabetes, BP, Asthma, etc.)") },
                    singleLine = true, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                )
                OutlinedTextField(
                    value = allergies, onValueChange = { allergies = it }, label = { Text("Allergies") },
                    singleLine = true, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = meds, onValueChange = { meds = it }, label = { Text("Current Medications") },
                    singleLine = true, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                )
                OutlinedTextField(
                    value = hospital, onValueChange = { hospital = it }, label = { Text("Previous Injuries (optional)") },
                    singleLine = false, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                )
            }
            Text(
                text = "Critical information for ambulance/hospital.\nHelps doctors treat you immediately.\nEnsures no wrong medication during emergencies.",
                color = Color(0xFF9CA3AF),
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
            )

            Text("Emergency Contact", color = Color.White, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = emgName, onValueChange = { emgName = it }, label = { Text("Full Name") },
                    singleLine = true, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                )
                OutlinedTextField(
                    value = emgRelation, onValueChange = { emgRelation = it }, label = { Text("Relationship") },
                    singleLine = true, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                )
            }
            OutlinedTextField(
                value = emgPhone, onValueChange = { emgPhone = it }, label = { Text("Contact Number") },
                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)
            )

            Text("Bike / Vehicle Details", color = Color.White, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = insProvider, onValueChange = { insProvider = it }, label = { Text("Bike Model") },
                    singleLine = true, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                )
                OutlinedTextField(
                    value = insPolicy, onValueChange = { insPolicy = it }, label = { Text("Bike Number Plate") },
                    singleLine = true, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = doctor, onValueChange = { doctor = it }, label = { Text("Insurance Number") },
                    singleLine = true, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                )
                OutlinedTextField(
                    value = doctorContact, onValueChange = { doctorContact = it }, label = { Text("RC Expiry Date") },
                    singleLine = true,
                    modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Helmet Usage", color = Color.White)
                Switch(checked = helmetUsed, onCheckedChange = { helmetUsed = it })
            }
            Text(
                text = "Helps with insurance & accident verification.\nPolice/ambulance can identify your vehicle quickly.",
                color = Color(0xFF9CA3AF),
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
            )
        }
    }
}
