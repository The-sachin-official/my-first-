package com.example.ridealertz

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ridealertz.ui.theme.RideAlertzTheme
import com.example.ridealertz.NeonDarkTokens
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import androidx.lifecycle.lifecycleScope
import android.util.Log

class AmbulanceDriverLoginActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val auth = FirebaseAuth.getInstance()
            val existingUser = auth.currentUser
            if (existingUser != null) {
                lifecycleScope.launch {
                    try {
                        val extras = fetchDriverDetailsOrNull(existingUser.uid)
                        if (extras != null) {
                            startActivity(
                                Intent(
                                    this@AmbulanceDriverLoginActivity,
                                    com.example.ridealertz.driver.AmbulanceDriverActivity::class.java
                                ).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                                    putExtras(extras)
                                }
                            )
                            finish()
                        } else {
                            try {
                                auth.signOut()
                            } catch (_: Exception) { }
                            renderLogin()
                        }
                    } catch (e: Exception) {
                        Log.e("AmbulanceDriverLogin", "Error checking existing user", e)
                        renderLogin()
                    }
                }
            } else {
                renderLogin()
            }
        } catch (e: Exception) {
            Log.e("AmbulanceDriverLogin", "Error in onCreate", e)
            renderLogin()
        }
    }

    private fun renderLogin() {
        setContent {
            RideAlertzTheme {
                AmbulanceDriverLoginScreen(this)
            }
        }
    }

    private suspend fun fetchDriverDetailsOrNull(uid: String): Bundle? {
        return try {
            val db = FirebaseDatabase.getInstance().reference
            val snapshot = withContext(Dispatchers.IO) {
                db.child("ambulance_drivers").child(uid).get().await()
            }
            if (!snapshot.exists()) return null
            val driverId = snapshot.child("driver_id").getValue(String::class.java) ?: "D01"
            val personal = snapshot.child("personal_info")
            val vehicle = snapshot.child("vehicle_info")
            val name = personal.child("name").getValue(String::class.java) ?: "Driver"
            val phone = personal.child("phone").getValue(String::class.java) ?: ""
            val experience = (personal.child("experience").getValue(Long::class.java)?.toInt()) ?: 0
            val ambulanceNo = vehicle.child("ambulance_no").getValue(String::class.java) ?: "AMB001"
            Bundle().apply {
                putString("driverId", driverId)
                putString("driverName", name)
                putString("driverPhone", phone)
                putInt("experienceYears", experience)
                putString("ambulanceId", ambulanceNo)
            }
        } catch (e: Exception) {
            Log.e("AmbulanceDriverLogin", "Error fetching driver details", e)
            null
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AmbulanceDriverLoginScreen(activity: ComponentActivity) {
    val prefs = activity.getSharedPreferences("ridealertz", Context.MODE_PRIVATE)

    var driverId by remember { mutableStateOf(prefs.getString("driver_id_last", "") ?: "") }
    var password by remember { mutableStateOf("") }
    var rememberMe by remember { mutableStateOf(true) }
    var isLoading by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }

    val scope = rememberCoroutineScope()

    val scrollState = rememberScrollState()
    val infinite = rememberInfiniteTransition(label = "bg")
    val offset by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1200f,
        animationSpec = infiniteRepeatable(animation = tween(15000, easing = LinearEasing)),
        label = "offset"
    )

    Scaffold(
        containerColor = NeonDarkTokens.BgBase
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(NeonDarkTokens.mainBackground(offset))
                .verticalScroll(scrollState)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.LocalHospital,
                contentDescription = null,
                tint = NeonDarkTokens.TextPrimary,
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "AMBULANCE DRIVER PORTAL",
                color = NeonDarkTokens.TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(24.dp))

            NeonAuthCard {
                NeonTextField(
                    value = driverId,
                    onValueChange = { driverId = it.uppercase() },
                    label = "Driver ID (e.g., AMB-TN-001)",
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii)
                )
                Spacer(modifier = Modifier.height(12.dp))
                NeonTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = "Password",
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = rememberMe, onCheckedChange = { rememberMe = it })
                    Text("Remember Me", color = NeonDarkTokens.TextSecondary)
                }
                TextButton(onClick = { /* TODO: forgot password flow */ }) {
                    Text("Forgot Password?", color = NeonDarkTokens.OutlineFocused)
                }
            }

            if (errorText != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = errorText!!, color = NeonDarkTokens.DangerText, fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    if (driverId.isBlank() || password.isBlank()) {
                        errorText = "Please enter Driver ID and Password"
                        return@Button
                    }
                    isLoading = true
                    errorText = null
                    scope.launch {
                        val db = FirebaseDatabase.getInstance().reference
                        val auth = FirebaseAuth.getInstance()
                        try {
                            // Normalize driver ID: trim whitespace and ensure uppercase
                            val normalizedDriverId = driverId.trim().uppercase()
                            val email = "$normalizedDriverId@ambulance.ridealertz.com"
                            Log.d("AmbulanceDriverLogin", "Attempting login with email: $email, driverId: $normalizedDriverId (original: $driverId)")

                            // Sign in with Firebase Auth
                            val authResult = withContext(Dispatchers.IO) {
                                auth.signInWithEmailAndPassword(email, password).await()
                            }
                            Log.d("AmbulanceDriverLogin", "Login successful, UID: ${authResult.user?.uid}")
                            val uid = authResult.user?.uid
                                ?: throw IllegalStateException("Login user is null")

                            val snapshot = withContext(Dispatchers.IO) {
                                db.child("ambulance_drivers").child(uid).get().await()
                            }
                            if (!snapshot.exists()) {
                                errorText = "Driver profile not found"
                            } else {
                                val status = snapshot.child("status").getValue(String::class.java) ?: "active"
                                if (status == "suspended") {
                                    errorText = "Account suspended. Contact admin."
                                } else {
                                    // Successful login
                                    if (rememberMe) {
                                        prefs.edit().putString("driver_id_last", normalizedDriverId).apply()
                                    }
                                    db.child("ambulance_drivers").child(uid).child("login_status").setValue(true)
                                    db.child("ambulance_drivers").child(uid).child("status").setValue("available")
                                    val personal = snapshot.child("personal_info")
                                    val vehicle = snapshot.child("vehicle_info")
                                    val extras = Bundle().apply {
                                        putString("driverId", snapshot.child("driver_id").getValue(String::class.java) ?: normalizedDriverId)
                                        putString("driverName", personal.child("name").getValue(String::class.java) ?: driverId)
                                        putString("driverPhone", personal.child("phone").getValue(String::class.java) ?: "")
                                        putInt("experienceYears", (personal.child("experience").getValue(Long::class.java)?.toInt()) ?: 0)
                                        putString("ambulanceId", vehicle.child("ambulance_no").getValue(String::class.java) ?: "AMB001")
                                    }
                                    Log.d("AmbulanceDriverLogin", "Bundle created: driverId=${extras.getString("driverId")}, driverName=${extras.getString("driverName")}, ambulanceId=${extras.getString("ambulanceId")}")
                                    // Go to new driver dashboard with details
                                    Log.d("AmbulanceDriverLogin", "Starting AmbulanceDriverActivity with extras: driverId=${extras.getString("driverId")}, driverName=${extras.getString("driverName")}")
                                    withContext(Dispatchers.Main) {
                                        try {
                                            val intent = Intent(activity, com.example.ridealertz.driver.AmbulanceDriverActivity::class.java)
                                            intent.putExtras(extras)
                                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                                            Log.d("AmbulanceDriverLogin", "Intent created, starting activity...")
                                            activity.startActivity(intent)
                                            Log.d("AmbulanceDriverLogin", "Activity started successfully, finishing login activity")
                                            activity.finish()
                                        } catch (e: Exception) {
                                            Log.e("AmbulanceDriverLogin", "Error starting AmbulanceDriverActivity", e)
                                            e.printStackTrace()
                                            withContext(Dispatchers.Main) {
                                                errorText = "Failed to open dashboard: ${e.message}"
                                            }
                                        }
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            Log.e("AmbulanceDriverLogin", "Login error", e)
                            val errorMessage = e.message ?: "unknown error"
                            errorText = when {
                                errorMessage.contains("password", ignoreCase = true) || 
                                errorMessage.contains("credential", ignoreCase = true) -> {
                                    "Invalid Driver ID or Password. If you registered before, you may need to re-register due to a previous bug."
                                }
                                errorMessage.contains("user", ignoreCase = true) && 
                                errorMessage.contains("not found", ignoreCase = true) -> {
                                    "Driver account not found. Please register first."
                                }
                                errorMessage.contains("invalid", ignoreCase = true) && 
                                errorMessage.contains("email", ignoreCase = true) -> {
                                    "Invalid email format. Please check your Driver ID."
                                }
                                else -> "Login failed: $errorMessage"
                            }
                        } finally {
                            isLoading = false
                        }
                    }
                },
                enabled = !isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(NeonDarkTokens.CtaGradient, shape = RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                    } else {
                        Text("LOGIN", fontWeight = FontWeight.Bold, color = NeonDarkTokens.TextPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("New Driver? ", color = NeonDarkTokens.TextMuted)
                TextButton(onClick = {
                    activity.startActivity(Intent(activity, AmbulanceDriverRegisterActivity::class.java))
                }) {
                    Text("Register Here", color = NeonDarkTokens.OutlineFocused)
                }
            }
        }
    }
}

@Composable
private fun NeonAuthCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, NeonDarkTokens.GlassBorderColor, RoundedCornerShape(20.dp))
            .background(NeonDarkTokens.GlassCardColor, RoundedCornerShape(20.dp))
            .padding(20.dp),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NeonTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    keyboardOptions: KeyboardOptions
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        keyboardOptions = keyboardOptions,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonDarkTokens.OutlineFocused,
            unfocusedBorderColor = NeonDarkTokens.OutlineUnfocused,
            focusedLabelColor = NeonDarkTokens.OutlineLabelFocused,
            unfocusedLabelColor = NeonDarkTokens.OutlineLabelUnfocused,
            cursorColor = NeonDarkTokens.OutlineFocused,
            focusedTextColor = NeonDarkTokens.TextPrimary,
            unfocusedTextColor = NeonDarkTokens.TextPrimary
        )
    )
}
