package com.example.ridealertz.service

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Minimal emergency call handoff screen.
 * Shows the primary emergency number (default 108) with quick access to dialer or voice call intent.
 */
class EmergencyCallActivity : ComponentActivity() {
    private var hasInitiatedCall = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    EmergencyCallScreen(
                        onCall108 = { placeCall("108") },
                        onCallUser = {
                            val phone = intent.getStringExtra(EXTRA_FALLBACK_PHONE)
                            if (!phone.isNullOrBlank()) placeCall(phone)
                        },
                        fallbackPhone = intent.getStringExtra(EXTRA_FALLBACK_PHONE)
                    )
                }
            }
        }

        // Automatically dial 108 as soon as the screen appears.
        maybeInitiateAutoCall()
    }

    private fun placeCall(number: String) {
        try {
            val callIntent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.parse("tel:$number")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(callIntent)
        } catch (security: SecurityException) {
            // Requesting CALL_PHONE permission should be handled upstream (CrashAlertActivity).
            val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$number")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(dialIntent)
        } catch (e: Exception) {
            val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$number")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(dialIntent)
        }
    }

    private fun maybeInitiateAutoCall() {
        if (hasInitiatedCall) return
        hasInitiatedCall = true
        window.decorView.post {
            placeCall("108")
        }
    }

    companion object {
        const val EXTRA_FALLBACK_PHONE = "extra_fallback_phone"
    }
}

@Composable
private fun EmergencyCallScreen(
    onCall108: () -> Unit,
    onCallUser: () -> Unit,
    fallbackPhone: String?
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B1320))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Emergency Assistance",
            color = Color.White,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "We’re about to connect you with emergency responders.",
            color = Color(0xFFE2E8F0),
            fontSize = 16.sp,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(32.dp))
        Button(
            onClick = onCall108,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935))
        ) {
            Text(text = "Call 108 Now", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = onCallUser,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            enabled = !fallbackPhone.isNullOrBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1F2937))
        ) {
            Text(
                text = fallbackPhone?.let { "Call $it" } ?: "No personal contact set",
                fontSize = 16.sp,
                color = Color.White
            )
        }
    }
}
