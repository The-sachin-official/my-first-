package com.example.ridealertz

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.edit
import com.example.ridealertz.FirebaseHelper
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class LoginActivity : ComponentActivity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefs = getSharedPreferences("ridealertz", MODE_PRIVATE)
        auth = FirebaseAuth.getInstance()

        val alreadyLoggedIn = prefs.getBoolean("is_logged_in", false)
        val firebaseUser = auth.currentUser
        if (alreadyLoggedIn && firebaseUser != null) {
            navigateAfterLogin()
            return
        }

        setContent {
            MaterialTheme {
                LoginScreen(
                    onLogin = { identifier, password -> performLogin(identifier, password) }
                )
            }
        }
    }

    private suspend fun performLogin(identifier: String, password: String): Pair<Boolean, String> {
        try {
            val result = auth.signInWithEmailAndPassword(identifier, password).await()
            val user = result.user
            if (user != null) {
                prefs.edit {
                    putBoolean("is_logged_in", true)
                    putString("user_name", user.displayName ?: "User")
                    putString("user_email", user.email ?: identifier)
                    putString("user_phone", user.phoneNumber ?: "")
                    putString("user_uid", user.uid)
                }
                ensureProfileCompleted(user.uid)
                navigateAfterLogin()
                return true to "Login successful"
            }
        } catch (_: Exception) {
        }

        val usersJson = prefs.getString("users", null)
        if (!usersJson.isNullOrBlank()) {
            val cached = runCatching { parseLocalUsers(usersJson) }.getOrDefault(emptyList())
            val user = cached.find { it.email.equals(identifier, true) || it.phone == identifier }
            if (user != null && user.password == password) {
                prefs.edit {
                    putBoolean("is_logged_in", true)
                    putString("user_name", user.name)
                    putString("user_email", user.email)
                    putString("user_phone", user.phone)
                    putString("user_uid", "local_${user.email.replace("@", "_")}")
                }
                ensureProfileCompleted(prefs.getString("user_uid", "") ?: "")
                navigateAfterLogin()
                return true to "Login successful"
            }
        }
        return false to "Invalid email/phone or password"
    }

    private suspend fun ensureProfileCompleted(userId: String) {
        if (userId.isBlank()) return
        val alreadyCompleted = prefs.getBoolean("profile_completed", false)
        if (alreadyCompleted) return
        try {
            val profile = FirebaseHelper.readUserProfile(userId)
            if (profile != null && profile.isNotEmpty()) {
                prefs.edit {
                    putBoolean("profile_completed", true)
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun parseLocalUsers(json: String): List<User> {
        val entries = json.trim().removePrefix("[").removeSuffix("]")
        if (entries.isBlank()) return emptyList()
        return entries.split("},").mapNotNull { entry ->
            val cleaned = entry.trim().removePrefix("{").removeSuffix("}")
            val map = cleaned.split(",").mapNotNull {
                val parts = it.split(":")
                if (parts.size == 2) parts[0].trim(' ', '"') to parts[1].trim(' ', '"') else null
            }.toMap()
            val name = map["name"]
            val email = map["email"]
            val phone = map["phone"]
            val password = map["password"]
            if (name != null && email != null && phone != null && password != null) {
                User(name, email, phone, password)
            } else null
        }
    }

    private fun navigateAfterLogin() {
        val profileCompleted = prefs.getBoolean("profile_completed", false)
        if (profileCompleted) {
            startActivity(Intent(this, MainActivityNew::class.java))
        } else {
            startActivity(Intent(this, ProfileDetailsActivity::class.java))
        }
        finish()
    }
}

@Composable
fun LoginScreen(
    onLogin: suspend (String, String) -> Pair<Boolean, String>
) {
    var emailState by remember { mutableStateOf("") }
    var passwordState by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val infinite = rememberInfiniteTransition(label = "login-bg")
    val offset by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(animation = tween(12000, easing = LinearEasing)),
        label = "login-offset"
    )
    val glowAlpha by infinite.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "logo-glow"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NeonDarkTokens.mainBackground(offset))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier.size(110.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFFFF6B1A).copy(alpha = glowAlpha),
                                    Color.Transparent
                                )
                            ),
                            shape = CircleShape
                        )
                )
                Icon(
                    imageVector = Icons.Default.DirectionsCar,
                    contentDescription = "RideAlertz Logo",
                    modifier = Modifier.size(72.dp),
                    tint = NeonDarkTokens.TextPrimary
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "RideAlertz",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = NeonDarkTokens.TextPrimary
            )
            Text(
                text = "Your Safety Companion",
                fontSize = 16.sp,
                color = NeonDarkTokens.TextSecondary
            )
            Spacer(modifier = Modifier.height(48.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = NeonDarkTokens.GlassCardColor),
                border = BorderStroke(1.dp, NeonDarkTokens.GlassBorderColor)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text(
                        text = "Welcome Back",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonDarkTokens.TextPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Login to continue",
                        fontSize = 14.sp,
                        color = NeonDarkTokens.TextSecondary
                    )
                    Spacer(modifier = Modifier.height(24.dp))

                    OutlinedTextField(
                        value = emailState,
                        onValueChange = { emailState = it },
                        label = { Text("Email or Phone") },
                        leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = Color(0xFFF472B6)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = NeonDarkTokens.OutlineUnfocused,
                            focusedBorderColor = NeonDarkTokens.OutlineFocused,
                            unfocusedTextColor = NeonDarkTokens.TextPrimary,
                            focusedTextColor = NeonDarkTokens.TextPrimary,
                            unfocusedLabelColor = NeonDarkTokens.OutlineLabelUnfocused,
                            focusedLabelColor = NeonDarkTokens.OutlineLabelFocused
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = passwordState,
                        onValueChange = { passwordState = it },
                        label = { Text("Password") },
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFFA855F7)) },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = if (passwordVisible) "Hide password" else "Show password"
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = NeonDarkTokens.OutlineUnfocused,
                            focusedBorderColor = NeonDarkTokens.OutlineFocused,
                            unfocusedTextColor = NeonDarkTokens.TextPrimary,
                            focusedTextColor = NeonDarkTokens.TextPrimary,
                            unfocusedLabelColor = NeonDarkTokens.OutlineLabelUnfocused,
                            focusedLabelColor = NeonDarkTokens.OutlineLabelFocused
                        )
                    )

                    errorMessage?.let {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = it, color = NeonDarkTokens.DangerText, fontSize = 14.sp)
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = {
                            errorMessage = null
                            if (emailState.isBlank() || passwordState.isBlank()) {
                                errorMessage = "Please fill all fields"
                                return@Button
                            }
                            isLoading = true
                            scope.launch {
                                val (success, message) = onLogin(emailState.trim(), passwordState)
                                if (!success) {
                                    errorMessage = message
                                }
                                isLoading = false
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        enabled = !isLoading
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(NeonDarkTokens.CtaGradient, shape = RoundedCornerShape(16.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(
                                    color = NeonDarkTokens.TextPrimary,
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(22.dp)
                                )
                            } else {
                                Text(
                                    text = "Login",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NeonDarkTokens.TextPrimary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Don't have an account? ",
                            color = NeonDarkTokens.TextSecondary,
                            fontSize = 13.sp
                        )
                        TextButton(
                            onClick = {
                                val intent = Intent(context, SignupActivity::class.java)
                                context.startActivity(intent)
                                if (context is LoginActivity) context.finish()
                            }
                        ) {
                            Text(
                                text = "Sign up",
                                color = Color(0xFF38BDF8),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}

private data class User(
    val name: String,
    val email: String,
    val phone: String,
    val password: String
)
