package com.example.ridealertz

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ridealertz.ui.theme.RideAlertzTheme
import android.util.Log

class RoleSectionActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RideAlertzTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    RiderOnlyRoleScreen(
                        onRider = {
                            startActivity(Intent(this, SignupActivity::class.java))
                            finish()
                        },
                        onAmbulanceDriver = {
                            try {
                                val intent = Intent(this, AmbulanceDriverLoginActivity::class.java)
                                startActivity(intent)
                            } catch (e: Exception) {
                                Log.e("RoleSection", "Error starting AmbulanceDriverLoginActivity", e)
                                // Show error to user or handle gracefully
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun RiderOnlyRoleScreen(
    onRider: () -> Unit,
    onAmbulanceDriver: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF020617), Color(0xFF020617), Color(0xFF0B1120))
                )
            )
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(24.dp))

            // Top title + neon divider
            Text(
                text = "Choose Your Role",
                fontSize = 28.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Pick how you use RideAlertz today",
                fontSize = 16.sp,
                color = Color(0xFF9CA3AF)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Box(
                modifier = Modifier
                    .width(120.dp)
                    .height(3.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFF6366F1), Color(0xFF22C55E))
                        ),
                        shape = RoundedCornerShape(50)
                    )
            )

            Spacer(modifier = Modifier.height(36.dp))

            // Role cards
            RoleCard(
                icon = Icons.Default.DirectionsBike,
                title = "Rider",
                description = "Smart crash detection & emergency alerts",
                primaryColor = Color(0xFF6366F1),
                onClick = onRider
            )

            Spacer(modifier = Modifier.height(20.dp))

            RoleCard(
                icon = Icons.Default.LocalHospital,
                title = "Ambulance Driver",
                description = "Respond to rider emergencies in real-time",
                primaryColor = Color(0xFFF97316),
                onClick = onAmbulanceDriver
            )
        }
    }
}

@Composable
private fun RoleCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    primaryColor: Color,
    onClick: () -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ), label = "card-scale"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(120.dp)
            .scale(scale)
            .clickable(
                onClick = {
                    pressed = true
                    onClick()
                    pressed = false
                },
                onClickLabel = title
            ),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF020617)
        ),
        border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.6f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .background(primaryColor.copy(alpha = 0.18f), shape = RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = primaryColor,
                    modifier = Modifier.size(32.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = description,
                    fontSize = 14.sp,
                    color = Color(0xFF9CA3AF)
                )
            }
        }
    }
}
