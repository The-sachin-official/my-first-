package com.example.ridealertz.service

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import java.text.SimpleDateFormat
import java.util.*

class PostEmergencyActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        setContent {
            MaterialTheme {
                PostEmergencyScreen(
                    onReturnToDashboard = { finish() }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostEmergencyScreen(
    onReturnToDashboard: () -> Unit
) {
    val currentTime = SimpleDateFormat("MMM dd, yyyy 'at' HH:mm:ss", Locale.getDefault())
        .format(Date())
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        "Emergency Summary",
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFFE8F5E9),
                    titleContentColor = Color(0xFF2E7D32)
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(
                    Color(0xFFF5F5F5)
                )
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Success Header
            SuccessHeader()
            
            // Crash Details Card
            CrashDetailsCard(currentTime = currentTime)
            
            // Emergency Call Status
            EmergencyCallStatusCard()
            
            // Location Information
            LocationInfoCard()
            
            // Alerts Sent
            AlertsSentCard()
            
            // Action Buttons
            ActionButtons(onReturnToDashboard = onReturnToDashboard)
        }
    }
}

@Composable
fun SuccessHeader() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = Color(0xFF4CAF50)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(
                    text = "Emergency Response Complete",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF2E7D32)
                )
                Text(
                    text = "Help is on the way",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color(0xFF388E3C)
                )
            }
        }
    }
}

@Composable
fun CrashDetailsCard(currentTime: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = "Crash Details",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            DetailRow("Time Detected", currentTime, Icons.Default.Schedule)
            DetailRow("Detection Method", "Sensor + GPS", Icons.Default.Sensors)
            DetailRow("Impact Severity", "High", Icons.Default.Warning)
            DetailRow("Response Time", "2.3 seconds", Icons.Default.Timer)
        }
    }
}

@Composable
fun EmergencyCallStatusCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = "Emergency Call Status",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            DetailRow("Call Status", "Connected", Icons.Default.Call)
            DetailRow("Call Duration", "45 seconds", Icons.Default.Timer)
            DetailRow("Emergency Number", "108", Icons.Default.Emergency)
            DetailRow("Operator Response", "Yes", Icons.Default.Person)
        }
    }
}

@Composable
fun LocationInfoCard() {
    val context = LocalContext.current
    val prefs = context.getSharedPreferences("ridealertz", Context.MODE_PRIVATE)
    val lat = prefs.getFloat("last_lat", Float.NaN)
    val lng = prefs.getFloat("last_lng", Float.NaN)
    val acc = prefs.getFloat("last_acc", -1f)
    val timeMs = prefs.getLong("last_time", 0L)
    val hasLocation = !lat.isNaN() && !lng.isNaN()
    val coords = if (hasLocation) String.format(Locale.getDefault(), "%.6f°, %.6f°", lat, lng) else "Unavailable"
    val accuracyText = if (acc >= 0f) "±${acc.toInt()} meters" else "Unknown"
    val timeAgo = if (timeMs > 0L) {
        val seconds = ((System.currentTimeMillis() - timeMs) / 1000).coerceAtLeast(0)
        when {
            seconds < 60 -> "$seconds seconds ago"
            seconds < 3600 -> "${seconds / 60} minutes ago"
            else -> SimpleDateFormat("MMM dd, yyyy 'at' HH:mm:ss", Locale.getDefault()).format(Date(timeMs))
        }
    } else "Unknown"
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = "Location Information",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            DetailRow("GPS Coordinates", coords, Icons.Default.LocationOn)
            DetailRow("Address", "—", Icons.Default.Home)
            DetailRow("Accuracy", accuracyText, Icons.Default.GpsFixed)
            DetailRow("Location Time", timeAgo, Icons.Default.Update)
        }
    }
}

@Composable
fun AlertsSentCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = "Alerts Sent",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            DetailRow("Emergency Contacts", "3 contacts notified", Icons.Default.People)
            DetailRow("SMS Alerts", "3 messages sent", Icons.Default.Sms)
            DetailRow("Location Shared", "GPS coordinates included", Icons.Default.ShareLocation)
            DetailRow("Response Time", "Immediate", Icons.Default.Speed)
        }
    }
}

@Composable
fun DetailRow(label: String, value: String, icon: ImageVector) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(20.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun ActionButtons(onReturnToDashboard: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Button(
            onClick = onReturnToDashboard,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Home, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                "Return to Dashboard",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }
        
        OutlinedButton(
            onClick = { /* TODO: Share summary */ },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Share, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                "Share Summary",
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
