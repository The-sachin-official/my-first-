package com.example.ridealertz

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.example.ridealertz.ui.theme.RideAlertzTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

class ProfileDetailsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs: SharedPreferences = getSharedPreferences("ridealertz", MODE_PRIVATE)
        val userId = prefs.getString("user_uid", null)
            ?: ((
                prefs.getString("user_email", null)
                    ?: prefs.getString("user_phone", null)
                    ?: "guest"
                ).replace("@", "_")
            )

        setContent {
            RideAlertzTheme {
                ProfileDetailsScreen(
                    initialPrefs = prefs,
                    userId = userId,
                    onContinue = { profileMap, prefUpdates ->
                        lifecycleScope.launch {
                            // Save to RTDB + Firestore (user/{userId}) and also create a new auto-ID doc in user collection
                            withTimeoutOrNull(5000L) {
                                try {
                                    val now = System.currentTimeMillis()
                                    val data = profileMap.toMutableMap().apply {
                                        put("user_id", userId)
                                        put("create_at", now)
                                        put("update_at", now)
                                    }
                                    withContext(Dispatchers.IO) {
                                        FirebaseHelper.writeUserProfile(userId, data)
                                        // Update/overwrite the canonical profile document keyed by userId
                                        FirebaseHelper.saveUserProfileFirestore(userId, data)
                                        // Additionally, create a brand new document with auto-generated ID
                                        FirebaseHelper.addUserProfileFirestoreDocument(data)
                                    }
                                } catch (_: Exception) { }
                            }

                            // Persist to SharedPreferences for later steps / review screen
                            prefs.edit().apply {
                                prefUpdates.forEach { (k, v) ->
                                    when (v) {
                                        is String -> putString(k, v)
                                        is Boolean -> putBoolean(k, v)
                                    }
                                }
                                apply()
                            }

                            startActivity(Intent(this@ProfileDetailsActivity, VehicleDetailsActivity::class.java))
                            finish()
                        }
                    },
                    onBack = { finish() }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileDetailsScreen(
    initialPrefs: SharedPreferences,
    userId: String,
    onContinue: (profileMap: Map<String, Any>, prefUpdates: Map<String, Any>) -> Unit,
    onBack: () -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }

    var doorNo by remember { mutableStateOf("") }
    var street by remember { mutableStateOf("") }
    var area by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("") }
    var district by remember { mutableStateOf("") }
    var state by remember { mutableStateOf("") }
    var pincode by remember { mutableStateOf("") }

    var bloodGroup by remember { mutableStateOf("") }
    var emergencyName by remember { mutableStateOf("") }
    var emergencyPhone by remember { mutableStateOf("") }

    var isLoading by remember { mutableStateOf(true) }
    var isSubmitting by remember { mutableStateOf(false) }

    LaunchedEffect(userId) {
        // Prefill from SharedPreferences first
        fullName = initialPrefs.getString("first_name", "") ?: ""
        phone = initialPrefs.getString("user_phone", "") ?: ""
        email = initialPrefs.getString("user_email", "") ?: ""
        bloodGroup = initialPrefs.getString("bloodGroup", "") ?: ""
        city = initialPrefs.getString("city", "") ?: ""
        state = initialPrefs.getString("state", "") ?: ""
        pincode = initialPrefs.getString("postalCode", "") ?: ""
        emergencyName = initialPrefs.getString("emgName", "") ?: ""
        emergencyPhone = initialPrefs.getString("emgPhone", "") ?: ""

        // Best-effort: load from Firebase profile if available
        try {
            val map = withContext(Dispatchers.IO) { FirebaseHelper.readUserProfile(userId) }
            if (map != null) {
                (map["full_name"] as? String)?.let { fullName = it }
                (map["age"] as? Long)?.let { age = it.toString() }
                (map["gender"] as? String)?.let { gender = it }
                (map["phone"] as? String)?.let { phone = it }
                (map["email"] as? String)?.let { email = it }
                (map["door_no"] as? String)?.let { doorNo = it }
                (map["street"] as? String)?.let { street = it }
                (map["area"] as? String)?.let { area = it }
                (map["city"] as? String)?.let { city = it }
                (map["district"] as? String)?.let { district = it }
                (map["state"] as? String)?.let { state = it }
                (map["pincode"] as? String)?.let { pincode = it }
                (map["blood_group"] as? String)?.let { bloodGroup = it }
                (map["emergency_contact_name"] as? String)?.let { emergencyName = it }
                (map["emergency_contact_phone"] as? String)?.let { emergencyPhone = it }
            }
        } catch (_: Exception) { }

        isLoading = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                title = { Text("Profile Details", color = Color.White) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF020617))
            )
        },
        containerColor = Color(0xFF020617)
    ) { padding ->
        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = Color.White)
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Personal Information", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("Full Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = age,
                    onValueChange = { age = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Age") },
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Gender", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    listOf("Male", "Female", "Other").forEach { option ->
                        FilterChip(
                            selected = gender == option,
                            onClick = { gender = option },
                            label = { Text(option) },
                            shape = RoundedCornerShape(12.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF2563EB),
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text("Address", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = doorNo,
                    onValueChange = { doorNo = it },
                    label = { Text("Door / House No") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = street,
                    onValueChange = { street = it },
                    label = { Text("Street") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = area,
                    onValueChange = { area = it },
                    label = { Text("Area / Locality") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = city,
                    onValueChange = { city = it },
                    label = { Text("City") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = district,
                    onValueChange = { district = it },
                    label = { Text("District") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = state,
                    onValueChange = { state = it },
                    label = { Text("State") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = pincode,
                    onValueChange = { pincode = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Pincode") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text("Health & Emergency", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = bloodGroup,
                    onValueChange = { bloodGroup = it.uppercase() },
                    label = { Text("Blood Group") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = emergencyName,
                    onValueChange = { emergencyName = it },
                    label = { Text("Emergency Contact Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = emergencyPhone,
                    onValueChange = { emergencyPhone = it },
                    label = { Text("Emergency Contact Phone") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    enabled = !isSubmitting,
                    onClick = {
                        if (isSubmitting) return@Button
                        isSubmitting = true
                        val profileMap = mutableMapOf<String, Any>()
                        val addressLine2 = listOf(street, area, district)
                            .filter { it.isNotBlank() }
                            .joinToString(", ")

                        profileMap["full_name"] = fullName
                        profileMap["age"] = age.toIntOrNull() ?: 0
                        profileMap["gender"] = gender
                        profileMap["phone"] = phone
                        profileMap["email"] = email
                        profileMap["address_line1"] = doorNo
                        profileMap["address_line2"] = addressLine2
                        profileMap["city"] = city
                        profileMap["state"] = state
                        profileMap["pincode"] = pincode
                        profileMap["blood_group"] = bloodGroup
                        profileMap["emergency_contact_name"] = emergencyName
                        profileMap["emergency_contact_phone"] = emergencyPhone
                        profileMap["medical_conditions"] = ""
                        profileMap["medications"] = ""

                        val fullAddress = listOf(doorNo, street, area, city, district, state, pincode)
                            .filter { it.isNotBlank() }
                            .joinToString(", ")

                        val prefUpdates = mutableMapOf<String, Any>()
                        prefUpdates["first_name"] = fullName
                        prefUpdates["user_phone"] = phone
                        prefUpdates["user_email"] = email
                        prefUpdates["bloodGroup"] = bloodGroup
                        prefUpdates["address"] = fullAddress
                        prefUpdates["city"] = city
                        prefUpdates["state"] = state
                        prefUpdates["postalCode"] = pincode
                        prefUpdates["emgName"] = emergencyName
                        prefUpdates["emgPhone"] = emergencyPhone
                        prefUpdates["gender"] = gender

                        onContinue(profileMap, prefUpdates)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E))
                ) {
                    Text(
                        if (isSubmitting) "Saving..." else "Save & Continue",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
