package com.example.ridealertz

import android.app.Application
import android.util.Log
import com.google.firebase.FirebaseApp

/**
 * Application class to initialize Firebase early in app lifecycle.
 */
class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Ensure Firebase is initialized as early as possible
        FirebaseApp.initializeApp(this)
        Log.d("MyApplication", "Firebase initialized - apps: ${FirebaseApp.getApps(this).size}")
        
    }
}
