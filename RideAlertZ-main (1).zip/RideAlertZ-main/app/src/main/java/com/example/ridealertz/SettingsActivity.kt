package com.example.ridealertz

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ridealertz.ui.theme.RideAlertzTheme
import android.content.Context
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        val prefs = getSharedPreferences("ridealertz", MODE_PRIVATE)
        
        setContent {
            var isDarkMode by remember { 
                mutableStateOf(prefs.getBoolean("dark_mode", false)) 
            }
            
            RideAlertzTheme(darkTheme = isDarkMode) {
                SettingsScreen(
                    onBackPressed = { finish() },
                    onNavigateToContacts = { 
                        startActivity(Intent(this, com.example.ridealertz.service.EmergencyContactsActivity::class.java))
                    },
                    onLogout = {
                        // Sign out placeholder (Firebase Auth removed)
                        prefs.edit().clear().apply()
                        startActivity(Intent(this, LoginActivity::class.java))
                        finishAffinity()
                    },
                    isDarkMode = isDarkMode,
                    onDarkModeChange = { enabled ->
                        isDarkMode = enabled
                        prefs.edit().putBoolean("dark_mode", enabled).apply()
                    },
                    onEditProfile = {
                        startActivity(Intent(this, EditProfileActivity::class.java))
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBackPressed: () -> Unit,
    onNavigateToContacts: () -> Unit = {},
    onLogout: () -> Unit = {},
    isDarkMode: Boolean = false,
    onDarkModeChange: (Boolean) -> Unit = {},
    onEditProfile: () -> Unit = {}
) {
    val context = LocalContext.current
    val prefs = remember(context) {
        context.getSharedPreferences("ridealertz", Context.MODE_PRIVATE)
    }

    val scope = rememberCoroutineScope()
    val userId = remember { prefs.getString("user_id", "") ?: "" }

    var firstName by remember { mutableStateOf(prefs.getString("first_name", "") ?: "") }
    var lastName by remember { mutableStateOf(prefs.getString("last_name", "") ?: "") }
    var email by remember { mutableStateOf(prefs.getString("user_email", "") ?: "") }
    var phone by remember { mutableStateOf(prefs.getString("user_phone", "") ?: "") }
    var city by remember { mutableStateOf(prefs.getString("city", "") ?: "") }
    var country by remember { mutableStateOf(prefs.getString("country", "") ?: "") }

    var autoStart by remember { mutableStateOf(false) }
    var highSensitivity by remember { mutableStateOf(false) }
    var soundAlerts by remember { mutableStateOf(true) }
    var vibrationAlerts by remember { mutableStateOf(true) }
    var speedLimit by remember { mutableStateOf(60) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        "Settings",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackPressed) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Appearance Section
            SettingsSection(title = "Appearance") {
                SettingsSwitchItem(
                    icon = Icons.Default.DarkMode,
                    title = "Dark Mode",
                    subtitle = "Use dark theme for better night visibility",
                    checked = isDarkMode,
                    onCheckedChange = onDarkModeChange
                )
            }
            
            // Driving Mode Section
            SettingsSection(title = "Driving Mode") {
                SettingsItem(
                    icon = Icons.Default.DirectionsCar,
                    title = "Speed Limit",
                    subtitle = "Set default speed limit: $speedLimit km/h",
                    onClick = { /* TODO: Show speed limit picker */ }
                )
                SettingsSwitchItem(
                    icon = Icons.Default.Videocam,
                    title = "Auto-Start Dashcam",
                    subtitle = "Start dashcam when driving mode begins",
                    checked = autoStart,
                    onCheckedChange = { autoStart = it }
                )
            }
            
            // Emergency Contacts Section
            SettingsSection(title = "Emergency") {
                SettingsItem(
                    icon = Icons.Default.Emergency,
                    title = "Emergency Contacts",
                    subtitle = "Manage your emergency contacts",
                    onClick = onNavigateToContacts
                )
                SettingsItem(
                    icon = Icons.Default.Call,
                    title = "Emergency Services",
                    subtitle = "Configure emergency call settings",
                    onClick = { /* Navigate to emergency services */ }
                )
            }
            
            // Monitoring Section
            SettingsSection(title = "Monitoring") {
                SettingsSwitchItem(
                    icon = Icons.Default.PlayArrow,
                    title = "Auto-Start Monitoring",
                    subtitle = "Start monitoring when app opens",
                    checked = autoStart,
                    onCheckedChange = { autoStart = it }
                )
                SettingsSwitchItem(
                    icon = Icons.Default.Sensors,
                    title = "High Sensitivity",
                    subtitle = "Detect minor impacts",
                    checked = highSensitivity,
                    onCheckedChange = { highSensitivity = it }
                )
            }
            
            // Notifications Section
            SettingsSection(title = "Notifications") {
                SettingsSwitchItem(
                    icon = Icons.Default.VolumeUp,
                    title = "Sound Alerts",
                    subtitle = "Play sound on crash detection",
                    checked = soundAlerts,
                    onCheckedChange = { soundAlerts = it }
                )
                SettingsSwitchItem(
                    icon = Icons.Default.Vibration,
                    title = "Vibration",
                    subtitle = "Vibrate on alerts",
                    checked = vibrationAlerts,
                    onCheckedChange = { vibrationAlerts = it }
                )
            }
            
            // Location Section
            SettingsSection(title = "Location") {
                SettingsItem(
                    icon = Icons.Default.LocationOn,
                    title = "GPS Settings",
                    subtitle = "Configure location tracking",
                    onClick = { /* Navigate to GPS settings */ }
                )
                SettingsItem(
                    icon = Icons.Default.Share,
                    title = "Location Sharing",
                    subtitle = "Manage location sharing preferences",
                    onClick = { /* Navigate to location sharing */ }
                )
            }
            
            // About Section
            SettingsSection(title = "About") {
                SettingsItem(
                    icon = Icons.Default.Info,
                    title = "App Version",
                    subtitle = "1.0.0",
                    onClick = { }
                )
                SettingsItem(
                    icon = Icons.Default.PrivacyTip,
                    title = "Privacy Policy",
                    subtitle = "View our privacy policy",
                    onClick = { /* Open privacy policy */ }
                )
                SettingsItem(
                    icon = Icons.Default.Help,
                    title = "Help & Support",
                    subtitle = "Get help using RideAlertz",
                    onClick = { /* Open help */ }
                )
                // Logout item
                SettingsItem(
                    icon = Icons.Default.ExitToApp,
                    title = "Log out",
                    subtitle = "Sign out of your account",
                    onClick = onLogout
                )
            }
        }
    }
}

@Composable
fun SettingsSection(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
        )
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier.padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                content()
            }
        }
    }
}

@Composable
fun SettingsItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun SettingsSwitchItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = MaterialTheme.colorScheme.secondary,
                checkedTrackColor = MaterialTheme.colorScheme.secondaryContainer
            )
        )
    }
}
