package com.example.ridealertz.service

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.telephony.SmsManager
import android.util.Log
import android.speech.tts.TextToSpeech
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.example.ridealertz.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import androidx.lifecycle.lifecycleScope
import androidx.compose.material.icons.filled.Home

class CrashAlertActivity : ComponentActivity() {
    private var toneGenerator: ToneGenerator? = null
    private var vibrator: Vibrator? = null
    private var countdownJob: Job? = null
    private var tts: TextToSpeech? = null
    private var primaryContactNumber: String? = null
    private var primaryContactLabel: String = "Primary Contact"
    private var hasSentEmergencySms: Boolean = false
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var lastKnownLocation: Location? = null
    
    private val callPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            makeEmergencyCall()
        }
    }
    
    private val smsPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            // Retry sending SMS if permission was granted
            sendEmergencySms()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize audio and vibration
        toneGenerator = ToneGenerator(AudioManager.STREAM_ALARM, 100)
        vibrator = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            val vibratorManager = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }
        
        // Initialize TTS
        tts = TextToSpeech(this) { }

        // Initialize location client and try to get last known location
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        updateLastKnownLocation()

        // Load primary emergency contact (if any)
        loadPrimaryEmergencyContact()

        setContent {
            MaterialTheme {
                CrashAlertScreen(
                    onImOk = { handleImOk() },
                    onCallEmergency = { handleCallEmergency() },
                    primaryContactNumber = primaryContactNumber,
                    primaryContactLabel = primaryContactLabel,
                    onQuickDialPrimary = { quickDialPrimaryContact() }
                )
            }
        }
        
        // Start emergency sequence
        startEmergencySequence()
    }
    
    private fun startEmergencySequence() {
        // Start continuous alarm sound
        toneGenerator?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 20000)
        
        // Start vibration pattern
        startVibrationPattern()
        
        // Start 8-second countdown
        startCountdown()

        // Voice feedback
        speakOut("Crash detected. Calling emergency in eight seconds. Tap I'm OK or Call Emergency.")
    }
    
    private fun startVibrationPattern() {
        val pattern = longArrayOf(0, 500, 200, 500, 200, 500)
        val amplitudes = intArrayOf(0, 255, 0, 255, 0, 255)
        
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val effect = VibrationEffect.createWaveform(pattern, amplitudes, 0)
            vibrator?.vibrate(effect)
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(pattern, 0)
        }
    }
    
    private fun startCountdown() {
        countdownJob = lifecycleScope.launch {
            delay(8000) // 8 seconds
            // Auto-call emergency if no response
            handleCallEmergency()
        }
    }
    
    private fun handleImOk() {
        // Stop emergency sequence
        stopEmergencySequence()
        
        // Send "I'm OK" SMS to emergency contacts
        sendImOkSms()
        
        // Show success message and return to dashboard
        showSuccessMessage()

        // Voice feedback
        speakOut("Acknowledged. You are okay. No emergency call will be placed.")
    }
    
    private fun handleCallEmergency() {
        // Send emergency SMS first
        sendEmergencySms()
        
        // Stop emergency sequence
        stopEmergencySequence()

        // Launch emergency call activity
        launchEmergencyCall()

        // Voice feedback
        speakOut("Calling emergency services now.")
    }
    
    private fun makeEmergencyCall() {
        try {
            val intent = Intent(Intent.ACTION_CALL)
            intent.data = Uri.parse("tel:108") // Emergency number
            startActivity(intent)
        } catch (e: Exception) {
            // Fallback to dialer
            val intent = Intent(Intent.ACTION_DIAL)
            intent.data = Uri.parse("tel:108")
            startActivity(intent)
        }
    }
    
    private fun sendImOkSms() {
        try {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                try {
                    val smsManager = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                        this.getSystemService(SmsManager::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        SmsManager.getDefault()
                    }
                    val locationSuffix = buildLocationSuffix()
                    val message = "I'm OK - No emergency needed. $locationSuffix"
                    getEmergencyContactsFromPrefs().forEach { contact ->
                        try {
                            smsManager.sendTextMessage(contact.phone, null, message, null, null)
                            Log.d("CrashAlert", "I'm OK SMS sent to ${contact.phone}")
                        } catch (e: Exception) {
                            Log.e("CrashAlert", "Failed to send I'm OK SMS to ${contact.phone}: ${e.message}")
                        }
                    }
                } catch (e: SecurityException) {
                    Log.e("CrashAlert", "Security Exception in sendImOkSms: ${e.message}")
                    smsPermissionLauncher.launch(Manifest.permission.SEND_SMS)
                }
            } else {
                smsPermissionLauncher.launch(Manifest.permission.SEND_SMS)
            }
        } catch (e: Exception) {
            Log.e("CrashAlert", "Error in sendImOkSms: ${e.message}")
        }
    }

    private fun sendEmergencySms() {
        try {
            // Check if we have SMS permission
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                try {
                    // We have permission, proceed with sending SMS
                    val smsManager = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                        this.getSystemService(SmsManager::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        SmsManager.getDefault()
                    }
                    val locationSuffix = buildLocationSuffix()
                    val message = "CRASH DETECTED! Auto-calling 108. $locationSuffix"
                    
                    getEmergencyContactsFromPrefs().forEach { contact ->
                        try {
                            smsManager.sendTextMessage(contact.phone, null, message, null, null)
                            Log.d("CrashAlert", "SMS sent to ${contact.phone}")
                        } catch (e: Exception) {
                            Log.e("CrashAlert", "Failed to send SMS to ${contact.phone}: ${e.message}")
                        }
                    }
                } catch (e: SecurityException) {
                    Log.e("CrashAlert", "Security Exception: ${e.message}")
                    // Request the permission again if we got a SecurityException
                    smsPermissionLauncher.launch(Manifest.permission.SEND_SMS)
                }
            } else {
                // Request the permission
                smsPermissionLauncher.launch(Manifest.permission.SEND_SMS)
            }
        } catch (e: Exception) {
            Log.e("CrashAlert", "Error in sendEmergencySms: ${e.message}")
        }
    }

    private fun buildLocationSuffix(): String {
        return try {
            // 1) Prefer last saved location from prefs (Ride map writes last_lat/last_lng)
            val prefs = getSharedPreferences("ridealertz", MODE_PRIVATE)
            val latPref = prefs.getFloat("last_lat", Float.NaN)
            val lngPref = prefs.getFloat("last_lng", Float.NaN)
            if (!latPref.isNaN() && !lngPref.isNaN()) {
                val latD = latPref.toDouble()
                val lngD = lngPref.toDouble()
                "Location: %.6f, %.6f | Maps: https://maps.google.com/?q=%.6f,%.6f".format(latD, lngD, latD, lngD)
            } else {
                // 2) Fallback to in-memory lastKnownLocation if prefs are missing
                val loc = lastKnownLocation
                if (loc != null) {
                    val latD = loc.latitude
                    val lngD = loc.longitude
                    "Location: %.6f, %.6f | Maps: https://maps.google.com/?q=%.6f,%.6f".format(latD, lngD, latD, lngD)
                } else {
                    "Location unavailable"
                }
            }
        } catch (_: Exception) { "Location unavailable" }
    }

    private fun updateLastKnownLocation() {
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            ) {
                // First, try to get a fresh high-accuracy fix
                val cts = CancellationTokenSource()
                fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.token)
                    .addOnSuccessListener { location: Location? ->
                        if (location != null) {
                            lastKnownLocation = location
                            if (!hasSentEmergencySms) {
                                sendEmergencySms()
                                hasSentEmergencySms = true
                            }
                        } else {
                            // Fallback to lastLocation if currentLocation returns null
                            fusedLocationClient.lastLocation
                                .addOnSuccessListener { lastLoc: Location? ->
                                    if (lastLoc != null) {
                                        lastKnownLocation = lastLoc
                                        if (!hasSentEmergencySms) {
                                            sendEmergencySms()
                                            hasSentEmergencySms = true
                                        }
                                    } else if (!hasSentEmergencySms) {
                                        // No location at all, still notify with fallback text
                                        sendEmergencySms()
                                        hasSentEmergencySms = true
                                    }
                                }
                        }
                    }
            } else if (!hasSentEmergencySms) {
                // No permission, still send SMS with "Location unavailable"
                sendEmergencySms()
                hasSentEmergencySms = true
            }
        } catch (_: Exception) { }
    }
    
    private fun stopEmergencySequence() {
        countdownJob?.cancel()
        toneGenerator?.stopTone()
        vibrator?.cancel()
    }
    
    override fun onDestroy() {
        super.onDestroy()
        stopEmergencySequence()
        toneGenerator?.release()
        tts?.stop()
        tts?.shutdown()
    }

    private fun showSuccessMessage() {
        // Show a brief success message before closing
        setContent {
            MaterialTheme {
                SuccessMessageScreen {
                    finish()
                }
            }
        }
    }
    
    private fun launchEmergencyCall() {
        val intent = Intent(this, EmergencyCallActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun speakOut(message: String) {
        try {
            tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "crash_alert_tts")
        } catch (_: Exception) { }
    }

    private fun loadPrimaryEmergencyContact() {
        try {
            val contacts = getEmergencyContactsFromPrefs()
            val primary = contacts.firstOrNull { it.isPrimary } ?: contacts.firstOrNull()
            if (primary != null) {
                primaryContactNumber = primary.phone
                primaryContactLabel = primary.name
            } else {
                val prefs = getSharedPreferences("ridealertz", MODE_PRIVATE)
                val fallbackName = prefs.getString("emgName", null)
                val fallbackPhone = prefs.getString("emgPhone", null)
                if (!fallbackName.isNullOrBlank() && !fallbackPhone.isNullOrBlank()) {
                    primaryContactNumber = fallbackPhone
                    primaryContactLabel = fallbackName
                }
            }
        } catch (_: Exception) { }
    }

    private fun getEmergencyContactsFromPrefs(): List<EmergencyContact> {
        return try {
            val prefs = getSharedPreferences("ridealertz", MODE_PRIVATE)
            val json = prefs.getString("emergency_contacts", "[]") ?: "[]"
            val type = object : TypeToken<List<EmergencyContact>>() {}.type
            val contacts: List<EmergencyContact> = Gson().fromJson(json, type) ?: emptyList()
            contacts.filter { it.phone.isNotBlank() }
        } catch (e: Exception) {
            Log.e("CrashAlert", "Error loading emergency contacts: ${e.message}")
            emptyList()
        }
    }

    private fun quickDialPrimaryContact() {
        val phone = primaryContactNumber ?: return
        try {
            val intent = Intent(Intent.ACTION_DIAL)
            intent.data = Uri.parse("tel:$phone")
            startActivity(intent)
        } catch (_: Exception) { }
    }
}

@Composable
fun CrashAlertScreen(
    onImOk: () -> Unit,
    onCallEmergency: () -> Unit,
    primaryContactNumber: String?,
    primaryContactLabel: String,
    onQuickDialPrimary: () -> Unit
) {
    var countdown by remember { mutableStateOf(8) }
    
    // Countdown effect
    LaunchedEffect(Unit) {
        while (countdown > 0) {
            delay(1000)
            countdown--
        }
    }
    
    // Pulsing animation for warning icon
    val infiniteTransition = rememberInfiniteTransition()
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE53E3E))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Warning Icon with pulse animation
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Warning",
                modifier = Modifier
                    .size(120.dp)
                    .scale(scale),
                tint = Color(0xFFFFFFFF)
            )
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Emergency Title
            Text(
                text = "CRASH DETECTED!",
                fontSize = 36.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Countdown
            Text(
                text = "Emergency call in ${countdown}s",
                fontSize = 24.sp,
                color = Color.White,
                fontWeight = FontWeight.Medium
            )

            // Primary contact quick dial
            if (primaryContactNumber != null) {
                Spacer(modifier = Modifier.height(24.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFFFF).copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = null,
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(primaryContactNumber, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                            Text(primaryContactLabel, color = Color(0xFFEFEFEF), fontSize = 12.sp)
                        }
                        OutlinedButton(
                            onClick = onQuickDialPrimary,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) {
                            Text("Quick Dial")
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(48.dp))
            
            // Action Buttons
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                // I'm OK Button
                Button(
                    onClick = onImOk,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF38A169)
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            modifier = Modifier.size(32.dp),
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = "I'M OK",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
                
                // Call Emergency Button
                Button(
                    onClick = onCallEmergency,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFB71C1C)
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Emergency,
                            contentDescription = null,
                            modifier = Modifier.size(32.dp),
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = "CALL EMERGENCY",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Instructions
            Text(
                text = "If you don't respond, emergency services will be called automatically",
                fontSize = 16.sp,
                color = Color(0xFFFAEAEA),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun SuccessMessageScreen(
    onReturnToDashboard: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE8F5E9))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Success",
                modifier = Modifier.size(120.dp),
                tint = Color(0xFF4CAF50)
            )
            
            Spacer(modifier = Modifier.height(32.dp))
            
            Text(
                text = "We're glad you're safe! 👍",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF2E7D32),
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text(
                text = "No emergency services were contacted",
                fontSize = 18.sp,
                color = Color(0xFF388E3C),
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(48.dp))
            
            Button(
                onClick = onReturnToDashboard,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF4CAF50)
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Home,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "Return to Dashboard",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}
