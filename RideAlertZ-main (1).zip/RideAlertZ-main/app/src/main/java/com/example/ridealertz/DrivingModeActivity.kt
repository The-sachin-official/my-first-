package com.example.ridealertz

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import com.example.ridealertz.service.DrivingBehaviorAnalyzer
import com.example.ridealertz.service.SensorMonitoringService
import com.example.ridealertz.ui.theme.RideAlertzTheme
import java.util.*

class DrivingModeActivity : ComponentActivity() {
    private lateinit var behaviorAnalyzer: DrivingBehaviorAnalyzer
    private lateinit var textToSpeech: TextToSpeech
    private var ttsReady = false
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        behaviorAnalyzer = DrivingBehaviorAnalyzer(this)
        
        // Initialize Text-to-Speech for hands-free alerts
        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech.language = Locale.getDefault()
                ttsReady = true
            }
        }
        
        // Setup behavior callbacks
        behaviorAnalyzer.setCallbacks(
            onHarshBrake = { intensity ->
                speak("Warning: Harsh braking detected")
            },
            onSharpTurn = { intensity ->
                speak("Warning: Sharp turn detected")
            },
            onSpeedViolation = { currentSpeed, limit ->
                speak("Speed limit exceeded. Current speed ${currentSpeed.toInt()} kilometers per hour")
            }
        )
        
        setContent {
            RideAlertzTheme(darkTheme = true) { // Force dark mode for driving
                DrivingModeScreen(
                    analyzer = behaviorAnalyzer,
                    onEndDriving = { endDrivingMode() }
                )
            }
        }
        
        startDrivingMode()
    }
    
    private fun startDrivingMode() {
        // Start trip tracking
        behaviorAnalyzer.startTrip()
        
        // Start sensor monitoring service
        val serviceIntent = Intent(this, SensorMonitoringService::class.java)
        startService(serviceIntent)
    }
    
    private fun endDrivingMode() {
        behaviorAnalyzer.endTrip()
        
        // Show score screen
        val intent = Intent(this, SafeDrivingScoreActivity::class.java)
        startActivity(intent)
        finish()
    }
    
    private fun speak(text: String) {
        if (ttsReady) {
            textToSpeech.speak(text, TextToSpeech.QUEUE_ADD, null, null)
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        textToSpeech.shutdown()
    }
}

@Composable
fun DrivingModeScreen(
    analyzer: DrivingBehaviorAnalyzer,
    onEndDriving: () -> Unit
) {
    var stats by remember { mutableStateOf(analyzer.getCurrentStats()) }
    var speedLimit by remember { mutableStateOf(60.0) }
    
    // Update stats periodically
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(1000)
            stats = analyzer.getCurrentStats()
        }
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Section - Status Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Time
                Text(
                    text = "${stats.duration} min",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            
            // Center Section - Large Speed Display
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Current Speed
                Text(
                    text = "${stats.currentSpeed.toInt()}",
                    color = if (stats.currentSpeed > speedLimit) Color(0xFFEF4444) else Color.White,
                    fontSize = 120.sp,
                    fontWeight = FontWeight.Bold
                )
                
                Text(
                    text = "km/h",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 24.sp
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Speed Limit
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(
                            Color.White.copy(alpha = 0.1f),
                            shape = RoundedCornerShape(16.dp)
                        )
                        .padding(horizontal = 24.dp, vertical = 12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Limit: ${speedLimit.toInt()} km/h",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                
                // Speed warning animation
                if (stats.currentSpeed > speedLimit) {
                    SpeedWarningIndicator()
                }
            }
            
            // Bottom Section - Stats and Controls
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Driving Stats Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    DrivingStatCard(
                        icon = Icons.Default.Route,
                        value = String.format("%.1f", stats.totalDistance),
                        label = "km",
                        color = Color(0xFF10B981)
                    )
                    
                    DrivingStatCard(
                        icon = Icons.Default.Warning,
                        value = "${stats.harshBrakingCount}",
                        label = "Harsh",
                        color = Color(0xFFEF4444)
                    )
                    
                    DrivingStatCard(
                        icon = Icons.Default.TurnRight,
                        value = "${stats.sharpTurnCount}",
                        label = "Turns",
                        color = Color(0xFFF59E0B)
                    )
                    
                    DrivingStatCard(
                        icon = Icons.Default.Speed,
                        value = "${stats.speedViolationCount}",
                        label = "Speed",
                        color = Color(0xFFEF4444)
                    )
                }
                
                // Control Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // End Driving Button
                    Button(
                        onClick = onEndDriving,
                        modifier = Modifier.weight(1f).height(56.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFEF4444)
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = null,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "End Trip",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SpeedWarningIndicator() {
    val infiniteTransition = rememberInfiniteTransition(label = "warning")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )
    
    Spacer(modifier = Modifier.height(16.dp))
    
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .background(
                Color(0xFFEF4444).copy(alpha = alpha),
                shape = RoundedCornerShape(16.dp)
            )
            .padding(horizontal = 24.dp, vertical = 12.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(28.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = "SPEED LIMIT EXCEEDED",
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun DrivingStatCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    value: String,
    label: String,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .background(
                Color.White.copy(alpha = 0.1f),
                shape = RoundedCornerShape(16.dp)
            )
            .padding(16.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(28.dp)
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = value,
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        
        Text(
            text = label,
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 12.sp
        )
    }
}
