package com.example.ridealertz

import com.google.firebase.database.ServerValue
import com.google.firebase.database.ktx.database
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.delay
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.GenericTypeIndicator
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Simple helper for writing/reading small data to Firebase Realtime Database.
 * This uses Kotlin coroutines (run from a coroutine scope).
 */
object FirebaseHelper {
    private val database = Firebase.database("https://ridealertz-36b0b-default-rtdb.firebaseio.com").reference
    private val firestore = FirebaseFirestore.getInstance()

    suspend fun writeUser(userId: String, map: Map<String, Any>) {
        database.child("users").child(userId).setValue(map).await()
    }

    suspend fun writeUserProfile(userId: String, profile: Map<String, Any>) {
        database.child("users").child(userId).child("profile").setValue(profile).await()
    }

    suspend fun writeUserVehicle(userId: String, vehicle: Map<String, Any>) {
        database.child("users").child(userId).child("vehicle_details").setValue(vehicle).await()
    }

    suspend fun saveEmergencyContacts(userId: String, contacts: List<Map<String, Any>>) {
        database.child("users").child(userId).child("emergency_contacts").setValue(contacts).await()
    }

    suspend fun readEmergencyContacts(userId: String): List<Map<String, Any>> {
        val snapshot = database.child("users").child(userId).child("emergency_contacts").get().await()
        val type = object : GenericTypeIndicator<List<Map<String, Any>>>() {}
        return snapshot.getValue(type) ?: emptyList()
    }

    suspend fun readUserProfile(userId: String): Map<String, Any>? {
        val snapshot = database.child("users").child(userId).child("profile").get().await()
        return snapshot.value as? Map<String, Any>
    }

    suspend fun readUserVehicle(userId: String): Map<String, Any>? {
        val snapshot = database.child("users").child(userId).child("vehicle_details").get().await()
        return snapshot.value as? Map<String, Any>
    }

    suspend fun readUser(userId: String): Map<String, Any>? {
        val snapshot = database.child("users").child(userId).get().await()
        return snapshot.value as? Map<String, Any>
    }

    // ---- Firestore helpers: primary storage for profile + vehicle ----

    suspend fun saveUserProfileFirestore(userId: String, data: Map<String, Any>) {
        firestore.collection("user").document(userId).set(data).await()
    }

    suspend fun addUserProfileFirestoreDocument(data: Map<String, Any>) {
        firestore.collection("user").add(data).await()
    }

    suspend fun updateUserVehicleFirestore(userId: String, vehicleDetails: Map<String, Any>) {
        val now = System.currentTimeMillis()
        firestore.collection("user").document(userId)
            .update(
                mapOf(
                    "vehicle_details" to vehicleDetails,
                    "update_at" to now
                )
            )
            .await()
    }

    /**
     * Reliable connectivity check:
     * 1) Listen to .info/connected and wait up to 5s for true.
     * 2) If not true, try a tiny write (optional) to confirm backend reachability.
     */
    suspend fun isConnected(): Boolean {
        return try {
            val db = Firebase.database("https://ridealertz-36b0b-default-rtdb.firebaseio.com")
            val infoRef = db.getReference(".info/connected")
            val connected = withTimeoutOrNull(5_000) {
                suspendCancellableCoroutine<Boolean> { cont ->
                    val listener = object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            val v = snapshot.getValue(Boolean::class.java) ?: false
                            if (v && cont.isActive) cont.resume(true) {}
                        }
                        override fun onCancelled(error: DatabaseError) {
                            if (cont.isActive) cont.resume(false) {}
                        }
                    }
                    infoRef.addValueEventListener(listener)
                    cont.invokeOnCancellation { infoRef.removeEventListener(listener) }
                }
            } ?: false
            if (connected) return true
            // Fallback: tiny write proves backend reachability (may require permissive rules)
            db.getReference("__healthcheck__/ping").setValue(ServerValue.TIMESTAMP).await()
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun ping(): Boolean {
        return try {
            Firebase.database("https://ridealertz-36b0b-default-rtdb.firebaseio.com")
                .getReference("__healthcheck__/ts")
                .setValue(ServerValue.TIMESTAMP)
                .await()
            true
        } catch (_: Exception) {
            false
        }
    }

}
