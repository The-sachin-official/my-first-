package com.example.ridealertz

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.location.Geocoder
import android.location.Location
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.google.firebase.FirebaseApp
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.activity.viewModels
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.edit
import androidx.lifecycle.lifecycleScope
import com.example.ridealertz.service.SensorMonitoringService
import com.example.ridealertz.ui.theme.RideAlertzTheme
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.*
import com.example.ridealertz.FirebaseHelper
import java.text.SimpleDateFormat
import java.util.*
import android.net.Uri
import android.telephony.SmsManager
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.example.ridealertz.service.WeatherViewModel
import com.example.ridealertz.service.WeatherViewModelFactory
import com.example.ridealertz.service.WeatherUiState
import com.example.ridealertz.service.WeatherData
import com.example.ridealertz.service.HourlyForecast
import com.example.ridealertz.service.DailyForecast
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import kotlin.math.roundToInt

private val NeonOrangeGradientColors = listOf(
    Color(0xFFFF6E00),
    Color(0xFFFF3D00),
    Color(0xFFFF6B22)
)
private val NeonGlowColor = Color(0x52FF5A00)

class MainActivityNew : ComponentActivity() {
    private val showLocationPrompt = mutableStateOf(false)
    private val locationTextState = mutableStateOf("")
    private lateinit var prefs: SharedPreferences
    private val weatherViewModel: WeatherViewModel by viewModels { WeatherViewModelFactory(application) }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
            if (isLocationPermissionGranted()) {
                showLocationPrompt.value = false
                refreshLocation()
            } else if (shouldShowLocationPrompt()) {
                showLocationPrompt.value = true
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Ensure Firebase is initialized
        try {
            FirebaseApp.initializeApp(this)
        } catch (e: Exception) {
            // ignore initialization errors here; plugin will usually handle init
        }
        
        prefs = getSharedPreferences("ridealertz", MODE_PRIVATE)
        
        // Get user info
        val userName = (
            prefs.getString("first_name", null)
                ?: prefs.getString("user_name", null)
                ?: prefs.getString("user_full_name", null)
        ).takeIf { !it.isNullOrBlank() } ?: "Rider"
        val batteryLevel = getBatteryLevel()
        
        showLocationPrompt.value = shouldShowLocationPrompt()
        locationTextState.value = prefs.getString("last_location_text", "Fetching location…") ?: "Fetching location…"

        val activityContext = this@MainActivityNew

        setContent {
            RideAlertzTheme {
                val promptVisible by showLocationPrompt
                val currentLocationText by locationTextState
                val weatherState by weatherViewModel.uiState.collectAsState()

                Box {
                    SmartDashboardScreen(
                        context = activityContext,
                        userName = userName,
                        batteryLevel = batteryLevel,
                        currentLocationText = currentLocationText,
                        onRequestLocationRefresh = { refreshLocation() },
                        onSOS = { startSOS() },
                        onSettings = { startSettings() },
                        onStartRide = { startRide() },
                        onStopRide = { stopRide() },
                        onStartDriving = { startDrivingMode() },
                        onViewScore = { viewSafetyScore() },
                        onHospitalFinder = { openHospitalFinder() },
                        onTravelHistory = { openTravelHistory() },
                        onAccidentLog = { viewAccidentLog() },
                        onDatabaseTest = { openDatabaseTest() },
                        onEditProfile = { startProfile() },
                        onEditVehicle = { startVehicleSetup() },
                        onProfileRefreshRequested = { fetchLatestProfileData() },
                        weatherState = weatherState,
                        onWeatherRefresh = { weatherViewModel.refreshWeather() }
                    )

                    if (promptVisible) {
                        LocationPermissionPrompt(
                            onDismiss = { finish() },
                            onAccept = { requestAllPermissions() }
                        )
                    }
                }
            }
        }

        if (!showLocationPrompt.value) {
            requestAllPermissions()
            refreshLocation()
        }
    }

    override fun onResume() {
        super.onResume()
        fetchLatestProfileData()
        if (isLocationPermissionGranted()) {
            refreshLocation()
        }
    }

    private fun fetchLatestProfileData() {
        val userId = prefs.getString("user_uid", null)
            ?: prefs.getString("user_email", null)?.replace("@", "_")
            ?: prefs.getString("user_phone", null)
            ?: return
        lifecycleScope.launch {
            try {
                val profile = FirebaseHelper.readUserProfile(userId)
                val vehicle = FirebaseHelper.readUserVehicle(userId)
                if (profile != null) {
                    prefs.edit {
                        (profile["full_name"] as? String)?.let { putString("first_name", it) }
                        (profile["phone"] as? String)?.let { putString("user_phone", it) }
                        (profile["email"] as? String)?.let { putString("user_email", it) }
                        (profile["blood_group"] as? String)?.let { putString("bloodGroup", it) }
                        (profile["city"] as? String)?.let { putString("city", it) }
                        (profile["state"] as? String)?.let { putString("state", it) }
                        (profile["pincode"] as? String)?.let { putString("postalCode", it) }
                        (profile["emergency_contact_name"] as? String)?.let { putString("emgName", it) }
                        (profile["emergency_contact_phone"] as? String)?.let { putString("emgPhone", it) }
                        val addressLine1 = profile["address_line1"] as? String ?: ""
                        val addressLine2 = profile["address_line2"] as? String ?: ""
                        putString("address", listOf(addressLine1, addressLine2).filter { it.isNotBlank() }.joinToString(", "))
                    }
                }
                if (vehicle != null) {
                    prefs.edit {
                        (vehicle["vehicle_name"] as? String)?.let { putString("vehicle_name", it) }
                        (vehicle["vehicle_type"] as? String)?.let { putString("vehicle_type", it) }
                        (vehicle["vehicle_number"] as? String)?.let { putString("vehicle_number", it) }
                        (vehicle["vehicle_color"] as? String)?.let { putString("vehicle_color", it) }
                    }
                }
            } catch (_: Exception) { }
        }
    }

    private fun getBatteryLevel(): Int {
        val batteryStatus: Intent? = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let { ifilter ->
            registerReceiver(null, ifilter)
        }
        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        return if (level != -1 && scale != -1) {
            (level * 100 / scale.toFloat()).toInt()
        } else {
            0
        }
    }

    private fun requestAllPermissions() {
        val perms = mutableListOf<String>()

        fun addIfMissing(permission: String) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                perms.add(permission)
            }
        }

        addIfMissing(Manifest.permission.ACCESS_FINE_LOCATION)
        addIfMissing(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            addIfMissing(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        }
        addIfMissing(Manifest.permission.SEND_SMS)
        addIfMissing(Manifest.permission.CALL_PHONE)
        addIfMissing(Manifest.permission.CAMERA)
        addIfMissing(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            addIfMissing(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (perms.isNotEmpty()) {
            permissionLauncher.launch(perms.toTypedArray())
        } else if (isLocationPermissionGranted()) {
            showLocationPrompt.value = false
            refreshLocation()
        }
    }

    private fun shouldShowLocationPrompt(): Boolean {
        return !isLocationPermissionGranted()
    }

    private fun isLocationPermissionGranted(): Boolean {
        val fineGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        return fineGranted || coarseGranted
    }

    private fun refreshLocation() {
        if (!isLocationPermissionGranted()) {
            showLocationPrompt.value = true
            return
        }

        val fusedClient = LocationServices.getFusedLocationProviderClient(this)
        try {
            fusedClient.lastLocation
                .addOnSuccessListener { location ->
                    if (location != null) {
                        handleLocationUpdate(location)
                    } else {
                        requestSingleHighAccuracyLocation()
                    }
                }
                .addOnFailureListener {
                    requestSingleHighAccuracyLocation()
                }
        } catch (_: SecurityException) {
            // Permission revoked mid-session
            showLocationPrompt.value = true
        }
    }

    private fun requestSingleHighAccuracyLocation() {
        val fusedClient = LocationServices.getFusedLocationProviderClient(this)
        try {
            fusedClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, CancellationTokenSource().token)
                .addOnSuccessListener { location ->
                    location?.let { handleLocationUpdate(it) }
                }
        } catch (_: SecurityException) {
            showLocationPrompt.value = true
        }
    }

    private fun handleLocationUpdate(location: Location) {
        prefs.edit {
            putFloat("last_lat", location.latitude.toFloat())
            putFloat("last_lng", location.longitude.toFloat())
        }

        lifecycleScope.launch {
            val cityLabel = withContext(Dispatchers.IO) {
                resolveLocationLabel(location)
            }
            val label = cityLabel ?: String.format(Locale.getDefault(), "%.4f, %.4f", location.latitude, location.longitude)
            prefs.edit {
                putString("last_location_text", label)
            }
            locationTextState.value = label
        }
    }

    private fun resolveLocationLabel(location: Location): String? {
        return try {
            val geocoder = Geocoder(this, Locale.getDefault())
            val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
            if (!addresses.isNullOrEmpty()) {
                val address = addresses.first()
                val parts = listOfNotNull(address.locality, address.subLocality, address.adminArea)
                    .filter { it.isNotBlank() }
                if (parts.isNotEmpty()) parts.joinToString(", ") else address.countryName
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun startSOS() {
        val intent = Intent(this, com.example.ridealertz.service.CrashAlertActivity::class.java)
        startActivity(intent)
    }

    private fun startSettings() {
        val intent = Intent(this, SettingsActivity::class.java)
        startActivity(intent)
    }

    private fun startContacts() {
        val intent = Intent(this, com.example.ridealertz.service.EmergencyContactsActivity::class.java)
        startActivity(intent)
    }

    private fun startProfile() {
        startActivity(Intent(this, ProfileDetailsActivity::class.java))
    }

    private fun startVehicleSetup() {
        startActivity(Intent(this, VehicleDetailsActivity::class.java))
    }

    private fun logout() {
        prefs.edit {
            putBoolean("is_logged_in", false)
            remove("user_name")
            remove("user_email")
            remove("user_phone")
        }
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
    
    private fun startDrivingMode() {
        val intent = Intent(this, DrivingModeActivity::class.java)
        startActivity(intent)
    }
    
    private fun viewSafetyScore() {
        val intent = Intent(this, SafeDrivingScoreActivity::class.java)
        startActivity(intent)
    }
    
    private fun startRide() {
        // Start sensor monitoring
        val sensorIntent = Intent(this, SensorMonitoringService::class.java)
        startService(sensorIntent)
        
        // NOTE: SpeedMonitoringService disabled (class not present) to avoid compile errors
        // If you add a SpeedMonitoringService later, start it here.
        
        prefs.edit().putBoolean("ride_active", true).apply()

        // Quick user feedback
        Toast.makeText(this, "Sensor monitoring started", Toast.LENGTH_SHORT).show()

        
    }
    
    private fun stopRide() {
        // Stop sensor monitoring
        val sensorIntent = Intent(this, SensorMonitoringService::class.java)
        stopService(sensorIntent)
        
        // NOTE: SpeedMonitoringService disabled (class not present).
        
        prefs.edit().putBoolean("ride_active", false).apply()

        // Quick user feedback
        Toast.makeText(this, "Sensor monitoring stopped", Toast.LENGTH_SHORT).show()

        
    }
    
    private fun viewAccidentLog() {
        val intent = Intent(this, AccidentLogActivity::class.java)
        startActivity(intent)
    }
    
    private fun openHospitalFinder() {
        val intent = Intent(this, HospitalFinderActivity::class.java)
        startActivity(intent)
    }
    
    private fun openTravelHistory() {
        val intent = Intent(this, TravelHistoryActivity::class.java)
        startActivity(intent)
    }
    
    private fun openDatabaseTest() {
        // DatabaseTestActivity not available; function kept as no-op to avoid crashes.
        // You can implement and start the activity here later.
    }
}

@Composable
fun LocationPermissionPrompt(onDismiss: () -> Unit, onAccept: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.6f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .padding(32.dp)
                .fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1F1F1F))
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = Color(0xFFFF6B6B),
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Enable Location Accuracy",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Text(
                    text = "To continue, RideAlertz needs precise device location."
                            + "\n\nPlease turn on:\n• Device location\n• Google Location Accuracy",
                    color = Color(0xFFCBD5F5),
                    fontSize = 14.sp
                )

                Text(
                    text = "Google may use sensor and wireless data to improve accuracy."
                            + " You can change this anytime in Settings > Location > Location Accuracy.",
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("No, thanks", color = Color(0xFF9CA3AF))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onAccept,
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
                    ) {
                        Text("Turn on", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartDashboardScreen(
    context: Context,
    userName: String,
    batteryLevel: Int,
    currentLocationText: String,
    onRequestLocationRefresh: () -> Unit,
    onSOS: () -> Unit,
    onSettings: () -> Unit,
    onStartRide: () -> Unit,
    onStopRide: () -> Unit,
    onStartDriving: () -> Unit,
    onViewScore: () -> Unit,
    onHospitalFinder: () -> Unit,
    onTravelHistory: () -> Unit,
    onAccidentLog: () -> Unit,
    onDatabaseTest: () -> Unit,
    onEditProfile: () -> Unit,
    onEditVehicle: () -> Unit,
    onProfileRefreshRequested: () -> Unit,
    weatherState: WeatherUiState,
    onWeatherRefresh: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(2) }
    var isRideActive by remember { 
        mutableStateOf(context.getSharedPreferences("ridealertz", Context.MODE_PRIVATE)
            .getBoolean("ride_active", false)) 
    }
    
    Scaffold(
        containerColor = Color(0xFF1A1A1A), // Dark background
        bottomBar = {
            BottomNavigationBar(
                selectedTab = selectedTab,
                onTabSelected = { selectedTab = it },
                onSettings = onSettings
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (selectedTab) {
                0 -> ProfileTab(context, onEditProfile, onEditVehicle, onProfileRefreshRequested)
                1 -> FriendsTab(context)
                2 -> HomeTab(
                    context = context,
                    userName = userName,
                    batteryLevel = batteryLevel,
                    isRideActive = isRideActive,
                    currentLocationText = currentLocationText,
                    onRefreshLocation = onRequestLocationRefresh,
                    onStartRide = {
                        isRideActive = true
                        onStartRide()
                    },
                    onStopRide = {
                        isRideActive = false
                        onStopRide()
                    },
                    onSOS = onSOS,
                    onHospitalFinder = onHospitalFinder,
                    onTravelHistory = onTravelHistory,
                    onAccidentLog = onAccidentLog,
                    onViewScore = onViewScore,
                    onDatabaseTest = onDatabaseTest
                )
                3 -> WeatherTab(
                    weatherState = weatherState,
                    onRefresh = onWeatherRefresh,
                    currentLocationText = currentLocationText
                )
            }
        }
    }
}

@Composable
fun BottomNavigationBar(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit,
    onSettings: () -> Unit
) {
    NavigationBar(
        containerColor = Color(0xFF2A2A2A),
        contentColor = Color.White
    ) {
        NavigationBarItem(
            selected = selectedTab == 0,
            onClick = { onTabSelected(0) },
            icon = {
                NeonTabIcon(
                    selected = selectedTab == 0,
                    icon = Icons.Default.Person,
                    contentDescription = "Profile"
                )
            },
            label = {
                Text("Profile", color = if (selectedTab == 0) Color.White else Color.Gray, fontSize = 11.sp)
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color.White,
                indicatorColor = Color.Transparent,
                unselectedIconColor = Color.Gray,
                unselectedTextColor = Color.Gray
            )
        )
        
        NavigationBarItem(
            selected = selectedTab == 1,
            onClick = { onTabSelected(1) },
            icon = {
                NeonTabIcon(
                    selected = selectedTab == 1,
                    icon = Icons.Default.Group,
                    contentDescription = "Friends"
                )
            },
            label = {
                Text("Friends", color = if (selectedTab == 1) Color.White else Color.Gray, fontSize = 11.sp)
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color.White,
                indicatorColor = Color.Transparent,
                unselectedIconColor = Color.Gray,
                unselectedTextColor = Color.Gray
            )
        )
        
        NavigationBarItem(
            selected = selectedTab == 2,
            onClick = { onTabSelected(2) },
            icon = {
                NeonTabIcon(
                    selected = selectedTab == 2,
                    icon = Icons.Default.DirectionsBike,
                    contentDescription = "Ride"
                )
            },
            label = {
                Text("Ride", color = if (selectedTab == 2) Color.White else Color.Gray, fontSize = 11.sp)
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color.White,
                indicatorColor = Color.Transparent,
                unselectedIconColor = Color.Gray,
                unselectedTextColor = Color.Gray
            )
        )

        NavigationBarItem(
            selected = selectedTab == 3,
            onClick = { onTabSelected(3) },
            icon = {
                NeonTabIcon(
                    selected = selectedTab == 3,
                    icon = Icons.Default.WbSunny,
                    contentDescription = "Weather"
                )
            },
            label = {
                Text("Weather", color = if (selectedTab == 3) Color.White else Color.Gray, fontSize = 11.sp)
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color.White,
                indicatorColor = Color.Transparent,
                unselectedIconColor = Color.Gray,
                unselectedTextColor = Color.Gray
            )
        )
        
        NavigationBarItem(
            selected = false,
            onClick = { onSettings() },
            icon = {
                NeonTabIcon(
                    selected = false,
                    icon = Icons.Default.Settings,
                    contentDescription = "Settings",
                    unselectedTint = Color.Gray
                )
            },
            label = {
                Text("Settings", color = Color.Gray, fontSize = 11.sp)
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color.White,
                indicatorColor = Color.Transparent,
                unselectedIconColor = Color.Gray,
                unselectedTextColor = Color.Gray
            )
        )
    }
}

@Composable
fun WeatherTab(
    weatherState: WeatherUiState,
    onRefresh: () -> Unit,
    currentLocationText: String
) {
    val gradient = Brush.verticalGradient(
        listOf(Color(0xFF1A0A00), Color(0xFF050100))
    )
    val cardBackground = Color(0xFF1C1008)
    val accentGlow = Color(0xFFFF8A00)

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(gradient)
            .verticalScroll(scrollState)
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Ride Weather", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = currentLocationText,
                    color = Color(0xFF9CA3AF),
                    fontSize = 13.sp
                )
            }
            IconButton(onClick = onRefresh) {
                Icon(
                    imageVector = Icons.Outlined.Refresh,
                    contentDescription = "Refresh weather",
                    tint = accentGlow
                )
            }
        }

        when {
            weatherState.isLoading -> {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = Color.White)
                }
            }
            weatherState.data == null -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF262A3F)),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(
                        Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = weatherState.error ?: "Weather unavailable",
                            color = Color.White,
                            fontSize = 16.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Pull to refresh once GPS + internet are ready.",
                            color = Color(0xFF9CA3AF),
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
            else -> {
                WeatherCurrentConditionsCard(weatherState.data, cardBackground)
                WeatherSafetyCard(weatherState.data, cardBackground)
                WeatherHourlyRow(weatherState.hourly, cardBackground, accentGlow)
                WeatherDailyList(weatherState.daily, cardBackground)
            }
        }
    }
}

@Composable
private fun WeatherCurrentConditionsCard(data: WeatherData, cardColor: Color) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "${data.temperature.toInt()}°C",
                color = Color.White,
                fontSize = 42.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                text = data.description.replaceFirstChar { it.uppercase() },
                color = Color(0xFFB5C2FF),
                fontSize = 18.sp
            )
            Divider(color = Color.White.copy(alpha = 0.1f))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                WeatherInfoColumn("Feels like", "${data.feelsLike.toInt()}°C")
                WeatherInfoColumn("Humidity", "${data.humidity}%")
                WeatherInfoColumn("Wind", "${String.format("%.1f", data.windSpeed)} m/s")
            }
        }
    }
}

@Composable
private fun WeatherInfoColumn(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(label, color = Color(0xFF9CA3AF), fontSize = 12.sp)
    }
}

@Composable
private fun WeatherSafetyCard(data: WeatherData, cardColor: Color) {
    val color = when {
        data.drivingSafetyScore >= 80 -> Color(0xFF10B981)
        data.drivingSafetyScore >= 60 -> Color(0xFFF59E0B)
        data.drivingSafetyScore >= 40 -> Color(0xFFF97316)
        else -> Color(0xFFEF4444)
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Driving Safety", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
            LinearProgressIndicator(
                progress = data.drivingSafetyScore / 100f,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp)),
                color = color,
                trackColor = Color.White.copy(alpha = 0.1f)
            )
            Text(
                text = "${data.drivingSafetyScore}/100 score",
                color = color,
                fontWeight = FontWeight.Bold
            )
            if (data.recommendations.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    data.recommendations.take(3).forEach { rec ->
                        Text("• $rec", color = Color(0xFFCFD8FF), fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun WeatherHourlyRow(hourly: List<HourlyForecast>, cardColor: Color, accentGlow: Color) {
    Text("Next hours", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
    if (hourly.isEmpty()) {
        Text("No hourly data available", color = Color(0xFF9CA3AF), fontSize = 12.sp)
        return
    }
    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(hourly.take(12)) { forecast ->
            Card(
                colors = CardDefaults.cardColors(containerColor = cardColor),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = SimpleDateFormat("ha", Locale.getDefault()).format(Date(forecast.time)),
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "${forecast.temperature.toInt()}°",
                        color = accentGlow,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = forecast.condition,
                        color = Color(0xFF9CA3AF),
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun WeatherDailyList(daily: List<DailyForecast>, cardColor: Color) {
    Text("Upcoming days", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
    if (daily.isEmpty()) {
        Text("No daily forecast available", color = Color(0xFF9CA3AF), fontSize = 12.sp)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        daily.take(5).forEach { day ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = cardColor),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date(day.date)),
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = day.description,
                            color = Color(0xFF9CA3AF),
                            fontSize = 12.sp
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${day.highTemp.toInt()}° / ${day.lowTemp.toInt()}°",
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Wind ${String.format("%.1f", day.windSpeed)} m/s",
                            color = Color(0xFF9CA3AF),
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileTab(
    context: Context,
    onEditProfile: () -> Unit,
    onEditVehicle: () -> Unit,
    onRefreshRequested: () -> Unit
) {
    val activeOrange = Color(0xFFFF8A00)
    val inactiveDark = Color(0xFF2A2A2A)
    val accentYellow = Color(0xFFFFC266)
    val midnight = Brush.verticalGradient(listOf(Color(0xFF120600), Color(0xFF050200)))
    val cardColor = Color(0xFF1A120A)

    val prefs = remember(context) { context.getSharedPreferences("ridealertz", Context.MODE_PRIVATE) }

    val fullName = remember { mutableStateOf("") }
    val phone = remember { mutableStateOf("") }
    val email = remember { mutableStateOf("") }
    val bloodGroup = remember { mutableStateOf("") }
    val address = remember { mutableStateOf("") }
    val city = remember { mutableStateOf("") }
    val stateText = remember { mutableStateOf("") }
    val postalCode = remember { mutableStateOf("") }
    val emergencyName = remember { mutableStateOf("") }
    val emergencyPhone = remember { mutableStateOf("") }
    var emergencyContacts by remember { mutableStateOf(emptyList<SimpleEmergencyContact>()) }

    val vehicleType = remember { mutableStateOf("Bike") }
    val vehicleName = remember { mutableStateOf("-") }
    val vehicleNumber = remember { mutableStateOf("-") }
    val vehicleColor = remember { mutableStateOf("-") }

    fun loadFromPrefs() {
        fullName.value = prefs.getString("first_name", "") ?: ""
        phone.value = prefs.getString("user_phone", "") ?: ""
        email.value = prefs.getString("user_email", "") ?: ""
        bloodGroup.value = prefs.getString("bloodGroup", "") ?: ""
        address.value = prefs.getString("address", "") ?: ""
        city.value = prefs.getString("city", "") ?: ""
        stateText.value = prefs.getString("state", "") ?: ""
        postalCode.value = prefs.getString("postalCode", "") ?: ""
        emergencyName.value = prefs.getString("emgName", "") ?: ""
        emergencyPhone.value = prefs.getString("emgPhone", "") ?: ""
        emergencyContacts = loadContactsFromPrefs(prefs)
        vehicleType.value = prefs.getString("vehicle_type", "Bike") ?: "Bike"
        vehicleName.value = prefs.getString("vehicle_name", "-") ?: "-"
        vehicleNumber.value = prefs.getString("vehicle_number", "-") ?: "-"
        vehicleColor.value = prefs.getString("vehicle_color", "-") ?: "-"
    }

    LaunchedEffect(Unit) {
        loadFromPrefs()
        onRefreshRequested()
    }

    var selectedSection by remember { mutableStateOf("profile") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(midnight)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 20.dp)
    ) {
        Text(
            text = "My Details",
            color = Color.White,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "View the information saved in your profile & vehicle setup.",
            color = Color(0xFF9CA3AF),
            fontSize = 13.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onEditProfile,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = accentYellow),
                border = BorderStroke(1.dp, accentYellow.copy(alpha = 0.6f))
            ) {
                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Edit Profile")
            }
            Button(
                onClick = onEditVehicle,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = activeOrange, contentColor = Color.White)
            ) {
                Icon(Icons.Default.DirectionsBike, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Edit Vehicle")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { selectedSection = "profile" },
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp),
                shape = RoundedCornerShape(22.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedSection == "profile") activeOrange else inactiveDark,
                    contentColor = if (selectedSection == "profile") Color.White else Color(0xFFE5E5E5)
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Profile")
            }

            Button(
                onClick = { selectedSection = "vehicle" },
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp),
                shape = RoundedCornerShape(22.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedSection == "vehicle") activeOrange else inactiveDark,
                    contentColor = if (selectedSection == "vehicle") Color.White else Color(0xFFE5E5E5)
                )
            ) {
                Icon(
                    imageVector = Icons.Default.DirectionsBike,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Vehicle")
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (selectedSection == "profile") {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = cardColor),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Profile Details",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp
                    )

                    ProfileDetailRow(label = "Name", value = fullName.value.ifBlank { "Not set" })
                    ProfileDetailRow(label = "Phone", value = phone.value.ifBlank { "Not set" })
                    ProfileDetailRow(label = "Email", value = email.value.ifBlank { "Not set" })
                    ProfileDetailRow(label = "Blood Group", value = bloodGroup.value.ifBlank { "Not set" })

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Address",
                        color = Color(0xFFE5E7EB),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    val addressLines = buildList {
                        if (address.value.isNotBlank()) add(address.value)
                        val cityState = listOf(city.value, stateText.value)
                            .filter { it.isNotBlank() }
                            .joinToString(", ")
                        if (cityState.isNotBlank()) add(cityState)
                        if (postalCode.value.isNotBlank()) add(postalCode.value)
                    }
                    Text(
                        text = if (addressLines.isEmpty()) "Not set" else addressLines.joinToString("\n"),
                        color = Color(0xFF9CA3AF),
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Emergency Contact",
                        color = Color(0xFFE5E7EB),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    val primaryEmergency = emergencyContacts.firstOrNull { it.isPrimary } ?: emergencyContacts.firstOrNull()
                    if (primaryEmergency != null) {
                        ProfileDetailRow(label = "Primary Name", value = primaryEmergency.name)
                        ProfileDetailRow(label = "Primary Phone", value = primaryEmergency.phone)
                        if (!primaryEmergency.isPrimary) {
                            Text(
                                text = "Marked automatically as primary until you choose one in Emergency Contacts.",
                                color = Color(0xFF9CA3AF),
                                fontSize = 12.sp
                            )
                        }
                        if (emergencyContacts.size > 1) {
                            Text(
                                text = "${emergencyContacts.size - 1} additional contact${if (emergencyContacts.size > 2) "s" else ""} saved.",
                                color = Color(0xFF9CA3AF),
                                fontSize = 12.sp
                            )
                        }
                    } else if (emergencyName.value.isNotBlank() && emergencyPhone.value.isNotBlank()) {
                        ProfileDetailRow(label = "Primary Name", value = emergencyName.value)
                        ProfileDetailRow(label = "Primary Phone", value = emergencyPhone.value)
                    } else {
                        Text(
                            text = "No emergency contacts set. Add one to send crash/SOS alerts automatically.",
                            color = Color(0xFF9CA3AF),
                            fontSize = 12.sp
                        )
                    }

                    val secondaryContacts = emergencyContacts
                        .filter { it != primaryEmergency }
                        .take(2)
                    if (secondaryContacts.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Secondary Contacts",
                            color = Color(0xFFE5E7EB),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        secondaryContacts.forEachIndexed { index, contact ->
                            ProfileDetailRow(
                                label = "Contact ${index + 1}",
                                value = "${contact.name} • ${contact.phone}"
                            )
                        }
                    }

                    Button(
                        onClick = {
                            val intent = Intent(
                                context,
                                com.example.ridealertz.service.EmergencyContactsActivity::class.java
                            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            try {
                                context.startActivity(intent)
                            } catch (_: Exception) {
                                Toast.makeText(context, "Unable to open Emergency Contacts", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = activeOrange)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add / Manage Emergency Contacts", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = cardColor),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Vehicle Details",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp
                    )

                    ProfileDetailRow(label = "Vehicle Name", value = vehicleName.value.ifBlank { "Not set" })
                    ProfileDetailRow(label = "Vehicle Type", value = vehicleType.value.ifBlank { "Not set" })
                    ProfileDetailRow(label = "Number Plate", value = vehicleNumber.value.ifBlank { "Not set" })
                    ProfileDetailRow(label = "Color", value = vehicleColor.value.ifBlank { "Not set" })

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "These values come from your Vehicle setup screen.",
                        color = Color(0xFF9CA3AF),
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun ProfileDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = Color(0xFF9CA3AF),
            fontSize = 13.sp
        )
        Text(
            text = value,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f, fill = false),
            textAlign = TextAlign.End
        )
    }
}

@Composable
private fun SettingsSwitchRow(title: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = title, color = Color.White)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun DropdownMenuBox(
    options: List<String>,
    selected: String,
    onSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        OutlinedButton(onClick = { expanded = true }) {
            Text(selected)
            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onSelected(option)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun HomeTab(
    context: Context,
    userName: String,
    batteryLevel: Int,
    isRideActive: Boolean,
    currentLocationText: String,
    onRefreshLocation: () -> Unit,
    onStartRide: () -> Unit,
    onStopRide: () -> Unit,
    onSOS: () -> Unit,
    onHospitalFinder: () -> Unit,
    onTravelHistory: () -> Unit,
    onAccidentLog: () -> Unit,
    onViewScore: () -> Unit = {},
    onDatabaseTest: () -> Unit = {}
) {
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    val activeOrange = Color(0xFFFF8A00)
    val inactiveDark = Color(0xFF2A2A2A)
    val accentYellow = Color(0xFFFFC266)
    val surfaceTint = Color.White.copy(alpha = 0.06f)
    val pulse = rememberInfiniteTransition(label = "ridePulse").animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAnim"
    ).value

    val gradientBackground = Brush.verticalGradient(NeonOrangeGradientColors.map { it.copy(alpha = 0.15f) })

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(gradientBackground)
            .padding(horizontal = 18.dp, vertical = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = " RideAlertz",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 13.sp
                    )
                    Text(
                        text = "Hello, $userName",
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                StatusPill(
                    title = if (isRideActive) "Ride active" else "Standby",
                    value = "$batteryLevel%",
                    valueLabel = "Battery",
                    accent = if (isRideActive) accentYellow else activeOrange
                )
            }

            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                border = Brush.linearGradient(listOf(surfaceTint, activeOrange.copy(alpha = 0.6f)))
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Current location",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 12.sp
                    )
                    Text(
                        text = currentLocationText.ifBlank { "Locating…" },
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium
                    )
                    GradientActionButton(
                        text = "Refresh location",
                        leadingIcon = Icons.Default.MyLocation,
                        modifier = Modifier.align(Alignment.End),
                        gradient = Brush.horizontalGradient(listOf(activeOrange, accentYellow))
                    ) { onRefreshLocation() }
                }
            }

            val categories = listOf(
                "Food" to Icons.Default.Restaurant,
                "Fuel" to Icons.Default.LocalGasStation,
                "Hospitals" to Icons.Default.LocalHospital,
                "ATMs" to Icons.Default.AccountBalance
            )
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(categories) { (label, icon) ->
                    NeonChip(
                        text = label,
                        icon = icon,
                        selected = selectedCategory == label,
                        onClick = {
                            selectedCategory = if (selectedCategory == label) null else label
                        }
                    )
                }
            }

            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(520.dp),
                shape = RoundedCornerShape(34.dp),
                border = Brush.linearGradient(
                    listOf(Color.White.copy(alpha = 0.08f), activeOrange.copy(alpha = 0.5f))
                ),
                contentPadding = PaddingValues(0.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    RideMapView(
                        modifier = Modifier
                            .matchParentSize()
                            .clip(RoundedCornerShape(24.dp)),
                        selectedCategory = selectedCategory
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(20.dp)
                    ) {
                        Text(
                            text = selectedCategory?.let { "Showing nearby $it" } ?: "Map radar online",
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Tap chips above to filter POIs",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 12.sp
                        )
                    }
                }
            }

            GradientActionButton(
                text = "SOS",
                leadingIcon = Icons.Default.Warning,
                gradient = Brush.horizontalGradient(listOf(Color(0xFFFF5F6D), Color(0xFFFF1843))),
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(18.dp, RoundedCornerShape(28.dp)),
                glow = true
            ) { onSOS() }

            GradientActionButton(
                text = if (isRideActive) "End Ride" else "Start Ride",
                leadingIcon = if (isRideActive) Icons.Default.Stop else Icons.Default.PlayArrow,
                gradient = if (isRideActive) {
                    Brush.horizontalGradient(listOf(Color(0xFFFF5A36), Color(0xFFFFB347)))
                } else {
                    Brush.horizontalGradient(listOf(activeOrange, accentYellow))
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isRideActive) onStopRide() else onStartRide()
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(
                            if (isRideActive) accentYellow.copy(alpha = pulse)
                            else activeOrange.copy(alpha = pulse * 0.9f)
                        )
                )
                Text(
                    text = if (isRideActive) "Sensors monitoring active…" else "Ride monitoring paused",
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 15.sp
                )
            }

            GradientActionButton(
                text = "View Accidents",
                leadingIcon = Icons.Default.List,
                gradient = Brush.horizontalGradient(listOf(Color(0xFFFFB347), Color(0xFFFFCC33))),
                modifier = Modifier.fillMaxWidth()
            ) { onAccidentLog() }
        }
    }
}

@Composable
private fun StatusPill(
    title: String,
    value: String,
    valueLabel: String,
    accent: Color
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .border(
                BorderStroke(1.dp, accent.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(18.dp)
            )
            .background(Color.White.copy(alpha = 0.05f))
            .padding(horizontal = 18.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = title, color = accent, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        Text(text = value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(text = valueLabel, color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
    }
}

@Composable
private fun GlassCard(
    modifier: Modifier = Modifier,
    shape: RoundedCornerShape = RoundedCornerShape(24.dp),
    border: Brush? = null,
    contentPadding: PaddingValues = PaddingValues(18.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier,
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.02f)),
        border = border?.let { BorderStroke(1.dp, it) }
    ) {
        Column(
            modifier = Modifier.padding(contentPadding),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            content = content
        )
    }
}

@Composable
private fun NeonChip(
    text: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    val background = if (selected) {
        Brush.horizontalGradient(listOf(Color(0xFFFF8C42), Color(0xFFFFC857)))
    } else {
        Brush.horizontalGradient(listOf(Color(0xFF1B0F07), Color(0xFF100703)))
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(24.dp))
            .background(background)
            .border(
                BorderStroke(
                    1.dp,
                    if (selected) Color.White.copy(alpha = 0.4f) else Color.White.copy(alpha = 0.12f)
                ),
                RoundedCornerShape(24.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
            Text(text = text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun GradientActionButton(
    text: String,
    leadingIcon: ImageVector?,
    gradient: Brush,
    modifier: Modifier = Modifier,
    glow: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(28.dp))
            .background(gradient)
            .neonGlow(glow)
            .clickable(onClick = onClick)
            .padding(vertical = 16.dp, horizontal = 20.dp)
    ) {
        Row(
            modifier = Modifier.align(Alignment.Center),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (leadingIcon != null) {
                Icon(
                    imageVector = leadingIcon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(text = text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

data class SimpleEmergencyContact(
    val name: String = "",
    val phone: String = "",
    val isPrimary: Boolean = false
)

private fun Modifier.neonGlow(enabled: Boolean, cornerRadius: Dp = 28.dp): Modifier =
    if (!enabled) this else drawBehind {
        val radiusPx = cornerRadius.value * density
        drawRoundRect(
            color = NeonGlowColor,
            cornerRadius = CornerRadius(radiusPx, radiusPx)
        )
    }

@Composable
private fun NeonTabIcon(
    selected: Boolean,
    icon: ImageVector,
    contentDescription: String,
    unselectedTint: Color = Color.Gray
) {
    val tint = if (selected) Color.White else unselectedTint
    val modifier = if (selected) {
        Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(Brush.radialGradient(colors = NeonOrangeGradientColors, radius = 80f))
            .neonGlow(true, cornerRadius = 20.dp)
            .padding(8.dp)
    } else {
        Modifier.size(24.dp)
    }
    Icon(icon, contentDescription = contentDescription, tint = tint, modifier = modifier)
}

private fun loadContactsFromPrefs(prefs: SharedPreferences): List<SimpleEmergencyContact> {
    val json = prefs.getString("emergency_contacts", "[]")
    return try {
        val type = object : TypeToken<List<SimpleEmergencyContact>>() {}.type
        Gson().fromJson<List<SimpleEmergencyContact>>(json, type) ?: emptyList()
    } catch (_: Exception) {
        emptyList()
    }
}

private fun resolveUserId(prefs: SharedPreferences): String? {
    return prefs.getString("user_uid", null)
        ?: prefs.getString("user_email", null)?.replace("@", "_")
        ?: prefs.getString("user_phone", null)
}

private fun mapRemoteEmergencyContact(raw: Map<String, Any?>): SimpleEmergencyContact? {
    val name = (raw["name"] as? String)?.trim()?.takeIf { it.isNotEmpty() } ?: return null
    val phone = (raw["phone"] as? String)?.trim()?.takeIf { it.isNotEmpty() } ?: return null
    val isPrimary = when (val value = raw["isPrimary"]) {
        is Boolean -> value
        is Number -> value.toInt() != 0
        is String -> value.equals("true", true) || value == "1"
        else -> false
    }
    return SimpleEmergencyContact(name = name, phone = phone, isPrimary = isPrimary)
}

private fun dedupeSimpleContacts(list: List<SimpleEmergencyContact>): List<SimpleEmergencyContact> {
    val seen = linkedMapOf<String, SimpleEmergencyContact>()
    var primaryAssigned = false
    list.forEach { contact ->
        val key = contact.phone.filter { it.isDigit() }.let { if (it.length > 10) it.takeLast(10) else it }
        val normalized = if (!primaryAssigned && contact.isPrimary) {
            primaryAssigned = true
            contact.copy(isPrimary = true)
        } else {
            contact.copy(isPrimary = false)
        }
        if (!seen.containsKey(key)) {
            seen[key] = normalized
        } else if (!seen[key]!!.isPrimary && normalized.isPrimary && primaryAssigned) {
            seen[key] = normalized
        }
    }
    if (!primaryAssigned && seen.isNotEmpty()) {
        val firstKey = seen.keys.first()
        seen[firstKey] = seen[firstKey]!!.copy(isPrimary = true)
    }
    return seen.values.toList()
}

@Composable
fun FriendsTab(context: Context) {
    val prefs = remember(context) { context.getSharedPreferences("ridealertz", Context.MODE_PRIVATE) }
    var emergencyContacts by remember { mutableStateOf(loadContactsFromPrefs(prefs)) }
    val activeOrange = Color(0xFFFF8A00)
    val accentYellow = Color(0xFFFFC266)

    LaunchedEffect(Unit) {
        val userId = resolveUserId(prefs)
        if (!userId.isNullOrBlank()) {
            try {
                val remote = FirebaseHelper.readEmergencyContacts(userId)
                if (remote.isNotEmpty()) {
                    val mapped = remote.mapNotNull { mapRemoteEmergencyContact(it) }
                    if (mapped.isNotEmpty()) {
                        emergencyContacts = dedupeSimpleContacts(mapped)
                        prefs.edit().putString("emergency_contacts", Gson().toJson(emergencyContacts)).apply()
                    }
                }
            } catch (_: Exception) { }
        }
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF120500), Color(0xFF080200)))),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Header
            Column(horizontalAlignment = Alignment.Start) {
                Text(
                    text = "Emergency Network",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Friends & family who get alerts when something goes wrong.",
                    color = Color(0xFF9CA3AF),
                    fontSize = 13.sp
                )
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B0C04)),
                shape = RoundedCornerShape(18.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.Start,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(activeOrange.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Group,
                                contentDescription = null,
                                tint = accentYellow
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Emergency contacts",
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "People who receive your crash & SOS alerts.",
                                color = Color(0xFF9CA3AF),
                                fontSize = 12.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Add at least one trusted contact so we can notify them with your live location during emergencies.",
                        color = Color(0xFFFFF3D4),
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (emergencyContacts.isEmpty()) {
                Text(
                    text = "No emergency contacts added yet.",
                    color = Color(0xFF9CA3AF),
                    fontSize = 13.sp
                )
            } else {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Saved contacts (${emergencyContacts.size})",
                        color = Color(0xFFE5E7EB),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    emergencyContacts.forEach { contact ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1B0C04)),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.04f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(contact.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                    Text(contact.phone, color = Color(0xFF9CA3AF), fontSize = 12.sp)
                                }
                                if (contact.isPrimary) {
                                    Text(
                                        text = "PRIMARY",
                                        color = accentYellow,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Button(
                onClick = {
                    val intent = Intent(
                        context,
                        com.example.ridealertz.service.EmergencyContactsActivity::class.java
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        context.startActivity(intent)
                    } catch (_: Exception) {
                        Toast.makeText(context, "Unable to open Emergency Contacts", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(26.dp),
                colors = ButtonDefaults.buttonColors(containerColor = activeOrange)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    tint = Color.White
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Add / Manage Emergency Contacts", color = Color.White, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = {
                    val intent = Intent(
                        context,
                        com.example.ridealertz.service.EmergencyContactsActivity::class.java
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        context.startActivity(intent)
                    } catch (_: Exception) {
                        Toast.makeText(context, "Unable to open Emergency Contacts", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(24.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = accentYellow),
                border = BorderStroke(1.dp, accentYellow.copy(alpha = 0.5f))
            ) {
                Text("Set Primary Contact", color = accentYellow)
            }
        }
    }
}

@Composable
fun SavedTab() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1A1A1A)),
        contentAlignment = Alignment.Center
    ) {
        Text("Saved (coming soon)", color = Color.White)
    }
}

@Composable
fun QuickActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(100.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = color.copy(alpha = 0.15f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = color,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = label,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
        }
    }
}

@Composable
fun VehicleSpeedCard(
    vehicleType: String,
    vehicleName: String,
    speed: Float,
    location: String,
    isRideActive: Boolean
) {
    val speedLimit = if (vehicleType == "Bike") 90f else 120f
    val isOverspeed = speed > speedLimit
    
    val infiniteTransition = rememberInfiniteTransition(label = "overspeed")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isOverspeed) 0.3f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(500),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isOverspeed) 
                Color(0xFFEF4444).copy(alpha = 0.2f) 
            else Color(0xFF2A2A2A)
        ),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "-------------------------",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Vehicle Type
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Vehicle:",
                    fontSize = 16.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "$vehicleType ($vehicleName)",
                    fontSize = 18.sp,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Speed Display
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Speed:",
                    fontSize = 16.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = String.format(Locale.getDefault(), "%.1f km/h", speed),
                    fontSize = 32.sp,
                    color = if (isOverspeed) Color(0xFFEF4444).copy(alpha = alpha) else Color(0xFF10B981),
                    fontWeight = FontWeight.ExtraBold
                )
                
                if (isOverspeed) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "⚠️",
                        fontSize = 24.sp
                    )
                }
            }
            
            if (isOverspeed) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Overspeed Alert",
                    fontSize = 14.sp,
                    color = Color(0xFFEF4444),
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Speed limit: $speedLimit km/h",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Location
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Location:",
                    fontSize = 16.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = location,
                    fontSize = 16.sp,
                    color = Color.White
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Status
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Status:",
                    fontSize = 16.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isRideActive) {
                        "Monitoring Active ✅"
                    } else if (isOverspeed) {
                        "Overspeed Detected ⚠️"
                    } else {
                        "Safe Driving 😊"
                    },
                    fontSize = 16.sp,
                    color = if (isRideActive) Color(0xFF10B981) 
                           else if (isOverspeed) Color(0xFFEF4444)
                           else Color(0xFF6366F1),
                    fontWeight = FontWeight.Bold
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Text(
                text = "-------------------------",
                color = Color.Gray,
                fontSize = 12.sp
            )
        }
    }
}

 

fun getLocationName(latitude: Double, longitude: Double): String {
    // Simple location name based on coordinates
    // In production, use Geocoder or Google Places API
    return when {
        latitude in 10.0..11.0 && longitude in 76.0..77.0 -> "Coimbatore Area"
        latitude in 11.0..12.0 && longitude in 77.0..78.0 -> "Bangalore Area"
        latitude in 13.0..14.0 && longitude in 80.0..81.0 -> "Chennai Area"
        latitude in 10.0..11.0 && longitude in 78.0..79.0 -> "Trichy Main Road"
        else -> "On the road"
    }
}

@Composable
fun EmergencyButton(onSOS: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )
    
    Box(
        modifier = Modifier
            .size(200.dp * scale)
            .clip(CircleShape)
            .background(Color(0xFFFFB3BA))
            .clickable(onClick = onSOS),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.MedicalServices,
                contentDescription = "Emergency",
                tint = Color.White,
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Press & Hold",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@Composable
fun MapTab(context: Context) {
    var currentLocation by remember { mutableStateOf<Location?>(null) }

    LaunchedEffect(Unit) {
        try {
            val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
            fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                location?.let {
                    currentLocation = it
                }
            }
        } catch (e: SecurityException) {
            // Handle permission error
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Simple placeholder instead of OSM map
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF111827)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Map view disabled",
                color = Color(0xFF9CA3AF),
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Surface(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(16.dp),
            color = Color.Black.copy(alpha = 0.7f),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(
                text = "🧭 Live Location Tracking",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
            )
        }
    }
}

@Composable
fun HealthTab() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1A1A1A))
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        Text(
            text = "Health Monitoring",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        
        Spacer(modifier = Modifier.height(32.dp))
        
        // Heart Rate Card
        HealthMetricCard(
            icon = "💓",
            title = "Heart Rate",
            value = "-- bpm",
            status = "Not Connected",
            color = Color(0xFFEF4444)
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // SpO2 Card
        HealthMetricCard(
            icon = "🫁",
            title = "Blood Oxygen (SpO₂)",
            value = "--%",
            status = "Not Connected",
            color = Color(0xFF6366F1)
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Steps Card
        HealthMetricCard(
            icon = "👟",
            title = "Steps Today",
            value = "0",
            status = "Not Connected",
            color = Color(0xFF10B981)
        )
        
        Spacer(modifier = Modifier.height(32.dp))
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF2A2A2A)
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Watch,
                    contentDescription = null,
                    tint = Color(0xFF6366F1),
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Connect Wearable Device",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Pair your smartwatch or fitness tracker to monitor health metrics in real-time",
                    fontSize = 13.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { /* TODO: Implement pairing */ },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF6366F1)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Connect Device")
                }
            }
        }
    }
}

@Composable
fun HealthMetricCard(
    icon: String,
    title: String,
    value: String,
    status: String,
    color: Color
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF2A2A2A)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = icon,
                fontSize = 40.sp
            )
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    color = Color.Gray
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = value,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = color
                )
                Text(
                    text = status,
                    fontSize = 11.sp,
                    color = Color.Gray,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
            }
        }
    }
}

@Composable
fun AlertsTab() {
    val context = LocalContext.current
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1A1A1A))
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        Text(
            text = "Alerts & Notifications",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Accident Log Button
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    val intent = Intent(context, AccidentLogActivity::class.java)
                    context.startActivity(intent)
                },
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFFEF4444).copy(alpha = 0.2f)
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "Accident Log",
                        tint = Color(0xFFEF4444),
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "Accident Log",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "View past incidents",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                }
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = Color.Gray
                )
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // No alerts message
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF2A2A2A)
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.NotificationsNone,
                    contentDescription = null,
                    tint = Color.Gray,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "No Alerts",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "You're all safe! No emergency alerts at the moment.",
                    fontSize = 14.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center
                )
            }
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Text(
            text = "Safety Tips",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        SafetyTipCard(
            icon = "💡",
            tip = "Maintain safe following distance"
        )
        
        Spacer(modifier = Modifier.height(12.dp))
        
        SafetyTipCard(
            icon = "🚦",
            tip = "Always obey traffic signals"
        )
        
        Spacer(modifier = Modifier.height(12.dp))
        
        SafetyTipCard(
            icon = "👀",
            tip = "Check mirrors regularly"
        )
        
        Spacer(modifier = Modifier.height(12.dp))
        
        SafetyTipCard(
            icon = "⚠️",
            tip = "Avoid distractions while driving"
        )
    }
}

@Composable
fun SafetyTipCard(icon: String, tip: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF2A2A2A)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = icon,
                fontSize = 24.sp
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = tip,
                fontSize = 14.sp,
                color = Color.White
            )
        }
    }
}

// Keep old components for backward compatibility
@Composable
fun DashboardHeader(
    userName: String,
    currentTime: String,
    isOnline: Boolean,
    batteryLevel: Int,
    onSettings: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        ),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // App Logo and Name
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        Color(0xFF6366F1),
                                        Color(0xFF8B5CF6)
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.DirectionsCar,
                            contentDescription = "Logo",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    
                    Spacer(modifier = Modifier.width(12.dp))
                    
                    Column {
                        Text(
                            text = "RideAlertz",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "Smart Safety System",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                        )
                    }
                }
                
                // Settings Icon
                IconButton(onClick = onSettings) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Status Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // User Info
                StatusChip(
                    icon = Icons.Default.Person,
                    text = userName,
                    color = Color(0xFF10B981)
                )
                
                // Time
                StatusChip(
                    icon = Icons.Default.AccessTime,
                    text = currentTime,
                    color = Color(0xFF6366F1)
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Connection Status
                StatusChip(
                    icon = if (isOnline) Icons.Default.Wifi else Icons.Default.WifiOff,
                    text = if (isOnline) "Online" else "Offline",
                    color = if (isOnline) Color(0xFF10B981) else Color(0xFFEF4444)
                )
                
                // Battery
                StatusChip(
                    icon = Icons.Default.BatteryFull,
                    text = "$batteryLevel%",
                    color = when {
                        batteryLevel > 50 -> Color(0xFF10B981)
                        batteryLevel > 20 -> Color(0xFFF59E0B)
                        else -> Color(0xFFEF4444)
                    }
                )
            }
        }
    }
}

@Composable
fun StatusChip(icon: ImageVector, text: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.15f),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = text,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = color
            )
        }
    }
}

@Composable
fun LocationCard(locationText: String, isOnline: Boolean) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF6366F1).copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.GpsFixed,
                    contentDescription = "GPS",
                    tint = Color(0xFF6366F1),
                    modifier = Modifier.size(24.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "🛰️ Live GPS Location",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = locationText,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            // GPS Signal Indicator
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(if (isOnline) Color(0xFF10B981) else Color(0xFFEF4444))
            )
        }
    }
}

@Composable
fun RideControlButton(
    isRideActive: Boolean,
    onStartRide: () -> Unit,
    onStopRide: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clickable { if (isRideActive) onStopRide() else onStartRide() },
        colors = CardDefaults.cardColors(
            containerColor = if (isRideActive) Color(0xFFEF4444) else Color(0xFF10B981)
        ),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isRideActive) {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = pulseAlpha))
                )
            } else {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(32.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(12.dp))
            
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (isRideActive) "🚗 Ride Active - Detection ON" else "🚗 Start Ride / Enable Detection",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
                if (isRideActive) {
                    Text(
                        text = "Tap to stop monitoring",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.9f),
                        textAlign = TextAlign.Center
                    )
                } else {
                    Text(
                        text = "Activates crash detection sensors",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.9f),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun HealthDataWidget() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = "Health",
                    tint = Color(0xFFEF4444),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "❤️ Health Data",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                HealthMetric(
                    icon = "💓",
                    label = "Heart Rate",
                    value = "-- bpm",
                    subtitle = "Not connected"
                )
                
                HealthMetric(
                    icon = "🫁",
                    label = "SpO₂",
                    value = "--%",
                    subtitle = "Not connected"
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "Connect a wearable device to monitor health metrics",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun HealthMetric(icon: String, label: String, value: String, subtitle: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(8.dp)
    ) {
        Text(
            text = icon,
            fontSize = 32.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = label,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = subtitle,
            fontSize = 9.sp,
            color = MaterialTheme.colorScheme.error,
            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
        )
    }
}

@Composable
fun BigSOSButton(onSOS: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "sos_pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clickable(onClick = onSOS),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFDC2626)
        ),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp * scale)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "SOS",
                        tint = Color.White,
                        modifier = Modifier.size(48.dp)
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "🆘 EMERGENCY SOS",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "Tap for immediate emergency assistance",
                    fontSize = 14.sp,
                    color = Color.White.copy(alpha = 0.9f),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun QuickActionsRow(
    onStartDriving: () -> Unit,
    onViewScore: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        QuickActionCard(
            modifier = Modifier.weight(1f),
            icon = Icons.Default.DirectionsCar,
            title = "Driving Mode",
            subtitle = "Hands-free",
            color = Color(0xFF6366F1),
            onClick = onStartDriving
        )
        
        QuickActionCard(
            modifier = Modifier.weight(1f),
            icon = Icons.Default.Star,
            title = "Safety Score",
            subtitle = "View stats",
            color = Color(0xFFF59E0B),
            onClick = onViewScore
        )
    }
}

@Composable
fun QuickActionCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    title: String,
    subtitle: String,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(100.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = color.copy(alpha = 0.15f)
        ),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = color,
                textAlign = TextAlign.Center
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = color.copy(alpha = 0.8f),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun NotificationPanel() {
    val tips = listOf(
        "💡 Maintain safe following distance",
        "🚦 Always obey traffic signals",
        "👀 Check mirrors regularly",
        "⚠️ Avoid distractions while driving",
        "🌙 Use headlights in low visibility",
        "🛑 Never drink and drive"
    )
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Notifications,
                    contentDescription = "Notifications",
                    tint = Color(0xFF6366F1),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "🔔 Safety Tips & Alerts",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(tips) { tip ->
                    TipChip(tip)
                }
            }
        }
    }
}

@Composable
fun TipChip(tip: String) {
    Surface(
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = RoundedCornerShape(20.dp)
    ) {
        Text(
            text = tip,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            color = MaterialTheme.colorScheme.onPrimaryContainer
        )
    }
}

fun isNetworkAvailable(context: Context): Boolean {
    val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } else {
        @Suppress("DEPRECATION")
        val networkInfo = connectivityManager.activeNetworkInfo
        @Suppress("DEPRECATION")
        return networkInfo?.isConnected == true
    }
}

fun getCurrentTime(): String {
    val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
    return sdf.format(Date())
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainMapScreen(
    userName: String,
    batteryLevel: Int,
    onCheckIn: () -> Unit,
    onSOS: () -> Unit,
    onSettings: () -> Unit,
    onContacts: () -> Unit,
    onProfile: () -> Unit,
    onLogout: () -> Unit,
    onStartDriving: () -> Unit = {},
    onViewScore: () -> Unit = {}
) {
    var selectedTab by remember { mutableStateOf(0) }
    var showProfileMenu by remember { mutableStateOf(false) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Group selector
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(
                                    Color(0xFFF3F4F6),
                                    shape = RoundedCornerShape(20.dp)
                                )
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = "G Family",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Select Group",
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        
                        // Right side icons
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Notifications
                            Box {
                                IconButton(onClick = { /* TODO: Notifications */ }) {
                                    Icon(
                                        imageVector = Icons.Default.Notifications,
                                        contentDescription = "Notifications",
                                        tint = Color(0xFF6366F1)
                                    )
                                }
                                // Notification badge
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .offset(x = 24.dp, y = 8.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFEF4444)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "21",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            
                            // Messages
                            IconButton(onClick = { /* TODO: Messages */ }) {
                                Icon(
                                    imageVector = Icons.Default.Message,
                                    contentDescription = "Messages",
                                    tint = Color(0xFF6366F1)
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White
                )
            )
        },
        bottomBar = {
            Column {
                // Check in and SOS buttons
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Check in button
                    Button(
                        onClick = onCheckIn,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFF3F4F6)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = Color(0xFF6366F1),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Check in",
                            color = Color(0xFF6366F1),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    
                    // SOS button
                    Button(
                        onClick = onSOS,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFF3F4F6)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SOS",
                            color = Color(0xFFEF4444),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
                
                // Bottom navigation tabs (Location, Driving, Safety)
                NavigationBar(
                    containerColor = Color.White,
                    tonalElevation = 0.dp
                ) {
                    NavigationBarItem(
                        icon = {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = "Location"
                            )
                        },
                        label = { Text("Location") },
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF6366F1),
                            selectedTextColor = Color(0xFF6366F1),
                            indicatorColor = Color(0xFFEDE9FE),
                            unselectedIconColor = Color(0xFF9CA3AF),
                            unselectedTextColor = Color(0xFF9CA3AF)
                        )
                    )
                    
                    NavigationBarItem(
                        icon = {
                            Icon(
                                imageVector = Icons.Default.DirectionsCar,
                                contentDescription = "Driving"
                            )
                        },
                        label = { Text("Driving") },
                        selected = selectedTab == 1,
                        onClick = { onStartDriving() },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF6366F1),
                            selectedTextColor = Color(0xFF6366F1),
                            indicatorColor = Color(0xFFEDE9FE),
                            unselectedIconColor = Color(0xFF9CA3AF),
                            unselectedTextColor = Color(0xFF9CA3AF)
                        )
                    )
                    
                    NavigationBarItem(
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = "Safety"
                            )
                        },
                        label = { Text("Safety") },
                        selected = selectedTab == 2,
                        onClick = { onViewScore() },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF6366F1),
                            selectedTextColor = Color(0xFF6366F1),
                            indicatorColor = Color(0xFFEDE9FE),
                            unselectedIconColor = Color(0xFF9CA3AF),
                            unselectedTextColor = Color(0xFF9CA3AF)
                        )
                    )
                }
                
                // User profile section at bottom
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xFFF9FAFB),
                    tonalElevation = 2.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Profile avatar
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF6366F1)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = userName.firstOrNull()?.uppercase() ?: "U",
                                    color = Color.White,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            
                            Spacer(modifier = Modifier.width(12.dp))
                            
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = userName,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        imageVector = Icons.Default.SignalCellularAlt,
                                        contentDescription = null,
                                        tint = Color(0xFFEF4444),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Text(
                                    text = "Battery: ${batteryLevel}%",
                                    fontSize = 12.sp,
                                    color = Color(0xFF10B981) // green-ish when showing percent
                                )
                                Text(
                                    text = "Updated now",
                                    fontSize = 12.sp,
                                    color = Color(0xFF9CA3AF)
                                )
                            }
                        }
                        
                        // Warning icon
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Warning",
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Simple placeholder instead of OSM map
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF111827)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Map view disabled",
                    color = Color(0xFF9CA3AF),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // Settings button (top left)
            IconButton(
                onClick = onSettings,
                modifier = Modifier
                    .padding(16.dp)
                    .align(Alignment.TopStart)
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(Color.White)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = Color(0xFF6366F1)
                )
            }
        }
    }
}
