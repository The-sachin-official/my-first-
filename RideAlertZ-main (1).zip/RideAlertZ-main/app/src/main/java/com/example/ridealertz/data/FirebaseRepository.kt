package com.example.ridealertz.data

import android.location.Location
import com.google.firebase.database.*
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Firebase Repository for RideAlertz
 * Handles all Firebase Realtime Database operations
 * Updated Schema:
 * users ──< emergency_contacts
 *   │
 *   └──< rides ──< crash_events ──< alerts
 * hospitals ──< ambulances
 */
class FirebaseRepository {
    val database: DatabaseReference = Firebase.database.reference

    // ==================== USER OPERATIONS ====================
    
    suspend fun saveUser(user: User): Result<Unit> {
        return try {
            database.child("users").child(user.uid).setValue(user).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getUser(uid: String): Result<User?> {
        return try {
            val snapshot = database.child("users").child(uid).get().await()
            val user = snapshot.getValue(User::class.java)
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateUserLastActive(uid: String): Result<Unit> {
        return try {
            database.child("users").child(uid)
                .updateChildren(mapOf("lastActive" to System.currentTimeMillis())).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==================== EMERGENCY CONTACTS OPERATIONS ====================
    
    suspend fun addEmergencyContact(userId: String, contact: EmergencyContact): Result<String> {
        return try {
            val id = database.child("users").child(userId).child("emergency_contacts").push().key 
                ?: throw Exception("Failed to generate ID")
            val contactWithId = contact.copy(id = id, userId = userId)
            database.child("users").child(userId).child("emergency_contacts").child(id)
                .setValue(contactWithId).await()
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getEmergencyContacts(userId: String): Result<List<EmergencyContact>> {
        return try {
            val snapshot = database.child("users").child(userId).child("emergency_contacts").get().await()
            val contacts = mutableListOf<EmergencyContact>()
            snapshot.children.forEach { child ->
                child.getValue(EmergencyContact::class.java)?.let { contacts.add(it) }
            }
            Result.success(contacts.sortedByDescending { it.isPrimary })
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateEmergencyContact(userId: String, contactId: String, contact: EmergencyContact): Result<Unit> {
        return try {
            database.child("users").child(userId).child("emergency_contacts").child(contactId)
                .setValue(contact).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteEmergencyContact(userId: String, contactId: String): Result<Unit> {
        return try {
            database.child("users").child(userId).child("emergency_contacts").child(contactId)
                .removeValue().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==================== RIDE OPERATIONS ====================
    
    suspend fun startRide(userId: String, ride: Ride): Result<String> {
        return try {
            val id = database.child("users").child(userId).child("rides").push().key 
                ?: throw Exception("Failed to generate ID")
            val rideWithId = ride.copy(id = id, userId = userId, status = "active")
            database.child("users").child(userId).child("rides").child(id)
                .setValue(rideWithId).await()
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun endRide(userId: String, rideId: String, endTime: Long, finalStats: Map<String, Any>): Result<Unit> {
        return try {
            val updates = mapOf(
                "endTime" to endTime,
                "status" to "completed",
                "duration" to (endTime - finalStats["startTime"] as Long),
                "distance" to finalStats["distance"],
                "avgSpeed" to finalStats["avgSpeed"],
                "maxSpeed" to finalStats["maxSpeed"],
                "harshBrakes" to finalStats["harshBrakes"],
                "sharpTurns" to finalStats["sharpTurns"],
                "speedViolations" to finalStats["speedViolations"],
                "safetyScore" to finalStats["safetyScore"]
            )
            database.child("users").child(userId).child("rides").child(rideId)
                .updateChildren(updates).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getUserRides(userId: String, limit: Int = 50): Result<List<Ride>> {
        return try {
            val snapshot = database.child("users").child(userId).child("rides")
                .orderByChild("startTime")
                .limitToLast(limit)
                .get()
                .await()
            
            val rides = mutableListOf<Ride>()
            snapshot.children.forEach { child ->
                child.getValue(Ride::class.java)?.let { rides.add(it) }
            }
            
            Result.success(rides.sortedByDescending { it.startTime })
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun observeActiveRide(userId: String): Flow<Ride?> = callbackFlow {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val rides = mutableListOf<Ride>()
                snapshot.children.forEach { child ->
                    child.getValue(Ride::class.java)?.let { ride ->
                        if (ride.status == "active") {
                            rides.add(ride)
                        }
                    }
                }
                trySend(rides.maxByOrNull { it.startTime })
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }
        
        database.child("users").child(userId).child("rides")
            .orderByChild("status")
            .equalTo("active")
            .addValueEventListener(listener)
        
        awaitClose {
            database.child("users").child(userId).child("rides")
                .orderByChild("status")
                .equalTo("active")
                .removeEventListener(listener)
        }
    }

    // ==================== CRASH EVENT OPERATIONS ====================
    
    suspend fun reportCrashEvent(rideId: String, userId: String, crashEvent: CrashEvent): Result<String> {
        return try {
            val id = database.child("users").child(userId).child("rides").child(rideId)
                .child("crash_events").push().key ?: throw Exception("Failed to generate ID")
            val crashWithId = crashEvent.copy(id = id, rideId = rideId, userId = userId)
            database.child("users").child(userId).child("rides").child(rideId)
                .child("crash_events").child(id).setValue(crashWithId).await()
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getCrashEventsForRide(userId: String, rideId: String): Result<List<CrashEvent>> {
        return try {
            val snapshot = database.child("users").child(userId).child("rides").child(rideId)
                .child("crash_events").get().await()
            val events = mutableListOf<CrashEvent>()
            snapshot.children.forEach { child ->
                child.getValue(CrashEvent::class.java)?.let { events.add(it) }
            }
            Result.success(events.sortedByDescending { it.timestamp })
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateCrashEventStatus(userId: String, rideId: String, crashEventId: String, status: String): Result<Unit> {
        return try {
            database.child("users").child(userId).child("rides").child(rideId)
                .child("crash_events").child(crashEventId)
                .updateChildren(mapOf("status" to status)).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==================== ALERT OPERATIONS ====================
    
    suspend fun createAlert(crashEventId: String, userId: String, rideId: String, alert: Alert): Result<String> {
        return try {
            val id = database.child("users").child(userId).child("rides").child(rideId)
                .child("crash_events").child(crashEventId).child("alerts").push().key 
                ?: throw Exception("Failed to generate ID")
            val alertWithId = alert.copy(id = id, crashEventId = crashEventId, userId = userId)
            database.child("users").child(userId).child("rides").child(rideId)
                .child("crash_events").child(crashEventId).child("alerts").child(id)
                .setValue(alertWithId).await()
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateAlertStatus(userId: String, rideId: String, crashEventId: String, alertId: String, status: String): Result<Unit> {
        return try {
            database.child("users").child(userId).child("rides").child(rideId)
                .child("crash_events").child(crashEventId).child("alerts").child(alertId)
                .updateChildren(mapOf("status" to status)).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun markAlertAsResponded(userId: String, rideId: String, crashEventId: String, alertId: String): Result<Unit> {
        return try {
            val updates = mapOf(
                "status" to "responded",
                "responseTime" to System.currentTimeMillis()
            )
            database.child("users").child(userId).child("rides").child(rideId)
                .child("crash_events").child(crashEventId).child("alerts").child(alertId)
                .updateChildren(updates).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==================== HOSPITAL OPERATIONS ====================
    
    suspend fun getNearbyHospitals(
        latitude: Double,
        longitude: Double,
        radiusKm: Double = 10.0
    ): Result<List<Hospital>> {
        return try {
            val snapshot = database.child("hospitals").get().await()
            val hospitals = mutableListOf<Hospital>()
            
            snapshot.children.forEach { child ->
                val hospital = child.getValue(Hospital::class.java)
                hospital?.let {
                    val distance = calculateDistance(
                        latitude, longitude,
                        it.latitude, it.longitude
                    )
                    if (distance <= radiusKm) {
                        hospitals.add(it.copy(distance = distance))
                    }
                }
            }
            
            // Sort by distance
            hospitals.sortBy { it.distance }
            Result.success(hospitals)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun addHospital(hospital: Hospital): Result<String> {
        return try {
            val id = database.child("hospitals").push().key ?: throw Exception("Failed to generate ID")
            val hospitalWithId = hospital.copy(id = id)
            database.child("hospitals").child(id).setValue(hospitalWithId).await()
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==================== AMBULANCE OPERATIONS ====================
    
    suspend fun getAvailableAmbulances(hospitalId: String? = null): Result<List<Ambulance>> {
        return try {
            val query = if (hospitalId != null) {
                database.child("hospitals").child(hospitalId).child("ambulances")
            } else {
                database.child("ambulances") // Global ambulance registry
            }
            
            val snapshot = query.get().await()
            val ambulances = mutableListOf<Ambulance>()
            
            snapshot.children.forEach { child ->
                val ambulance = child.getValue(Ambulance::class.java)
                if (ambulance?.isAvailable == true) {
                    ambulances.add(ambulance)
                }
            }
            
            Result.success(ambulances)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun addAmbulanceToHospital(hospitalId: String, ambulance: Ambulance): Result<String> {
        return try {
            val id = database.child("hospitals").child(hospitalId).child("ambulances").push().key 
                ?: throw Exception("Failed to generate ID")
            val ambulanceWithId = ambulance.copy(id = id, hospitalId = hospitalId)
            database.child("hospitals").child(hospitalId).child("ambulances").child(id)
                .setValue(ambulanceWithId).await()
            
            // Also add to global registry
            database.child("ambulances").child(id).setValue(ambulanceWithId).await()
            
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateAmbulanceLocation(
        ambulanceId: String,
        latitude: Double,
        longitude: Double
    ): Result<Unit> {
        return try {
            val updates = mapOf(
                "currentLatitude" to latitude,
                "currentLongitude" to longitude
            )
            database.child("ambulances").child(ambulanceId).updateChildren(updates).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun observeAmbulanceLocation(ambulanceId: String): Flow<Pair<Double, Double>> = callbackFlow {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val ambulance = snapshot.getValue(Ambulance::class.java)
                ambulance?.let {
                    trySend(Pair(it.currentLatitude, it.currentLongitude))
                }
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }
        
        database.child("ambulances").child(ambulanceId).addValueEventListener(listener)
        
        awaitClose {
            database.child("ambulances").child(ambulanceId).removeEventListener(listener)
        }
    }

    // ==================== ACCIDENT OPERATIONS ====================
    
    suspend fun reportAccident(accident: AccidentReport): Result<String> {
        return try {
            val id = database.child("accidents").push().key ?: throw Exception("Failed to generate ID")
            val accidentWithId = accident.copy(id = id)
            database.child("accidents").child(id).setValue(accidentWithId).await()
            
            // Also create a crash alert for admin dashboard
            createCrashAlert(accidentWithId)
            
            // Send notification to nearby hospitals
            sendAccidentNotificationToHospitals(accidentWithId)
            
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    private suspend fun createCrashAlert(accident: AccidentReport) {
        try {
            // Find nearest hospital
            val hospitals = getNearbyHospitals(accident.latitude, accident.longitude, 50.0)
            val nearestHospital = hospitals.getOrNull()?.firstOrNull()
            
            val crashAlert = CrashAlert(
                alertId = accident.id,
                userId = accident.userId,
                userName = accident.userName,
                userPhone = accident.userPhone,
                hospitalId = nearestHospital?.id ?: "",
                timestamp = accident.timestamp,
                latitude = accident.latitude,
                longitude = accident.longitude,
                speed = accident.speed,
                severity = accident.severity,
                status = "pending",
                nearestHospital = nearestHospital?.name ?: "Unknown Hospital",
                nearestHospitalDistance = nearestHospital?.distance ?: 0.0
            )
            
            database.child("crash_alerts").child(accident.id).setValue(crashAlert).await()
        } catch (e: Exception) {
            // Silent fail for crash alert creation
        }
    }

    private suspend fun sendAccidentNotificationToHospitals(accident: AccidentReport) {
        try {
            val hospitals = getNearbyHospitals(accident.latitude, accident.longitude, 20.0)
            hospitals.getOrNull()?.forEach { hospital ->
                val notification = Notification(
                    id = database.child("notifications").push().key ?: return@forEach,
                    userId = hospital.id,
                    title = "🚨 Emergency Alert",
                    message = "Accident reported ${String.format("%.1f", hospital.distance)} km away",
                    type = "emergency",
                    actionUrl = "accident/${accident.id}"
                )
                database.child("notifications").child(notification.id).setValue(notification)
            }
        } catch (e: Exception) {
            // Silent fail for notifications
        }
    }

    suspend fun getAccidentById(accidentId: String): Result<AccidentReport?> {
        return try {
            val snapshot = database.child("accidents").child(accidentId).get().await()
            val accident = snapshot.getValue(AccidentReport::class.java)
            Result.success(accident)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun observeAccidents(): Flow<List<AccidentReport>> = callbackFlow {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val accidents = mutableListOf<AccidentReport>()
                snapshot.children.forEach { child ->
                    child.getValue(AccidentReport::class.java)?.let { accidents.add(it) }
                }
                trySend(accidents.sortedByDescending { it.timestamp })
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }
        
        database.child("accidents").addValueEventListener(listener)
        
        awaitClose {
            database.child("accidents").removeEventListener(listener)
        }
    }

    // ==================== TRAVEL HISTORY OPERATIONS ====================
    
    suspend fun saveTravelHistory(travel: TravelHistory): Result<String> {
        return try {
            val id = database.child("travel_history").push().key ?: throw Exception("Failed to generate ID")
            val travelWithId = travel.copy(id = id)
            database.child("travel_history").child(id).setValue(travelWithId).await()
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getUserTravelHistory(userId: String, limit: Int = 50): Result<List<TravelHistory>> {
        return try {
            val snapshot = database.child("travel_history")
                .orderByChild("userId")
                .equalTo(userId)
                .limitToLast(limit)
                .get()
                .await()
            
            val travels = mutableListOf<TravelHistory>()
            snapshot.children.forEach { child ->
                child.getValue(TravelHistory::class.java)?.let { travels.add(it) }
            }
            
            Result.success(travels.sortedByDescending { it.startTime })
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==================== EMERGENCY MISSION OPERATIONS ====================
    
    suspend fun createEmergencyMission(mission: EmergencyMission): Result<String> {
        return try {
            val id = database.child("missions").push().key ?: throw Exception("Failed to generate ID")
            val missionWithId = mission.copy(id = id)
            database.child("missions").child(id).setValue(missionWithId).await()
            
            // Update ambulance status
            database.child("ambulances").child(mission.ambulanceId).updateChildren(
                mapOf(
                    "isAvailable" to false,
                    "currentMissionId" to id
                )
            ).await()
            
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun observeMission(missionId: String): Flow<EmergencyMission?> = callbackFlow {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val mission = snapshot.getValue(EmergencyMission::class.java)
                trySend(mission)
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }
        
        database.child("missions").child(missionId).addValueEventListener(listener)
        
        awaitClose {
            database.child("missions").child(missionId).removeEventListener(listener)
        }
    }

    fun observeMissionsByAmbulanceId(ambulanceId: String): Flow<EmergencyMission?> = callbackFlow {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                // Find the most recent active mission for this ambulance
                val missions = mutableListOf<EmergencyMission>()
                snapshot.children.forEach { child ->
                    val mission = child.getValue(EmergencyMission::class.java)
                    mission?.let {
                        if (it.ambulanceId == ambulanceId && 
                            (it.status == "dispatched" || it.status == "in_progress" || it.status == "en_route" || it.status == "assigned")) {
                            missions.add(it)
                        }
                    }
                }
                // Send the most recent active mission, or null if none
                val activeMission = missions.maxByOrNull { it.dispatchTime }
                trySend(activeMission)
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }
        
        // Listen to all missions and filter by ambulanceId in code
        // This ensures we catch all mission updates
        database.child("missions").addValueEventListener(listener)
        
        awaitClose {
            database.child("missions").removeEventListener(listener)
        }
    }

    // ==================== NOTIFICATION OPERATIONS ====================
    
    suspend fun getUserNotifications(userId: String): Result<List<Notification>> {
        return try {
            val snapshot = database.child("notifications")
                .orderByChild("userId")
                .equalTo(userId)
                .get()
                .await()
            
            val notifications = mutableListOf<Notification>()
            snapshot.children.forEach { child ->
                child.getValue(Notification::class.java)?.let { notifications.add(it) }
            }
            
            Result.success(notifications.sortedByDescending { it.timestamp })
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun markNotificationAsRead(notificationId: String): Result<Unit> {
        return try {
            database.child("notifications").child(notificationId)
                .updateChildren(mapOf("isRead" to true))
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==================== ADMIN OPERATIONS ====================
    
    suspend fun getCrashAlertsForHospital(hospitalId: String): Result<List<CrashAlert>> {
        return try {
            val snapshot = database.child("crash_alerts")
                .orderByChild("hospitalId")
                .equalTo(hospitalId)
                .get()
                .await()
            
            val alerts = mutableListOf<CrashAlert>()
            snapshot.children.forEach { child ->
                child.getValue(CrashAlert::class.java)?.let { alerts.add(it) }
            }
            
            Result.success(alerts.sortedByDescending { it.timestamp })
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    fun observeCrashAlertsForHospital(hospitalId: String): Flow<List<CrashAlert>> = callbackFlow {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val alerts = mutableListOf<CrashAlert>()
                snapshot.children.forEach { child ->
                    val alert = child.getValue(CrashAlert::class.java)
                    if (alert?.hospitalId == hospitalId) {
                        alerts.add(alert)
                    }
                }
                trySend(alerts.sortedByDescending { it.timestamp })
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }
        
        database.child("crash_alerts").addValueEventListener(listener)
        
        awaitClose {
            database.child("crash_alerts").removeEventListener(listener)
        }
    }
    
    suspend fun dispatchAmbulance(
        alertId: String,
        ambulanceId: String,
        driverName: String
    ): Result<Unit> {
        return try {
            val updates = mapOf(
                "status" to "ambulance_dispatched",
                "assignedAmbulanceId" to ambulanceId,
                "assignedDriver" to driverName,
                "responseTime" to System.currentTimeMillis()
            )
            
            database.child("crash_alerts").child(alertId).updateChildren(updates).await()
            
            // Update ambulance status
            database.child("ambulances").child(ambulanceId).updateChildren(
                mapOf(
                    "isAvailable" to false,
                    "currentMissionId" to alertId
                )
            ).await()
            
            // Create emergency mission
            val alertSnapshot = database.child("crash_alerts").child(alertId).get().await()
            val alert = alertSnapshot.getValue(CrashAlert::class.java)
            alert?.let {
                val mission = EmergencyMission(
                    accidentId = alertId,
                    ambulanceId = ambulanceId,
                    hospitalId = it.hospitalId,
                    victimLatitude = it.latitude,
                    victimLongitude = it.longitude,
                    status = "dispatched",
                    dispatchTime = System.currentTimeMillis(),
                    eta = calculateETA(it.latitude, it.longitude, ambulanceId)
                )
                createEmergencyMission(mission)
            }
            
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun resolveCrashAlert(alertId: String): Result<Unit> {
        return try {
            val updates = mapOf(
                "status" to "resolved",
                "resolvedTime" to System.currentTimeMillis()
            )
            
            database.child("crash_alerts").child(alertId).updateChildren(updates).await()
            
            // Free up ambulance
            val alertSnapshot = database.child("crash_alerts").child(alertId).get().await()
            val alert = alertSnapshot.getValue(CrashAlert::class.java)
            alert?.assignedAmbulanceId?.let { ambulanceId ->
                database.child("ambulances").child(ambulanceId).updateChildren(
                    mapOf(
                        "isAvailable" to true,
                        "currentMissionId" to null
                    )
                ).await()
            }
            
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun getAdminDashboard(hospitalId: String): Result<AdminDashboard> {
        return try {
            val hospitalSnapshot = database.child("hospitals").child(hospitalId).get().await()
            val hospital = hospitalSnapshot.getValue(Hospital::class.java)
            
            val alertsSnapshot = database.child("crash_alerts")
                .orderByChild("hospitalId")
                .equalTo(hospitalId)
                .get()
                .await()
            
            val totalAccidents = alertsSnapshot.children.count()
            val pendingAccidents = alertsSnapshot.children.count { 
                it.getValue(CrashAlert::class.java)?.status == "pending" 
            }
            val resolvedAccidents = alertsSnapshot.children.count { 
                it.getValue(CrashAlert::class.java)?.status == "resolved" 
            }
            
            val ambulancesSnapshot = database.child("ambulances")
                .orderByChild("hospitalId")
                .equalTo(hospitalId)
                .get()
                .await()
            
            val totalAmbulances = ambulancesSnapshot.children.count()
            val availableAmbulances = ambulancesSnapshot.children.count { 
                it.getValue(Ambulance::class.java)?.isAvailable == true 
            }
            
            val dashboard = AdminDashboard(
                hospitalId = hospitalId,
                hospitalName = hospital?.name ?: "Unknown Hospital",
                totalAccidents = totalAccidents,
                pendingAccidents = pendingAccidents,
                resolvedAccidents = resolvedAccidents,
                availableAmbulances = availableAmbulances,
                totalAmbulances = totalAmbulances,
                averageResponseTime = 0L, // TODO: Calculate from historical data
                lastUpdated = System.currentTimeMillis()
            )
            
            Result.success(dashboard)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    private suspend fun calculateETA(victimLat: Double, victimLng: Double, ambulanceId: String): Int {
        // Get ambulance location
        val ambulanceSnapshot = database.child("ambulances").child(ambulanceId).get().await()
        val ambulance = ambulanceSnapshot.getValue(Ambulance::class.java)
        
        return if (ambulance != null) {
            val distance = calculateDistance(
                ambulance.currentLatitude, ambulance.currentLongitude,
                victimLat, victimLng
            )
            // Assume average ambulance speed of 40 km/h in city traffic
            ((distance / 40.0) * 60).toInt()
        } else {
            15 // Default 15 minutes
        }
    }

    // ==================== UTILITY FUNCTIONS ====================
    
    /**
     * Calculate distance between two coordinates using Haversine formula
     * Returns distance in kilometers
     */
    private fun calculateDistance(
        lat1: Double, lon1: Double,
        lat2: Double, lon2: Double
    ): Double {
        val earthRadius = 6371.0 // km
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2) * sin(dLon / 2)
        
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return earthRadius * c
    }

    companion object {
        @Volatile
        private var instance: FirebaseRepository? = null

        fun getInstance(): FirebaseRepository {
            return instance ?: synchronized(this) {
                instance ?: FirebaseRepository().also { instance = it }
            }
        }
    }
}
