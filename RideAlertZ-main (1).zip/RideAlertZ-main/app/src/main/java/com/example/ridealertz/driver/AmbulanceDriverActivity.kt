package com.example.ridealertz.driver

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.net.toUri
import androidx.lifecycle.lifecycleScope
import com.example.ridealertz.AmbulanceDriverLoginActivity
import com.example.ridealertz.AmbulanceDriverRegisterActivity
import com.example.ridealertz.RideMapView
import com.example.ridealertz.SettingsActivity
import com.example.ridealertz.data.*
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.*
import android.util.Log

class AmbulanceDriverActivity : ComponentActivity() {
    private val firebaseRepository = FirebaseRepository.getInstance()
    private var driverId: String = ""
    private var driverName: String = ""
    private var ambulanceId: String = ""
    private var driverPhone: String = ""
    private var driverExperienceYears: Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        try {
            Log.d("AmbulanceDriver", "onCreate started")
            val prefs = getSharedPreferences("ridealertz", MODE_PRIVATE)
            driverId = intent.getStringExtra("driverId") ?: prefs.getString("driverId", "D01") ?: "D01" // Default for demo
            driverName = intent.getStringExtra("driverName") ?: prefs.getString("driverName", "Ravi") ?: "Ravi"
            ambulanceId = intent.getStringExtra("ambulanceId") ?: prefs.getString("ambulanceId", "AMB001") ?: "AMB001"
            driverPhone = intent.getStringExtra("driverPhone") ?: prefs.getString("driverPhone", "") ?: ""
            driverExperienceYears = intent.getIntExtra("experienceYears", 0)

            Log.d("AmbulanceDriver", "Driver data: id=$driverId, name=$driverName, ambulance=$ambulanceId")

            try {
                setContent {
                    MaterialTheme {
                        AmbulanceDriverScreen(
                            driverId = driverId,
                            driverName = driverName,
                            ambulanceId = ambulanceId,
                            driverPhone = driverPhone,
                            experienceYears = driverExperienceYears,
                            onBackPressed = { finish() },
                            onLogout = { performLogout() },
                            onEditProfile = { editDriverProfile() },
                            onOpenSettings = { openDriverSettings() },
                            onViewMissionHistory = { viewMissionHistory() },
                            onNavigateToLocation = { lat, lng -> openLocationInMaps(lat, lng) },
                            onCallRider = { phone -> callRider(phone) },
                            onMarkArrived = { missionId -> markArrived(missionId) },
                            onMarkCompleted = { missionId -> markCompleted(missionId) }
                        )
                    }
                }
            } catch (e: Exception) {
                Log.e("AmbulanceDriver", "Error in setContent", e)
                e.printStackTrace()
                Toast.makeText(this, "Error loading dashboard UI: ${e.message}", Toast.LENGTH_LONG).show()
                finish()
            }
            Log.d("AmbulanceDriver", "onCreate completed successfully")
        } catch (e: Exception) {
            Log.e("AmbulanceDriver", "Error in onCreate", e)
            Toast.makeText(this, "Error loading dashboard: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun performLogout() {
        lifecycleScope.launch {
            try {
                FirebaseAuth.getInstance().signOut()
            } catch (_: Exception) {
            }
            startActivity(Intent(this@AmbulanceDriverActivity, AmbulanceDriverLoginActivity::class.java))
            finish()
        }
    }

    private fun editDriverProfile() {
        startActivity(Intent(this, AmbulanceDriverRegisterActivity::class.java))
    }

    private fun openDriverSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    private fun viewMissionHistory() {
        Toast.makeText(this, "Mission history coming soon", Toast.LENGTH_SHORT).show()
    }

    private fun callRider(phone: String) {
        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = "tel:$phone".toUri()
        }
        startActivity(intent)
    }

    private fun openLocationInMaps(lat: Double, lng: Double) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = "geo:$lat,$lng?q=$lat,$lng".toUri()
        }
        startActivity(intent)
    }

    private fun markArrived(missionId: String) {
        lifecycleScope.launch {
            val updates = mapOf(
                "status" to "arrived",
                "arrivalTime" to System.currentTimeMillis()
            )
            firebaseRepository.database.child("missions").child(missionId).updateChildren(updates).await()
        }
    }

    private fun markCompleted(missionId: String) {
        lifecycleScope.launch {
            val updates = mapOf(
                "status" to "completed",
                "completionTime" to System.currentTimeMillis()
            )
            firebaseRepository.database.child("missions").child(missionId).updateChildren(updates).await()

            // Free up ambulance
            firebaseRepository.database.child("ambulances").child(ambulanceId).updateChildren(
                mapOf(
                    "isAvailable" to true,
                    "currentMissionId" to null
                )
            ).await()
        }
    }
}

@Composable
fun ProfileTabContent(
    driverId: String,
    driverName: String,
    driverPhone: String,
    experienceYears: Int,
    ambulanceId: String,
    mission: EmergencyMission?,
    crashAlert: CrashAlert?,
    palette: EmergencyPalette,
    onStartNavigation: () -> Unit,
    onCallVictim: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        DriverStatusCard(
            ambulanceId = ambulanceId,
            driverId = driverId,
            driverPhone = driverPhone,
            experienceYears = experienceYears,
            mission = mission,
            palette = palette
        )
        ProfileOverviewCard(
            driverName = driverName,
            driverId = driverId,
            phone = driverPhone,
            experienceYears = experienceYears,
            ambulanceId = ambulanceId,
            palette = palette
        )
        LiveMapPreviewCard()
    }
}

@Composable
fun MissionTabContent(
    mission: EmergencyMission?,
    crashAlert: CrashAlert?,
    riderProfile: User?,
    emergencyContacts: List<EmergencyContact>,
    palette: EmergencyPalette,
    onNavigateToLocation: (Double, Double) -> Unit,
    onMarkArrived: (String) -> Unit,
    onMarkCompleted: (String) -> Unit,
    onViewHistory: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        EmergencyAlertCard(
            mission = mission,
            crashAlert = crashAlert,
            palette = palette,
            onMap = {
                crashAlert?.let { onNavigateToLocation(it.latitude, it.longitude) }
            },
            onAccept = {
                mission?.let { onMarkArrived(it.id) }
            },
            onReject = {
                mission?.let { onMarkCompleted(it.id) }
            }
        )
        LiveMapPreviewCard()
        MissionQueueCard(
            mission = mission,
            onViewHistory = onViewHistory,
            palette = palette
        )
        RiderDetailsCard(
            crashAlert = crashAlert,
            riderProfile = riderProfile,
            emergencyContacts = emergencyContacts,
            palette = palette
        )
        TripSummaryCard(
            mission = mission,
            palette = palette,
            onSaveReport = { }
        )
    }
}

data class EmergencyPalette(
    val primary: Color = Color(0xFFD32F2F),
    val secondary: Color = Color(0xFFF57C00),
    val accent: Color = Color(0xFF00E676),
    val background: Color = Color(0xFF121212),
    val card: Color = Color(0xFF1E1E1E),
    val cardElevated: Color = Color(0xFF252525)
)

enum class MissionActionStatus { ON_THE_WAY, REACHED, PATIENT_SHIFTED }

enum class DriverDashboardTab(val label: String, val emoji: String) {
    PROFILE("Profile", "👤"),
    MISSION("Missions", "🚑"),
    SETTINGS("Settings", "⚙️");

    companion object {
        fun fromOrdinal(ordinal: Int) = entries[ordinal]
    }
}

data class WeatherSnapshot(
    val location: String,
    val condition: String,
    val temperatureC: Int,
    val humidity: Int,
    val windKmph: Int,
    val alert: String? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmergencyTopBar(
    driverName: String,
    driverId: String,
    onBack: () -> Unit,
    onLogout: () -> Unit,
    palette: EmergencyPalette
) {
    val gradient = Brush.horizontalGradient(
        listOf(palette.primary.copy(alpha = 0.9f), palette.secondary.copy(alpha = 0.9f))
    )
    TopAppBar(
        title = {
            Column {
                Text("🚑 RideAlertz", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text(
                    text = "$driverName (ID: $driverId)",
                    fontSize = 13.sp,
                    color = Color.White
                )
            }
        },
        navigationIcon = {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
        },
        actions = {
            IconButton(onClick = onLogout) {
                Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = "Logout", tint = Color.White)
            }
            IconButton(onClick = { /* TODO settings */ }) {
                Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
            }
            IconButton(onClick = { /* TODO notifications */ }) {
                Icon(Icons.Default.Notifications, contentDescription = "Notifications", tint = Color.White)
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
        modifier = Modifier
            .background(gradient)
            .clip(RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
    )
}

@Composable
fun DriverStatusCard(
    ambulanceId: String,
    driverId: String,
    driverPhone: String,
    experienceYears: Int,
    mission: EmergencyMission?,
    palette: EmergencyPalette
) {
    val pulseAnim = rememberInfiniteTransition(label = "pulse")
    val alpha by pulseAnim.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(1200, easing = LinearEasing), repeatMode = RepeatMode.Reverse),
        label = "pulseAlpha"
    )
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = palette.card),
        elevation = CardDefaults.cardElevation(10.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(palette.accent.copy(alpha = alpha))
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = if (mission == null) "AVAILABLE" else mission.status.uppercase(Locale.getDefault()),
                    color = if (mission == null) palette.accent else palette.secondary,
                    fontWeight = FontWeight.Bold
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocalHospital, contentDescription = null, tint = Color.White.copy(alpha = 0.8f))
                Spacer(Modifier.width(8.dp))
                Text("Ambulance: $ambulanceId", color = Color.White)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Person, contentDescription = null, tint = Color.White.copy(alpha = 0.8f))
                Spacer(Modifier.width(8.dp))
                Text("Driver ID: $driverId", color = Color.White.copy(alpha = 0.9f))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Phone, contentDescription = null, tint = Color.White.copy(alpha = 0.8f))
                Spacer(Modifier.width(8.dp))
                Text("Phone: ${if (driverPhone.isBlank()) "N/A" else driverPhone}", color = Color.White.copy(alpha = 0.8f))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Work, contentDescription = null, tint = Color.White.copy(alpha = 0.8f))
                Spacer(Modifier.width(8.dp))
                Text("Experience: $experienceYears yrs", color = Color.White.copy(alpha = 0.8f))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Place, contentDescription = null, tint = Color.White.copy(alpha = 0.8f))
                Spacer(Modifier.width(8.dp))
                Text(
                    text = if (mission == null) "Current Location: Live GPS Enabled" else "Mission ETA: ${mission.eta} mins",
                    color = Color.White.copy(alpha = 0.8f)
                )
            }
        }
    }
}

@Composable
fun EmergencyAlertCard(
    mission: EmergencyMission?,
    crashAlert: CrashAlert?,
    palette: EmergencyPalette,
    onMap: () -> Unit,
    onAccept: () -> Unit,
    onReject: () -> Unit
) {
    val shake = rememberInfiniteTransition(label = "alert")
    val borderAlpha by shake.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(800, easing = FastOutLinearInEasing), repeatMode = RepeatMode.Reverse),
        label = "borderAlpha"
    )
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(2.dp, palette.primary.copy(alpha = borderAlpha), RoundedCornerShape(20.dp)),
        colors = CardDefaults.cardColors(containerColor = palette.cardElevated)
    ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("EMERGENCY ALERT", fontWeight = FontWeight.Bold, color = palette.primary)
            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
            if (mission != null && crashAlert != null) {
                InfoRow(
                    icon = Icons.Default.Place,
                    label = "Location",
                    value = "${String.format(Locale.getDefault(), "%.2f", crashAlert.latitude)}, ${String.format(Locale.getDefault(), "%.2f", crashAlert.longitude)}"
                )
                InfoRow(icon = Icons.Default.Schedule, label = "Time", value = formatRelativeTime(crashAlert.timestamp))
                InfoRow(icon = Icons.Default.NearMe, label = "Distance", value = "${mission.eta.takeIf { it > 0 } ?: 1} km")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onMap, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = palette.secondary)) {
                        Text("Map View")
                    }
                    Button(onClick = onAccept, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = palette.accent)) {
                        Text("Accept")
                    }
                    Button(onClick = onReject, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = palette.primary)) {
                        Text("Reject")
                    }
                }
            } else {
                Text("No active emergencies. Standby for dispatch.", color = Color.White.copy(alpha = 0.7f))
            }
        }
    }
}

@Composable
fun InfoRow(icon: ImageVector, label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Icon(icon, contentDescription = null, tint = Color.White.copy(alpha = 0.6f))
        Spacer(Modifier.width(8.dp))
        Text("$label: ", color = Color.White.copy(alpha = 0.6f))
        Text(value, color = Color.White, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun LiveMapPreviewCard() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(480.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B0D16))
    ) {
        Box(Modifier.fillMaxSize()) {
            RideMapView(
                modifier = Modifier.fillMaxSize(),
                selectedCategory = "Hospitals"
            )
        }
    }
}


@Composable
fun TripSummaryCard(mission: EmergencyMission?, palette: EmergencyPalette, onSaveReport: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = palette.card)
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("📊 TRIP SUMMARY", fontWeight = FontWeight.Bold, color = Color.White)
            val distance = mission?.eta?.times(0.35)?.takeIf { it > 0 } ?: 4.1
            val duration = mission?.eta ?: 11
            SummaryRow("Distance Covered", "${String.format(Locale.getDefault(), "%.1f km", distance)}")
            SummaryRow("Time Taken", "${duration}m")
            SummaryRow("Patient Condition", if (mission?.status == "completed") "Stable" else "In Progress")
            Button(onClick = onSaveReport, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.secondary)) {
                Text("Save Report", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun SummaryRow(label: String, value: String) {
    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
        Text(label, color = Color.White.copy(alpha = 0.7f))
        Text(value, color = Color.White, fontWeight = FontWeight.SemiBold)
    }
}

fun formatRelativeTime(timestamp: Long): String {
    val diff = System.currentTimeMillis() - timestamp
    val minutes = (diff / 60000).coerceAtLeast(0)
    return if (minutes == 0L) "Just now" else "$minutes mins ago"
}

@Composable
fun ProfileOverviewCard(
    driverName: String,
    driverId: String,
    phone: String,
    experienceYears: Int,
    ambulanceId: String,
    palette: EmergencyPalette
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = palette.card)
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("👤 Driver Profile", color = palette.accent, fontWeight = FontWeight.Bold)
            Text(driverName, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            SummaryRow("Driver ID", driverId)
            SummaryRow("Phone", if (phone.isBlank()) "Not set" else phone)
            SummaryRow("Experience", "$experienceYears years")
            SummaryRow("Ambulance", ambulanceId)
        }
    }
}

@Composable
fun MissionQueueCard(
    mission: EmergencyMission?,
    onViewHistory: () -> Unit,
    palette: EmergencyPalette
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = palette.card)
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("📋 Missions", color = palette.secondary, fontWeight = FontWeight.Bold)
            if (mission != null) {
                Text("Current Mission: ${mission.id}", color = Color.White)
                SummaryRow("Status", mission.status.replace("_", " ").uppercase(Locale.getDefault()))
                SummaryRow("ETA", "${mission.eta} mins")
            } else {
                Text("No active missions. Standby for dispatch.", color = Color.White.copy(alpha = 0.7f))
                Text(
                    text = "You will see rider & vehicle details here immediately when an SOS is assigned.",
                    color = Color.White.copy(alpha = 0.6f),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            OutlinedButton(onClick = onViewHistory, modifier = Modifier.fillMaxWidth()) {
                Text("View Mission History")
            }
        }
    }
}

@Composable
fun RiderDetailsCard(
    crashAlert: CrashAlert?,
    riderProfile: User?,
    emergencyContacts: List<EmergencyContact>,
    palette: EmergencyPalette
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = palette.card)
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("🧑‍🦽 Rider Details", color = palette.secondary, fontWeight = FontWeight.Bold)
            if (crashAlert != null) {
                InfoRow(Icons.Default.Person, "Name", crashAlert.userName)
                InfoRow(Icons.Default.Phone, "Phone", crashAlert.userPhone)
                InfoRow(Icons.Default.Warning, "Severity", crashAlert.severity)
                InfoRow(Icons.Default.Place, "Last Location", "${String.format(Locale.getDefault(), "%.4f", crashAlert.latitude)}, ${String.format(Locale.getDefault(), "%.4f", crashAlert.longitude)}")

                Spacer(Modifier.height(8.dp))
                Text("🚗 Vehicle", fontWeight = FontWeight.SemiBold, color = Color.White)
                InfoRow(Icons.Default.DirectionsCar, "Type", riderProfile?.vehicleType ?: "Unknown")
                InfoRow(Icons.Default.Badge, "Model", riderProfile?.vehicleName ?: "Unknown")
                InfoRow(Icons.Default.ConfirmationNumber, "Number", riderProfile?.vehicleNumber ?: "—")

                if (emergencyContacts.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("📞 Emergency Contacts", fontWeight = FontWeight.SemiBold, color = Color.White)
                    emergencyContacts.take(3).forEach { contact ->
                        InfoRow(
                            icon = Icons.Default.ContactPhone,
                            label = contact.name.ifBlank { "Contact" },
                            value = "${contact.phone}${if (contact.isPrimary) " • Primary" else ""}"
                        )
                    }
                }
            } else {
                Text("No rider assigned yet. Standby for the next SOS dispatch.", color = Color.White.copy(alpha = 0.7f))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AmbulanceDriverScreen(
    driverId: String,
    driverName: String,
    ambulanceId: String,
    driverPhone: String,
    experienceYears: Int,
    onBackPressed: () -> Unit,
    onLogout: () -> Unit,
    onEditProfile: () -> Unit,
    onOpenSettings: () -> Unit,
    onViewMissionHistory: () -> Unit,
    onNavigateToLocation: (Double, Double) -> Unit,
    onCallRider: (String) -> Unit,
    onMarkArrived: (String) -> Unit,
    onMarkCompleted: (String) -> Unit
) {
    val firebaseRepository = FirebaseRepository.getInstance()
    var currentMission by remember { mutableStateOf<EmergencyMission?>(null) }
    var crashAlert by remember { mutableStateOf<CrashAlert?>(null) }
    var riderProfile by remember { mutableStateOf<User?>(null) }
    var emergencyContacts by remember { mutableStateOf<List<EmergencyContact>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(ambulanceId) {
        var hasData = false
        var job: kotlinx.coroutines.Job? = null
        try {
            job = launch {
                try {
                    firebaseRepository.observeMissionsByAmbulanceId(ambulanceId).collect { mission ->
                hasData = true
                Log.d("AmbulanceDriver", "Mission received: ${mission?.id}, status: ${mission?.status}, ambulanceId: ${mission?.ambulanceId}")
                currentMission = mission
                if (mission != null) {
                    Log.d("AmbulanceDriver", "Loading rider details for mission: ${mission.id}, riderId: ${mission.riderId}")
                    val alertResult = firebaseRepository.getAccidentById(mission.accidentId)
                    alertResult.onSuccess { accident ->
                        crashAlert = CrashAlert(
                            alertId = accident?.id ?: mission.accidentId,
                            userId = accident?.userId ?: mission.riderId,
                            userName = accident?.userName ?: mission.riderName,
                            userPhone = accident?.userPhone ?: mission.riderPhone,
                            latitude = accident?.latitude ?: mission.victimLatitude,
                            longitude = accident?.longitude ?: mission.victimLongitude,
                            timestamp = accident?.timestamp ?: mission.dispatchTime,
                            severity = accident?.severity ?: mission.severity
                        )
                        Log.d("AmbulanceDriver", "CrashAlert created from accident data")
                    }.onFailure {
                        // If accident data not found, create crashAlert from mission data
                        Log.d("AmbulanceDriver", "Accident data not found, using mission data for crashAlert")
                        crashAlert = CrashAlert(
                            alertId = mission.accidentId,
                            userId = mission.riderId,
                            userName = mission.riderName,
                            userPhone = mission.riderPhone,
                            latitude = mission.victimLatitude,
                            longitude = mission.victimLongitude,
                            timestamp = mission.dispatchTime,
                            severity = mission.severity
                        )
                    }

                    if (mission.riderId.isNotBlank()) {
                        firebaseRepository.getUser(mission.riderId).onSuccess { user ->
                            riderProfile = user
                            Log.d("AmbulanceDriver", "Rider profile loaded: ${user?.name ?: "Unknown"}, phone: ${user?.phone ?: "N/A"}")
                        }.onFailure { 
                            Log.e("AmbulanceDriver", "Failed to load rider profile: ${it.message}")
                        }
                        firebaseRepository.getEmergencyContacts(mission.riderId).onSuccess { 
                            emergencyContacts = it
                            Log.d("AmbulanceDriver", "Emergency contacts loaded: ${it.size} contacts")
                        }.onFailure {
                            Log.e("AmbulanceDriver", "Failed to load emergency contacts: ${it.message}")
                        }
                    } else {
                        Log.d("AmbulanceDriver", "No riderId in mission, using mission data")
                        riderProfile = null
                        emergencyContacts = emptyList()
                    }
                } else {
                    crashAlert = null
                    riderProfile = null
                    emergencyContacts = emptyList()
                }
                isLoading = false
                    }
                } catch (e: Exception) {
                    Log.e("AmbulanceDriver", "Error collecting mission data", e)
                    isLoading = false
                }
            }
        } catch (e: Exception) {
            Log.e("AmbulanceDriver", "Error in LaunchedEffect observeMission", e)
            isLoading = false
        }

        // Timeout for loading
        try {
            delay(5000)
            if (!hasData) {
                job?.cancel()
                isLoading = false
            }
        } catch (e: Exception) {
            Log.e("AmbulanceDriver", "Error in LaunchedEffect timeout", e)
            isLoading = false
        }
    }

    val emergencyPalette = EmergencyPalette()
    var selectedTab by remember { mutableStateOf(DriverDashboardTab.PROFILE) }

    Scaffold(
        containerColor = Color(0xFF121212),
        topBar = {
            EmergencyTopBar(
                driverName = driverName,
                driverId = driverId,
                onBack = onBackPressed,
                onLogout = onLogout,
                palette = emergencyPalette
            )
        }
    ) { padding ->
        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = emergencyPalette.accent)
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                TabRow(
                    selectedTabIndex = selectedTab.ordinal,
                    containerColor = Color.Transparent,
                    contentColor = emergencyPalette.accent
                ) {
                    DriverDashboardTab.entries.forEachIndexed { index, tab ->
                        Tab(
                            selected = selectedTab == tab,
                            onClick = {
                                if (tab == DriverDashboardTab.SETTINGS) {
                                    onOpenSettings()
                                } else {
                                    selectedTab = tab
                                }
                            },
                            text = {
                                Text("${tab.emoji} ${tab.label}", color = Color.White)
                            }
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))

                when (selectedTab) {
                    DriverDashboardTab.PROFILE -> {
                        ProfileTabContent(
                            driverId = driverId,
                            driverName = driverName,
                            driverPhone = driverPhone,
                            experienceYears = experienceYears,
                            ambulanceId = ambulanceId,
                            mission = currentMission,
                            crashAlert = crashAlert,
                            palette = emergencyPalette,
                            onStartNavigation = {
                                crashAlert?.let { onNavigateToLocation(it.latitude, it.longitude) }
                            },
                            onCallVictim = { crashAlert?.let { onCallRider(it.userPhone) } }
                        )
                    }

                    DriverDashboardTab.MISSION -> {
                        MissionTabContent(
                            mission = currentMission,
                            crashAlert = crashAlert,
                            riderProfile = riderProfile,
                            emergencyContacts = emergencyContacts,
                            palette = emergencyPalette,
                            onNavigateToLocation = onNavigateToLocation,
                            onMarkArrived = onMarkArrived,
                            onMarkCompleted = onMarkCompleted,
                            onViewHistory = onViewMissionHistory
                        )
                    }

                    DriverDashboardTab.SETTINGS -> {
                        // Settings tab launches a dedicated activity; no embedded content here.
                    }
                }
            }
        }
    }
}
