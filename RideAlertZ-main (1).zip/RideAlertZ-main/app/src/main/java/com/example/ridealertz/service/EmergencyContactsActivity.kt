package com.example.ridealertz.service

import android.Manifest
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import androidx.lifecycle.lifecycleScope
import com.example.ridealertz.FirebaseHelper
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.launch

private const val MAX_SECONDARY_CONTACTS = 2

class EmergencyContactsActivity : ComponentActivity() {
    private lateinit var prefs: SharedPreferences
    private var emergencyContacts = mutableStateListOf<EmergencyContact>()

    private val contactsPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            loadContactsFromDevice()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefs = getSharedPreferences("ridealertz", MODE_PRIVATE)
        loadEmergencyContacts()

        setContent {
            MaterialTheme {
                EmergencyContactsScreen(
                    onBackPressed = { finish() },
                    emergencyContacts = emergencyContacts,
                    onAddContact = { contact -> addEmergencyContact(contact) },
                    onRemoveContact = { contact -> removeEmergencyContact(contact) },
                    onLoadFromDevice = { requestContactsPermission() },
                    onClearAll = { clearAllContacts() }
                )
            }
        }
    }

    private fun requestContactsPermission() {
        // Contacts permission no longer needed - manual entry only
    }

    private fun loadEmergencyContacts() {
        val contactsJson = prefs.getString("emergency_contacts", "[]")
        val type = object : TypeToken<List<EmergencyContact>>() {}.type
        val contacts: List<EmergencyContact> = Gson().fromJson(contactsJson, type)
        emergencyContacts.clear()
        emergencyContacts.addAll(contacts.toSecondaryList())
        saveEmergencyContacts()
        fetchContactsFromRealtime()
    }

    private fun saveEmergencyContacts() {
        val contactsJson = Gson().toJson(emergencyContacts)
        prefs.edit { putString("emergency_contacts", contactsJson) }
    }

    private fun persistEmergencyContacts() {
        saveEmergencyContacts()
        syncContactsToRealtime()
    }

    private fun loadContactsFromDevice() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_CONTACTS
            ) == PackageManager.PERMISSION_GRANTED
        ) {

            val contacts = mutableListOf<DeviceContact>()

            val cursor: Cursor? = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
            )

            cursor?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME))
                    val number = c.getString(c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER))

                    if (name.isNotEmpty() && number.isNotEmpty()) {
                        val initials = name.split(" ").map { it.firstOrNull()?.toString() ?: "" }
                            .joinToString("").take(2).uppercase()
                        contacts.add(DeviceContact(name, number, initials))
                    }
                }
            }

            // Show device contacts dialog
            showDeviceContactsDialog(contacts.take(20)) // Limit to 20 contacts
        }
    }

    private fun showDeviceContactsDialog(deviceContacts: List<DeviceContact>) {
        // Device contacts loaded but not automatically added
        // Users must manually add contacts using the + button
    }

    private fun addEmergencyContact(contact: EmergencyContact) {
        if (emergencyContacts.size >= MAX_SECONDARY_CONTACTS) {
            Toast.makeText(
                this,
                "You can only add $MAX_SECONDARY_CONTACTS secondary contacts. Remove one to add another.",
                Toast.LENGTH_SHORT
            ).show()
            return
        }
        val sanitized = contact.copy(isPrimary = false)
        emergencyContacts.add(sanitized)
        persistEmergencyContacts()
    }

    private fun removeEmergencyContact(contact: EmergencyContact) {
        emergencyContacts.remove(contact)
        persistEmergencyContacts()
    }

    private fun setPrimaryContact(contact: EmergencyContact) {
        Toast.makeText(this, "Primary contact is managed in Profile details.", Toast.LENGTH_SHORT).show()
        persistEmergencyContacts()
    }

    private fun clearAllContacts() {
        emergencyContacts.clear()
        persistEmergencyContacts()
    }

    private fun normalizePhoneKey(phone: String): String {
        val digits = phone.filter { it.isDigit() }
        return if (digits.length > 10) digits.takeLast(10) else digits
    }

    private fun List<EmergencyContact>.toSecondaryList(): List<EmergencyContact> {
        val seen = LinkedHashMap<String, EmergencyContact>()
        for (raw in this) {
            val safeInitials = raw.initials?.takeUnless { it.isBlank() } ?: buildInitials(raw.name)
            val normalized = normalizePhoneKey(raw.phone)
            if (!seen.containsKey(normalized)) {
                seen[normalized] = raw.copy(initials = safeInitials, isPrimary = false)
            }
            if (seen.size >= MAX_SECONDARY_CONTACTS) break
        }
        return seen.values.toList()
    }

    private fun fetchContactsFromRealtime() {
        val userId = resolveUserId() ?: return
        lifecycleScope.launch {
            try {
                val remote = FirebaseHelper.readEmergencyContacts(userId)
                if (remote.isNotEmpty()) {
                    val mapped = remote.mapNotNull { mapToEmergencyContact(it) }
                    if (mapped.isNotEmpty()) {
                        emergencyContacts.clear()
                        emergencyContacts.addAll(mapped.toSecondaryList())
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun syncContactsToRealtime() {
        val userId = resolveUserId() ?: return
        val now = System.currentTimeMillis()
        val payload = emergencyContacts.toList().toSecondaryList().map { contact ->
            val normalized = normalizePhoneKey(contact.phone)
            mapOf<String, Any>(
                "id" to (if (normalized.isNotBlank()) "contact_${normalized}" else "contact_${now}_${contact.name.hashCode()}"),
                "userId" to userId,
                "name" to contact.name,
                "phone" to contact.phone,
                "relation" to contact.relation,
                "initials" to (contact.initials ?: buildInitials(contact.name)),
                "isPrimary" to contact.isPrimary,
                "updatedAt" to System.currentTimeMillis()
            )
        }
        lifecycleScope.launch {
            try {
                FirebaseHelper.saveEmergencyContacts(userId, payload)
            } catch (_: Exception) {
            }
        }
    }

    private fun resolveUserId(): String? {
        return prefs.getString("user_uid", null)
            ?: prefs.getString("user_email", null)?.replace("@", "_")
            ?: prefs.getString("user_phone", null)
    }

    private fun mapToEmergencyContact(raw: Map<String, Any?>): EmergencyContact? {
        val name = raw["name"] as? String ?: return null
        val phone = raw["phone"] as? String ?: return null
        val relation = raw["relation"] as? String ?: ""
        val initials = (raw["initials"] as? String)?.ifBlank { buildInitials(name) } ?: buildInitials(name)
        val isPrimary = parseBoolean(raw["isPrimary"])
        return EmergencyContact(name, phone, initials, isPrimary, relation)
    }

    private fun parseBoolean(value: Any?): Boolean = when (value) {
        is Boolean -> value
        is Number -> value.toInt() != 0
        is String -> value.equals("true", true) || value == "1"
        else -> false
    }

    private fun buildInitials(name: String): String {
        return name.split(" ")
            .mapNotNull { it.firstOrNull()?.toString() }
            .take(2)
            .joinToString("")
            .uppercase()
            .ifEmpty { name.take(2).uppercase() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmergencyContactsScreen(
    onBackPressed: () -> Unit,
    emergencyContacts: List<EmergencyContact>,
    onAddContact: (EmergencyContact) -> Unit,
    onRemoveContact: (EmergencyContact) -> Unit,
    onLoadFromDevice: () -> Unit,
    onClearAll: () -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "Emergency Contacts",
                            fontWeight = FontWeight.Bold,
                            fontSize = 22.sp,
                            color = Color.White
                        )
                        Text(
                            text = "People who get your crash & SOS alerts",
                            color = Color(0xFF9CA3AF),
                            fontSize = 12.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackPressed) {
                        Icon(Icons.Default.Close, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF020617),
                    titleContentColor = Color.White
                ),
                actions = {
                    if (emergencyContacts.isNotEmpty()) {
                        TextButton(onClick = onClearAll) {
                            Text("Clear All", color = Color(0xFFF97373))
                        }
                    }
                    IconButton(onClick = { showAddDialog = true }) {
                        Icon(Icons.Default.Add, contentDescription = "Add Contact", tint = Color.White)
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = Color(0xFFDC2626)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Contact", tint = Color.White)
            }
        },
        containerColor = Color(0xFF020617)
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFF020617))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                HeaderCard(
                    contactCount = emergencyContacts.size,
                    onLoadFromDevice = onLoadFromDevice
                )
            }

            if (emergencyContacts.isEmpty()) {
                item {
                    EmptyContactsCard()
                }
            } else {
                items(emergencyContacts) { contact ->
                    EmergencyContactCard(
                        contact = contact,
                        onRemove = { onRemoveContact(contact) },
                        onSetPrimary = { }
                    )
                }
            }

            item {
                InstructionsCard()
            }
        }
    }

    if (showAddDialog) {
        AddContactDialog(
            onDismiss = { showAddDialog = false },
            onAddContact = { contact ->
                onAddContact(contact)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun HeaderCard(
    contactCount: Int,
    onLoadFromDevice: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF022C22)),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Emergency Contacts",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFBBF7D0)
                    )
                    Text(
                        text = "$contactCount contacts configured",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF4ADE80)
                    )
                }
                Icon(
                    imageVector = Icons.Default.Emergency,
                    contentDescription = null,
                    modifier = Modifier.size(32.dp),
                    tint = Color(0xFFE53E3E)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Choose up to 2 trusted people.\nThey receive crash and SOS alerts automatically.",
                color = Color(0xFF86EFAC),
                style = MaterialTheme.typography.bodyMedium
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onLoadFromDevice,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Person, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Load from Contacts", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun EmptyContactsCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Emergency,
                contentDescription = null,
                tint = Color(0xFFF97316),
                modifier = Modifier.size(48.dp)
            )
            Text(
                text = "No contacts added yet",
                fontWeight = FontWeight.Bold,
                color = Color.White,
                fontSize = 18.sp
            )
            Text(
                text = "Add at least one emergency contact to ensure someone is notified during an SOS or crash event.",
                textAlign = TextAlign.Center,
                color = Color(0xFFCBD5F5)
            )
        }
    }
}

@Composable
fun EmergencyContactCard(
    contact: EmergencyContact,
    onRemove: () -> Unit,
    onSetPrimary: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFF97316).copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = contact.initials ?: "\u2605",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(contact.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text(
                    contact.phone,
                    color = Color(0xFF9CA3AF),
                    fontSize = 13.sp
                )
                if (contact.relation.isNotBlank()) {
                    Text(contact.relation, color = Color(0xFFFDE68A), fontSize = 12.sp)
                }
            }

            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                IconButton(onClick = onRemove) {
                    Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color(0xFFF87171))
                }
                IconButton(onClick = onSetPrimary) {
                    Icon(Icons.Outlined.StarBorder, contentDescription = "Set Primary", tint = Color(0xFFFACC15))
                }
            }
        }
    }
}

@Composable
fun InstructionsCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1F2C)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                text = "How it works",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            Text(
                text = "• We automatically notify your contacts when a crash is detected.\n" +
                        "• Your primary contact is managed from the Profile tab.\n" +
                        "• Add up to two secondary contacts here for backup alerts.",
                color = Color(0xFF94A3B8),
                fontSize = 14.sp
            )
        }
    }
}

@Composable
fun AddContactDialog(
    onDismiss: () -> Unit,
    onAddContact: (EmergencyContact) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var relation by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Add Emergency Contact", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = relation,
                    onValueChange = { relation = it },
                    label = { Text("Relationship (optional)") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank() && phone.isNotBlank()) {
                        val contact = EmergencyContact(
                            name = name.trim(),
                            phone = phone.trim(),
                            initials = name.split(" ")
                                .mapNotNull { it.firstOrNull()?.toString() }
                                .take(2)
                                .joinToString("")
                                .uppercase(),
                            isPrimary = false,
                            relation = relation.trim()
                        )
                        onAddContact(contact)
                    }
                },
                enabled = name.isNotBlank() && phone.isNotBlank()
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

data class DeviceContact(
    val name: String,
    val phone: String,
    val initials: String
)

data class EmergencyContact(
    val name: String,
    val phone: String,
    val initials: String? = null,
    val isPrimary: Boolean = false,
    val relation: String = ""
)
