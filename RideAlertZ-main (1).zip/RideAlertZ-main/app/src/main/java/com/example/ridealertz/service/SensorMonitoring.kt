package com.example.ridealertz.service

import kotlin.math.max
import kotlin.math.min

data class SensorSnapshot(
    val mlProb: Float,
    val audioProb: Float,
    val accelMagnitude: Float,
    val gyroMagnitude: Float,
    val tiltDegrees: Float,
    val accelThreshold: Float,
    val gyroThreshold: Float,
    val accelRecent: Boolean,
    val gyroRecent: Boolean,
    val tiltExceeded: Boolean
)

data class SensorDecision(
    val finalScore: Float,
    val triggered: Boolean,
    val strongMotion: Boolean,
    val reason: String?
)

class SensorFusionEngine(
    private val hardTriggerScore: Float = 0.85f,
    private val motionAssistScore: Float = 0.75f
) {

    fun evaluate(snapshot: SensorSnapshot): SensorDecision {
        val accelScore = min(1f, snapshot.accelMagnitude / max(0.1f, snapshot.accelThreshold))
        val gyroScore = min(1f, snapshot.gyroMagnitude / max(0.1f, snapshot.gyroThreshold))
        val finalScore = (snapshot.audioProb * 0.45f) + (accelScore * 0.35f) + (gyroScore * 0.2f)
        val strongMotion = snapshot.accelRecent || snapshot.gyroRecent || snapshot.tiltExceeded

        var reason: String? = null
        val triggered = when {
            snapshot.mlProb >= 0.9f -> {
                reason = "ML high confidence"
                true
            }
            snapshot.audioProb >= 0.95f -> {
                reason = "Audio spike"
                true
            }
            finalScore >= hardTriggerScore -> {
                reason = "Fusion score"
                true
            }
            snapshot.mlProb >= 0.7f && strongMotion -> {
                reason = "ML + motion"
                true
            }
            snapshot.audioProb >= 0.8f && strongMotion -> {
                reason = "Audio + motion"
                true
            }
            snapshot.audioProb >= 0.7f && snapshot.mlProb >= 0.6f -> {
                reason = "Audio + ML agreement"
                true
            }
            finalScore >= motionAssistScore && strongMotion -> {
                reason = "Fusion + motion"
                true
            }
            else -> false
        }

        return SensorDecision(
            finalScore = finalScore,
            triggered = triggered,
            strongMotion = strongMotion,
            reason = reason
        )
    }
}
