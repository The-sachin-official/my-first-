package com.example.ridealertz

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.lifecycle.lifecycleScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ridealertz.ui.theme.RideAlertzTheme
import kotlinx.coroutines.launch

class ReviewActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RideAlertzTheme {
                val prefs: SharedPreferences = getSharedPreferences("ridealertz", MODE_PRIVATE)
                ReviewScreen(
                    onBack = { finish() },
                    onSave = {
                        val userId = ((
                            prefs.getString("user_email", null)
                                ?: prefs.getString("user_phone", null)
                                ?: "guest"
                            ).replace("@", "_")
                        )

                        val profile = mapOf(
                            "firstName" to (prefs.getString("first_name", "") ?: ""),
                            "lastName" to (prefs.getString("last_name", "") ?: ""),
                            "email" to (prefs.getString("user_email", "") ?: ""),
                            "phone" to (prefs.getString("user_phone", "") ?: ""),
                            "address" to (prefs.getString("address", "") ?: ""),
                            "city" to (prefs.getString("city", "") ?: ""),
                            "state" to (prefs.getString("state", "") ?: ""),
                            "postalCode" to (prefs.getString("postalCode", "") ?: ""),
                            "country" to (prefs.getString("country", "India") ?: "India"),
                            "bloodGroup" to (prefs.getString("bloodGroup", "") ?: ""),
                            "allergies" to (prefs.getString("allergies", "") ?: ""),
                            "conditions" to (prefs.getString("conditions", "") ?: ""),
                            "medications" to (prefs.getString("medications", "") ?: ""),
                            "emergencyNotes" to (prefs.getString("emergencyNotes", "") ?: ""),
                            "emergencyContactName" to (prefs.getString("emgName", "") ?: ""),
                            "emergencyContactPhone" to (prefs.getString("emgPhone", "") ?: ""),
                            "emergencyContactRelation" to (prefs.getString("emgRelation", "") ?: ""),
                            "preferredHospital" to (prefs.getString("preferredHospital", "") ?: ""),
                            "insuranceProvider" to (prefs.getString("insuranceProvider", "") ?: ""),
                            "insurancePolicy" to (prefs.getString("insurancePolicy", "") ?: ""),
                            "doctorName" to (prefs.getString("doctorName", "") ?: ""),
                            "doctorContact" to (prefs.getString("doctorContact", "") ?: ""),
                            "helmet_used" to prefs.getBoolean("helmet_used", true)
                        )

                        lifecycleScope.launch {
                            try {
                                FirebaseHelper.writeUserProfile(userId, profile)
                            } catch (_: Exception) { }
                        }

                        prefs.edit().putBoolean("profile_completed", true).apply()
                        startActivity(Intent(this, MainActivityNew::class.java))
                        finish()
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReviewScreen(onBack: () -> Unit, onSave: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                title = { Text("Review & Confirm", color = Color.White) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF020617))
            )
        },
        containerColor = Color(0xFF020617)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp)
                .background(Color(0xFF020617)),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Review your details before saving", color = Color.White, fontSize = 16.sp)

                SectionSummaryCard("Personal Details")
                SectionSummaryCard("Medical Details")
                SectionSummaryCard("Vehicle Details")
            }

            Button(
                onClick = onSave,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E))
            ) {
                Text("SAVE PROFILE", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SectionSummaryCard(title: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF020817)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Tap Edit in future to change", color = Color(0xFF64748B), fontSize = 12.sp)
            }
            Text("Edit", color = Color(0xFF38BDF8), fontSize = 13.sp)
        }
    }
}
