package com.example.ridealertz.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class StopRideReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        context.stopService(Intent(context, SensorMonitoringService::class.java))
        Toast.makeText(context, "Ride monitoring stopped", Toast.LENGTH_SHORT).show()
    }
}
