# Logcat Checker Script for Ambulance Driver Login
# Run this script to monitor login errors

Write-Host "Clearing old logs..." -ForegroundColor Yellow
adb logcat -c

Write-Host "`nMonitoring AmbulanceDriver logs..." -ForegroundColor Green
Write-Host "Try logging in now, and watch for errors below:`n" -ForegroundColor Cyan

# Filter for AmbulanceDriver related logs
adb logcat | Select-String -Pattern "AmbulanceDriver|AndroidRuntime|FATAL"

